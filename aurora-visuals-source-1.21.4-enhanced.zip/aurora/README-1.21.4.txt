Aurora Visuals - Minecraft 1.21.4 / Fabric source port

This is an initial source adaptation from the supplied 1.21.11 project.

Target versions configured:
- Minecraft 1.21.4
- Yarn 1.21.4+build.8
- Fabric Loader 0.16.10
- Fabric API 0.119.2+1.21.4
- Java 21

Important limitations:
- This environment had no network access and no Gradle installation, so dependency resolution and compilation could not be run here.
- The 1.21.4 HUD callback API does not expose the newer element-replacement API used by the original source. The custom HUD is registered using HudRenderCallback; the vanilla hotbar/crosshair may still render underneath custom versions. A further Mixin pass may be needed to fully suppress vanilla elements.
- Mixin targets and any other version-sensitive methods must be verified by building and launching against a real 1.21.4 Fabric development environment.

Build using Gradle with Java 21 and an internet connection. If compilation reports errors, use the first error in the Gradle output as the next compatibility fix.


Swap updates: Player category now includes a Swap Now button. Item Swap can be triggered with G or the button; Auto Swap refills an empty offhand with the configured item. Swap Item selects Totem, Golden Apple, Ender Pearl, or Shield. Swapping uses the normal inventory click action; individual servers may still reject inventory actions or have their own rules.
