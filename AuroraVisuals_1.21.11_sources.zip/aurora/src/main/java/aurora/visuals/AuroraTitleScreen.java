package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public class AuroraTitleScreen extends Screen {
    public static long openTime = System.currentTimeMillis();

    private static final String[][] FONT = {
            {"01110", "10001", "10001", "11111", "10001", "10001", "10001"},
            {"10001", "10001", "10001", "10001", "10001", "10001", "01110"},
            {"11110", "10001", "10001", "11110", "10100", "10010", "10001"},
            {"01110", "10001", "10001", "10001", "10001", "10001", "01110"}
    };
    private static final int[] WORD = {0, 1, 2, 3, 2, 0};

    private int panelX, panelY, panelW, thumbW, thumbH, rowH;

    public AuroraTitleScreen() {
        super(Text.literal("Aurora Visuals"));
        openTime = System.currentTimeMillis();
    }

    @Override
    protected void init() {
        MinecraftClient mc = MinecraftClient.getInstance();
        int bw = Math.min(170, width - 30);
        int bh = Math.max(16, Math.min(22, (height - 150) / 5));
        int step = bh + 4;
        int x = (width - bw) / 2;
        int y = Math.max(height / 2 - 14, 80);
        addDrawableChild(new Widgets.MenuButton(x, y, bw, bh, "Multiplayer game", 0,
                () -> mc.setScreen(new MultiplayerScreen(this))));
        addDrawableChild(new Widgets.MenuButton(x, y + step, bw, bh, "Singleplayer game", 1,
                () -> mc.setScreen(new SelectWorldScreen(this))));
        addDrawableChild(new Widgets.MenuButton(x, y + step * 2, bw, bh, "Aurora Settings", 2,
                () -> mc.setScreen(new AuroraScreen(true))));
        int half = (bw - 4) / 2;
        addDrawableChild(new Widgets.MenuButton(x, y + step * 3, half, bh, "Options", 3,
                () -> mc.setScreen(new OptionsScreen(this, mc.options))));
        addDrawableChild(new Widgets.MenuButton(x + half + 4, y + step * 3, half, bh, "Exit", 4,
                mc::scheduleStop));

        panelW = 112;
        panelX = width - panelW - 8;
        panelY = 8;
        thumbW = 46;
        rowH = Math.max(28, Math.min(40, (height - 40) / 3));
        thumbH = rowH - 12;
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        // custom background is drawn in render()
    }

    private int thumbX(int i) { return panelX + 6 + (i % 2) * (thumbW + 4); }

    private int thumbY(int i) { return panelY + 16 + (i / 2) * rowH; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        double t = System.currentTimeMillis() / 1000.0;
        MenuBackgrounds.draw(c, width, height, AuroraVisuals.MENU_BG.mode, t);

        int cell = Math.max(2, Math.min(4, height / 70));
        int y0 = Math.max(8, height / 2 - 14 - 7 * cell - 56);
        int totalW = WORD.length * 5 * cell + (WORD.length - 1) * cell;
        int x0 = (width - totalW) / 2;
        for (int li = 0; li < WORD.length; li++) {
            String[] rows = FONT[WORD[li]];
            int lx = x0 + li * 6 * cell;
            int bob = (int) Math.round(Math.sin(t * 2.0 + li * 0.7) * 1.5);
            for (int ry = 0; ry < 7; ry++) {
                for (int rx = 0; rx < 5; rx++) {
                    if (rows[ry].charAt(rx) != '1') continue;
                    int px = lx + rx * cell, py = y0 + ry * cell + bob;
                    c.fill(px + 1, py + 1, px + cell + 1, py + cell + 1, 0x60000000);
                    c.fill(px, py, px + cell, py + cell, Colors.aurora(li * 0.35 + ry * 0.05 + rx * 0.03));
                }
            }
        }
        int ty = y0 + 7 * cell + 14;
        Ui.ctext(c, "Welcome to Aurora Visuals!", width / 2, ty, 0xFFFFFFFF);
        Ui.ctext(c, "How was your day? It's about to get better!", width / 2, ty + 12, 0xFFAEB6D0);

        Ui.rrect(c, panelX, panelY, panelX + panelW, panelY + 16 + rowH * 3, 5, 0xB00B0E18);
        Ui.ctext(c, "BACKGROUND", panelX + panelW / 2, panelY + 4, 0xFFC8CEE3);
        for (int i = 0; i < MenuBackgrounds.NAMES.length; i++) {
            int tx = thumbX(i), tyy = thumbY(i);
            MenuBackgrounds.thumb(c, tx, tyy, thumbW, thumbH, i);
            boolean sel = i == AuroraVisuals.MENU_BG.mode;
            boolean hov = mx >= tx && mx < tx + thumbW && my >= tyy && my < tyy + thumbH;
            if (sel) Ui.outline(c, tx - 1, tyy - 1, tx + thumbW + 1, tyy + thumbH + 1, Colors.aurora(i * 0.3));
            else if (hov) Ui.outline(c, tx - 1, tyy - 1, tx + thumbW + 1, tyy + thumbH + 1, 0x88FFFFFF);
            Ui.ctext(c, MenuBackgrounds.NAMES[i], tx + thumbW / 2, tyy + thumbH + 2, sel ? 0xFFFFFFFF : 0xFF8F98B5);
        }

        super.render(c, mx, my, delta);

        Ui.text(c, "Minecraft 1.21.11  |  Aurora Visuals v4", 6, height - 12, 0xFFB0B8D0);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) return true;
        if (click.button() != 0) return false;
        for (int i = 0; i < MenuBackgrounds.NAMES.length; i++) {
            int tx = thumbX(i), ty = thumbY(i);
            if (click.x() >= tx && click.x() < tx + thumbW && click.y() >= ty && click.y() < ty + thumbH) {
                AuroraVisuals.MENU_BG.mode = i;
                AuroraVisuals.saveConfig();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
