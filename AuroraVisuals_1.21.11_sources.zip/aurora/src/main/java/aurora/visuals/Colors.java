package aurora.visuals;

public final class Colors {
    private Colors() {}

    public static final String[] THEME_NAMES = {"Aurora", "Ocean", "Sunset", "Mono", "Mint", "Crimson"};
    private static final int[][] THEMES = {
            {0x4ADE9A, 0xC084FC},
            {0x38BDF8, 0x818CF8},
            {0xFB7185, 0xFBBF24},
            {0xF5F5F5, 0x9CA3AF},
            {0x34D399, 0x22D3EE},
            {0xFF4D5E, 0xFF8A5C}
    };

    public static int aurora(double offset) {
        double speed = AuroraVisuals.COLOR_SPEED.value;
        double t = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 1000.0 * speed + offset * 2.5);
        int[] p = THEMES[AuroraVisuals.THEME.mode];
        return lerp(0xFF000000 | p[0], 0xFF000000 | p[1], t);
    }

    public static int lerp(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int alpha(int rgb, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mul(int argb, float f) {
        int a = Math.round((argb >>> 24) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (argb & 0xFFFFFF);
    }

    public static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }
}
