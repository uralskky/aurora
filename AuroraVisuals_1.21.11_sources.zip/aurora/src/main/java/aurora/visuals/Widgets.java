package aurora.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.text.Text;

public final class Widgets {
    private Widgets() {}

    public static class RowToggle extends ButtonWidget {
        final Feature f;
        final int index;

        public RowToggle(int x, int y, int w, int h, Feature f, int index) {
            super(x, y, w, h, net.minecraft.text.Text.empty(), b -> {
                if (f.type == Feature.Type.TOGGLE) f.toggle();
                else f.cycle();
            }, DEFAULT_NARRATION_SUPPLIER);
            this.f = f;
            this.index = index;
            this.setAlpha(0f);
        }

        @Override
        public void playDownSound(SoundManager soundManager) {
        }

        @Override
        public void drawIcon(DrawContext c, int mx, int my, float delta) {
            float ra = AuroraScreen.rowAnim(index);
            float a = AuroraScreen.alpha() * ra;
            int off = (int) ((1f - ra) * 6f);
            int x = getX(), y = getY() + off, w = getWidth(), h = getHeight();
            boolean hov = isHovered();
            if (hov) AuroraScreen.hover = f;
            float target = (f.type == Feature.Type.TOGGLE && f.enabled) ? 1f : 0f;
            f.guiAnim += (target - f.guiAnim) * AuroraScreen.step(12f);

            int accent = Colors.aurora(y * 0.01);
            int idle = hov ? 0xFF1F2538 : 0xFF181D2C;
            int bg = Colors.lerp(idle, Colors.lerp(0xFF181D2C, accent, 0.30), f.guiAnim);
            Ui.rrect(c, x, y, x + w, y + h, 4, Colors.mul(bg, a));
            if (f.guiAnim > 0.03f) Ui.outline(c, x, y, x + w, y + h, Colors.mul(Colors.alpha(accent, 70), a * f.guiAnim));

            int bs = 8;
            Ui.rrect(c, x + 6, y + (h - bs) / 2, x + 6 + bs, y + (h + bs) / 2, 2,
                    Colors.mul(Colors.lerp(0xFF3A4157, accent, f.guiAnim), a));
            Ui.text(c, f.name, x + 20, y + (h - 8) / 2, Colors.mul(Colors.lerp(0xFFB9C0D6, 0xFFFFFFFF, f.guiAnim), a));

            if (f.type == Feature.Type.TOGGLE) {
                int sw = 20, sh = 10;
                int sx = x + w - sw - 6, sy = y + (h - sh) / 2;
                int track = Colors.lerp(0xFF343A50, accent, f.guiAnim);
                Ui.rrect(c, sx, sy, sx + sw, sy + sh, 4, Colors.mul(track, a));
                int kx = sx + 2 + Math.round(f.guiAnim * 10f);
                Ui.rrect(c, kx, sy + 2, kx + 6, sy + 8, 2, Colors.mul(0xFFFFFFFF, a));
            } else {
                String t = f.valueText();
                int tw = Ui.width(t);
                Ui.rrect(c, x + w - tw - 14, y + (h - 14) / 2, x + w - 4, y + (h + 14) / 2, 3, Colors.mul(0xFF2A3045, a));
                Ui.text(c, t, x + w - tw - 9, y + (h - 8) / 2, Colors.mul(accent, a));
            }
        }
    }

    public static class RowSlider extends SliderWidget {
        final Feature f;
        final int index;

        public RowSlider(int x, int y, int w, int h, Feature f, int index) {
            super(x, y, w, h, Text.empty(), (f.value - f.min) / (f.max - f.min));
            this.f = f;
            this.index = index;
        }

        @Override
        public void playDownSound(SoundManager soundManager) {
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(f == null ? "" : f.name));
        }

        @Override
        protected void applyValue() {
            double v = f.min + (f.max - f.min) * this.value;
            if (f.integer) v = Math.round(v);
            f.value = v;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            float ra = AuroraScreen.rowAnim(index);
            float a = AuroraScreen.alpha() * ra;
            int off = (int) ((1f - ra) * 6f);
            int x = getX(), y = getY() + off, w = getWidth(), h = getHeight();
            boolean hov = isHovered();
            if (hov) AuroraScreen.hover = f;
            int accent = Colors.aurora(y * 0.01);
            Ui.rrect(c, x, y, x + w, y + h, 4, Colors.mul(hov ? 0xFF1F2538 : 0xFF181D2C, a));
            Ui.text(c, f.name, x + 8, y + 3, Colors.mul(0xFFE3E7F5, a));
            String t = f.valueText();
            Ui.text(c, t, x + w - Ui.width(t) - 8, y + 3, Colors.mul(accent, a));
            double n = (f.value - f.min) / (f.max - f.min);
            int bx1 = x + 8, bx2 = x + w - 8, by = y + h - 7;
            Ui.rrect(c, bx1, by, bx2, by + 3, 1, Colors.mul(0xFF2E3448, a));
            int fx = bx1 + (int) ((bx2 - bx1) * n);
            Ui.hgrad(c, bx1, by, Math.max(bx1 + 1, fx), by + 3, a);
            Ui.rrect(c, fx - 2, by - 2, fx + 2, by + 5, 1, Colors.mul(0xFFFFFFFF, a));
        }
    }

    public static class CatButton extends ButtonWidget {
        final String cat;
        float anim;

        public CatButton(int x, int y, int w, int h, String cat) {
            super(x, y, w, h, net.minecraft.text.Text.empty(), b -> {
                AuroraScreen.selected = cat;
                net.minecraft.client.MinecraftClient.getInstance().setScreen(new AuroraScreen(false));
            }, DEFAULT_NARRATION_SUPPLIER);
            this.cat = cat;
            this.anim = cat.equals(AuroraScreen.selected) ? 1f : 0f;
            this.setAlpha(0f);
        }

        @Override
        public void playDownSound(SoundManager soundManager) {
        }

        @Override
        public void drawIcon(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            boolean sel = cat.equals(AuroraScreen.selected);
            anim += ((sel ? 1f : 0f) - anim) * AuroraScreen.step(14f);
            int accent = Colors.aurora(0.2);
            int bg = Colors.lerp(isHovered() ? 0xFF1B2133 : 0xFF121624, Colors.lerp(0xFF121624, accent, 0.30), anim);
            Ui.rrect(c, x, y, x + w, y + h, 4, Colors.mul(bg, a));
            int bs = Math.min(12, h - 4);
            Ui.rrect(c, x + 5, y + (h - bs) / 2, x + 5 + bs, y + (h + bs) / 2, 3, Colors.mul(Colors.lerp(0xFF2B3248, accent, anim), a));
            Ui.text(c, cat.substring(0, 1), x + 5 + (bs - Ui.width(cat.substring(0, 1))) / 2, y + (h - 8) / 2, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, cat, x + 22, y + (h - 8) / 2, Colors.mul(sel ? 0xFFFFFFFF : 0xFF9AA3BF, a));
        }
    }

    public static class PillButton extends ButtonWidget {
        final String label;
        final boolean danger;

        public PillButton(int x, int y, int w, int h, String label, boolean danger, Runnable action) {
            super(x, y, w, h, net.minecraft.text.Text.empty(), b -> action.run(), DEFAULT_NARRATION_SUPPLIER);
            this.label = label;
            this.danger = danger;
            this.setAlpha(0f);
        }

        @Override
        public void playDownSound(SoundManager soundManager) {
        }

        @Override
        public void drawIcon(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            boolean hov = isHovered();
            int base = danger ? (hov ? 0xFF5A2A35 : 0xFF3A2430) : (hov ? 0xFF2B3350 : 0xFF202741);
            Ui.rrect(c, x, y, x + w, y + h, 4, Colors.mul(base, a));
            if (!danger) Ui.hgrad(c, x + 3, y + h - 2, x + w - 3, y + h - 1, a * 0.8f);
            Ui.text(c, label, x + (w - Ui.width(label)) / 2, y + (h - 8) / 2, Colors.mul(0xFFFFFFFF, a));
        }
    }

    public static class StylePill extends ButtonWidget {
        final Feature style;

        public StylePill(int x, int y, int w, int h, Feature style) {
            super(x, y, w, h, net.minecraft.text.Text.empty(), b -> style.cycle(), DEFAULT_NARRATION_SUPPLIER);
            this.style = style;
            this.setAlpha(0f);
        }

        @Override
        public void playDownSound(SoundManager soundManager) {
        }

        @Override
        public void drawIcon(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            boolean hov = isHovered();
            if (hov) AuroraScreen.hoverTip = style.name + ": tap to change the look of this element";
            Ui.rrect(c, x, y, x + w, y + h, 4, Colors.mul(hov ? 0xFF2B3350 : 0xFF202741, a));
            Ui.hgrad(c, x + 3, y + h - 2, x + w - 3, y + h - 1, a * 0.8f);
            String t = style.modes[style.mode];
            Ui.text(c, t, x + (w - Ui.width(t)) / 2, y + (h - 8) / 2, Colors.mul(0xFFFFFFFF, a));
        }
    }

    public static class MenuButton extends ButtonWidget {
        final String label;
        final int index;
        float hover;

        public MenuButton(int x, int y, int w, int h, String label, int index, Runnable action) {
            super(x, y, w, h, net.minecraft.text.Text.empty(), b -> action.run(), DEFAULT_NARRATION_SUPPLIER);
            this.label = label;
            this.index = index;
            this.setAlpha(0f);
        }

        @Override
        public void playDownSound(SoundManager soundManager) {
        }

        @Override
        public void drawIcon(DrawContext c, int mx, int my, float delta) {
            float ra = Colors.ease((System.currentTimeMillis() - AuroraTitleScreen.openTime - index * 70L) / 350f);
            if (ra <= 0.01f) return;
            int off = (int) ((1f - ra) * 16f);
            int x = getX(), y = getY() + off, w = getWidth(), h = getHeight();
            hover += ((isHovered() ? 1f : 0f) - hover) * 0.2f;
            int bg = Colors.lerp(0xFF10131D, 0xFF222842, hover);
            Ui.rrect(c, x, y, x + w, y + h, 4, Colors.mul(Colors.alpha(bg, 225), ra));
            if (hover > 0.03f) Ui.outline(c, x, y, x + w, y + h, Colors.mul(Colors.alpha(Colors.aurora(index * 0.4), 90), ra * hover));
            Ui.ctext(c, label, x + w / 2, y + (h - 8) / 2, Colors.mul(Colors.lerp(0xFFC8CEE3, 0xFFFFFFFF, hover), ra));
        }
    }
}
