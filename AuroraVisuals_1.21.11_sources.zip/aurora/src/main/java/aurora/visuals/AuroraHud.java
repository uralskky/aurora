package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.item.Item;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public final class AuroraHud {
    private AuroraHud() {}

    private static long lastNs = System.nanoTime();
    private static float dt = 0.016f;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final String[] ROMAN = {"", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final String[] DIRS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
    private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static ItemStack[] counterIcons;

    private static float targetFade, shownHp;
    private static String targetName = "";
    private static float targetMax = 20f;

    private static int bg() {
        return Colors.alpha(0x0E0E16, (int) (AuroraVisuals.HUD_ALPHA.value * 235));
    }

    public static void render(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        HudLayout.frame++;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        ClientPlayerEntity p = mc.player;

        if (AuroraVisuals.WATERMARK.enabled) watermark(c, mc, p, sw, sh);
        if (AuroraVisuals.INFO.enabled) info(c, p, sw, sh);
        if (AuroraVisuals.POTIONS.enabled) potions(c, p, sw, sh);
        if (AuroraVisuals.COUNTER.enabled) counter(c, p, sw, sh);
        if (AuroraVisuals.INVENTORY.enabled) inventory(c, p, sw, sh);
        if (AuroraVisuals.ARMOR.enabled) armor(c, p, sw, sh);
        if (AuroraVisuals.KEYSTROKES.enabled) keystrokes(c, mc, sw, sh);
        if (AuroraVisuals.TARGET_HUD.enabled) targetHud(c, mc, sw, sh);
        if (AuroraVisuals.SESSION.enabled) session(c, mc, sw, sh);
        if (AuroraVisuals.COMBAT_INFO.enabled) combatInfo(c, sw, sh);
        if (AuroraVisuals.TOTEM_BAR.enabled) totemBar(c, p, sw, sh);
        if (AuroraVisuals.TNT_TIMER.enabled) tntTimer(c, mc, p, sw, sh);
        if (AuroraVisuals.PICKUP_LOG.enabled) pickupLog(c, sw, sh);
        moduleList(c, sw, sh);
        Notifications.render(c, sw, sh);
    }

    private static int ping(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            if (e != null) return e.getLatency();
        }
        return 0;
    }

    private static void watermark(DrawContext c, MinecraftClient mc, ClientPlayerEntity p, int sw, int sh) {
        HudLayout.El e = HudLayout.WATERMARK;
        int st = AuroraVisuals.WATERMARK.style.mode;
        int nameW = Ui.width(AuroraVisuals.NAME);
        String fps = mc.getCurrentFps() + " fps";
        if (st == 4) {
            String where = "singleplayer";
            if (!mc.isInSingleplayer()) {
                net.minecraft.client.network.ServerInfo si = mc.getCurrentServerEntry();
                where = si != null && si.address != null ? Ui.trim(si.address, 90) : "online";
            }
            String f2 = mc.getCurrentFps() + " fps";
            String ms = ping(mc, p) + " ms";
            int wd = 22 + Ui.width(f2) + 12 + Ui.width(ms) + 12 + Ui.width(where) + 10;
            HudLayout.layout(e, 4, 4, wd, 16, sw, sh);
            int x = e.ax, y = e.ay;
            Ui.rrect(c, x, y, x + wd, y + 16, 4, bg());
            Ui.rrect(c, x + 3, y + 3, x + 13, y + 13, 3, Colors.aurora(0));
            Ui.text(c, "A", x + 6, y + 4, 0xFFFFFFFF);
            int cx = x + 18;
            Ui.text(c, f2, cx, y + 4, 0xFFE8EAF4);
            cx += Ui.width(f2) + 6;
            c.fill(cx, y + 4, cx + 1, y + 12, 0x30FFFFFF);
            cx += 6;
            Ui.text(c, ms, cx, y + 4, 0xFFE8EAF4);
            cx += Ui.width(ms) + 6;
            c.fill(cx, y + 4, cx + 1, y + 12, 0x30FFFFFF);
            cx += 6;
            Ui.text(c, where, cx, y + 4, 0xFFAEB6D0);
            return;
        }
        if (st == 3) {
            String user = p.getName().getString();
            String png = ping(mc, p) + " ping";
            String shortName = "Aurora";
            int wd = 18 + Ui.width(shortName) + 14 + Ui.width(user) + 14 + Ui.width(fps) + 14 + Ui.width(png) + 12;
            HudLayout.layout(e, sw / 2 - wd / 2, 4, wd, 18, sw, sh);
            int x = e.ax, y = e.ay;
            Ui.rrect(c, x, y, x + wd, y + 18, 5, bg());
            Ui.rrect(c, x + 5, y + 4, x + 15, y + 14, 3, Colors.aurora(0));
            Ui.text(c, "A", x + 8, y + 5, 0xFFFFFFFF);
            int cx = x + 20;
            Ui.text(c, shortName, cx, y + 5, 0xFFFFFFFF);
            cx += Ui.width(shortName) + 7;
            c.fill(cx, y + 5, cx + 1, y + 13, 0x40FFFFFF);
            cx += 7;
            Ui.text(c, user, cx, y + 5, 0xFFD6DBEC);
            cx += Ui.width(user) + 7;
            c.fill(cx, y + 5, cx + 1, y + 13, 0x40FFFFFF);
            cx += 7;
            Ui.text(c, fps, cx, y + 5, Colors.aurora(0.3));
            cx += Ui.width(fps) + 7;
            c.fill(cx, y + 5, cx + 1, y + 13, 0x40FFFFFF);
            cx += 7;
            Ui.text(c, png, cx, y + 5, 0xFFD6DBEC);
            return;
        }
        if (st == 2) {
            int wd = nameW + 6 + Ui.width(fps);
            HudLayout.layout(e, 6, 6, wd, 10, sw, sh);
            Ui.gtext(c, AuroraVisuals.NAME, e.ax, e.ay, 0, 1f);
            Ui.text(c, fps, e.ax + nameW + 6, e.ay, 0xFFE8E8F4);
            return;
        }
        if (st == 1) {
            String r = String.valueOf(mc.getCurrentFps());
            int wd = nameW + Ui.width(r) + 26;
            HudLayout.layout(e, 4, 4, wd, 14, sw, sh);
            int x = e.ax, y = e.ay;
            Ui.rrect(c, x, y, x + wd, y + 14, 3, bg());
            Ui.hgrad(c, x + 3, y, x + wd - 3, y + 1, 1f);
            Ui.gtext(c, AuroraVisuals.NAME, x + 6, y + 4, 0, 1f);
            Ui.text(c, r, x + 6 + nameW + 10, y + 4, 0xFFE8E8F4);
            return;
        }
        String full = fps + "  |  " + ping(mc, p) + " ms  |  " + LocalTime.now().format(CLOCK);
        int wd = nameW + Ui.width(full) + 30;
        HudLayout.layout(e, 4, 4, wd, 17, sw, sh);
        int x = e.ax, y = e.ay;
        Ui.rrect(c, x, y, x + wd, y + 17, 3, bg());
        Ui.rrect(c, x + 4, y + 4, x + 8, y + 13, 1, Colors.aurora(0));
        Ui.gtext(c, AuroraVisuals.NAME, x + 13, y + 5, 0, 1f);
        Ui.text(c, full, x + 13 + nameW + 10, y + 5, 0xFFB8B8CC);
    }

    private static void info(DrawContext c, ClientPlayerEntity p, int sw, int sh) {
        float yaw = p.getYaw() % 360f;
        if (yaw > 180f) yaw -= 360f;
        if (yaw < -180f) yaw += 360f;
        String dir = DIRS[(Math.round(yaw / 45f) + 8) % 8];
        int st = AuroraVisuals.INFO.style.mode;
        HudLayout.El e = HudLayout.INFO;
        if (st == 1) {
            String[][] rows = {
                    {"XYZ", String.format("%.0f %.0f %.0f", p.getX(), p.getY(), p.getZ())},
                    {"Speed", String.format("%.1f b/s", AuroraVisuals.bps)},
                    {"Facing", dir}};
            int wd = 104, ht = 16 + rows.length * 11;
            HudLayout.layout(e, 4, 25, wd, ht, sw, sh);
            Ui.rrect(c, e.ax, e.ay, e.ax + wd, e.ay + ht, 4, bg());
            Ui.rrect(c, e.ax + 5, e.ay + 5, e.ax + 7, e.ay + 12, 1, Colors.aurora(0.4));
            Ui.text(c, "Information", e.ax + 11, e.ay + 4, 0xFFFFFFFF);
            int yy = e.ay + 16;
            for (String[] r : rows) {
                Ui.text(c, r[0], e.ax + 7, yy, 0xFF9AA3BF);
                Ui.text(c, r[1], e.ax + wd - 7 - Ui.width(r[1]), yy, 0xFFE8EAF4);
                yy += 11;
            }
            return;
        }
        if (st == 2) {
            String s = String.format("XYZ  %.0f  %.0f  %.0f", p.getX(), p.getY(), p.getZ());
            int wd = Ui.width(s);
            HudLayout.layout(e, sw - wd - 4, sh - 14, wd, 10, sw, sh);
            Ui.text(c, s, e.ax, e.ay, Colors.aurora(0.1));
            return;
        }
        String s = String.format("XYZ %.1f %.1f %.1f  |  %s  |  %.1f BPS", p.getX(), p.getY(), p.getZ(), dir, AuroraVisuals.bps);
        int wd = Ui.width(s) + 14;
        HudLayout.layout(e, 4, 25, wd, 15, sw, sh);
        Ui.rrect(c, e.ax, e.ay, e.ax + wd, e.ay + 15, 3, bg());
        Ui.rrect(c, e.ax, e.ay + 3, e.ax + 2, e.ay + 12, 1, Colors.aurora(0.4));
        Ui.text(c, s, e.ax + 7, e.ay + 4, 0xFFE8E8F4);
    }

    private static void potions(DrawContext c, ClientPlayerEntity p, int sw, int sh) {
        List<String[]> rows = new ArrayList<>();
        for (StatusEffectInstance ef : p.getStatusEffects()) {
            String name = ef.getEffectType().value().getName().getString();
            int amp = ef.getAmplifier();
            if (amp > 0 && amp < ROMAN.length) name += " " + ROMAN[amp + 1];
            else if (amp >= ROMAN.length) name += " " + (amp + 1);
            int d = ef.getDuration();
            String t = d < 0 ? "inf" : String.format("%d:%02d", d / 1200, (d / 20) % 60);
            rows.add(new String[]{name, t, (d >= 0 && d < 200) ? "1" : "0"});
        }
        if (rows.isEmpty()) {
            if (!HudLayout.editing) return;
            rows.add(new String[]{"Speed II", "1:30", "0"});
            rows.add(new String[]{"Strength", "0:08", "1"});
        }
        int st = AuroraVisuals.POTIONS.style.mode;
        int wd = 120, n = rows.size();
        int ht = st == 0 ? 15 + n * 12 : st == 1 ? n * 15 : n * 11;
        HudLayout.El e = HudLayout.POTIONS;
        HudLayout.layout(e, 4, 45, wd, ht, sw, sh);
        int x = e.ax, y = e.ay, yy = y;
        if (st == 0) {
            Ui.rrect(c, x, y, x + wd, y + ht, 3, bg());
            Ui.hgrad(c, x + 3, y, x + wd - 3, y + 1, 1f);
            Ui.text(c, "Potions", x + 6, y + 4, 0xFF9A9AB4);
            yy = y + 15;
        }
        for (String[] r : rows) {
            boolean low = "1".equals(r[2]);
            int tc = low ? 0xFFFF6B6B : Colors.aurora(0.3);
            if (st == 1) {
                Ui.rrect(c, x, yy, x + wd, yy + 13, 3, bg());
                Ui.rrect(c, x, yy + 2, x + 2, yy + 11, 1, Colors.aurora(yy * 0.02));
                Ui.text(c, r[0], x + 7, yy + 3, 0xFFEDEDF7);
                Ui.text(c, r[1], x + wd - 5 - Ui.width(r[1]), yy + 3, tc);
                yy += 15;
            } else if (st == 2) {
                Ui.text(c, r[0] + "  " + r[1], x + 2, yy, low ? tc : 0xFFEDEDF7);
                yy += 11;
            } else {
                Ui.text(c, r[0], x + 6, yy, 0xFFEDEDF7);
                Ui.text(c, r[1], x + wd - 6 - Ui.width(r[1]), yy, tc);
                yy += 12;
            }
        }
    }

    private static ItemStack[] icons() {
        if (counterIcons == null) {
            counterIcons = new ItemStack[]{
                    new ItemStack(Items.TOTEM_OF_UNDYING), new ItemStack(Items.GOLDEN_APPLE),
                    new ItemStack(Items.ENDER_PEARL), new ItemStack(Items.EXPERIENCE_BOTTLE)};
        }
        return counterIcons;
    }

    private static void counter(DrawContext c, ClientPlayerEntity p, int sw, int sh) {
        int[] cnt = new int[4];
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            if (s.isOf(Items.TOTEM_OF_UNDYING)) cnt[0] += s.getCount();
            else if (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)) cnt[1] += s.getCount();
            else if (s.isOf(Items.ENDER_PEARL)) cnt[2] += s.getCount();
            else if (s.isOf(Items.EXPERIENCE_BOTTLE)) cnt[3] += s.getCount();
        }
        HudLayout.El e = HudLayout.COUNTER;
        HudLayout.layout(e, 4, sh / 2 - 40, 50, 76, sw, sh);
        int x = e.ax, y = e.ay;
        Ui.rrect(c, x, y, x + 50, y + 76, 3, bg());
        Ui.hgrad(c, x + 3, y, x + 47, y + 1, 1f);
        ItemStack[] ic = icons();
        for (int i = 0; i < 4; i++) {
            int yy = y + 3 + i * 18;
            c.drawItem(ic[i], x + 4, yy);
            Ui.text(c, String.valueOf(cnt[i]), x + 25, yy + 4, cnt[i] == 0 ? 0xFF77778F : 0xFFFFFFFF);
        }
    }

    private static void inventory(DrawContext c, ClientPlayerEntity p, int sw, int sh) {
        HudLayout.El e = HudLayout.INVENTORY;
        HudLayout.layout(e, 4, sh - 76, 170, 72, sw, sh);
        int x = e.ax, y = e.ay;
        Ui.rrect(c, x, y, x + 170, y + 72, 3, bg());
        Ui.hgrad(c, x + 3, y, x + 167, y + 1, 1f);
        Ui.text(c, "Inventory", x + 6, y + 4, 0xFF9A9AB4);
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 27; i++) {
            ItemStack s = inv.getStack(9 + i);
            int sx = x + 4 + (i % 9) * 18, sy = y + 15 + (i / 9) * 18;
            c.fill(sx, sy, sx + 17, sy + 17, 0x30FFFFFF);
            if (s.isEmpty()) continue;
            c.drawItem(s, sx + 1, sy + 1);
            if (s.getCount() > 1) {
                String t = String.valueOf(s.getCount());
                Ui.text(c, t, sx + 17 - Ui.width(t), sy + 9, 0xFFFFFFFF);
            }
        }
    }

    private static void armor(DrawContext c, ClientPlayerEntity p, int sw, int sh) {
        boolean any = false;
        for (EquipmentSlot s : ARMOR_SLOTS) if (!p.getEquippedStack(s).isEmpty()) any = true;
        if (!any && !HudLayout.editing) return;
        HudLayout.El e = HudLayout.ARMOR;
        HudLayout.layout(e, sw / 2 - 44, sh - 84, 88, 28, sw, sh);
        int x = e.ax, y = e.ay;
        Ui.rrect(c, x, y, x + 88, y + 28, 3, bg());
        for (int i = 0; i < 4; i++) {
            ItemStack s = p.getEquippedStack(ARMOR_SLOTS[i]);
            int sx = x + 4 + i * 21, sy = y + 4;
            c.fill(sx, sy, sx + 18, sy + 18, 0x28FFFFFF);
            if (s.isEmpty()) continue;
            c.drawItem(s, sx + 1, sy + 1);
            if (s.isDamageable() && s.getMaxDamage() > 0) {
                float f = 1f - (float) s.getDamage() / s.getMaxDamage();
                int col = Colors.lerp(0xFFFF4D4D, 0xFF4ADE80, f);
                c.fill(sx + 1, sy + 20, sx + 17, sy + 22, 0xFF202030);
                c.fill(sx + 1, sy + 20, sx + 1 + Math.max(1, (int) (16 * f)), sy + 22, col);
            }
        }
    }

    private static void key(DrawContext c, int x, int y, int wd, int ht, String label, boolean down, String sub) {
        int base = down ? Colors.alpha(Colors.aurora(x * 0.02) & 0xFFFFFF, 190) : bg();
        Ui.rrect(c, x, y, x + wd, y + ht, 3, base);
        int ty = sub == null ? y + (ht - 8) / 2 : y + 3;
        Ui.text(c, label, x + (wd - Ui.width(label)) / 2, ty, down ? 0xFF101018 : 0xFFE8E8F4);
        if (sub != null) Ui.text(c, sub, x + (wd - Ui.width(sub)) / 2, y + 12, down ? 0xFF101018 : 0xFF9A9AB4);
    }

    private static void keystrokes(DrawContext c, MinecraftClient mc, int sw, int sh) {
        HudLayout.El e = HudLayout.KEYS;
        HudLayout.layout(e, sw - 70, sh - 86, 66, 82, sw, sh);
        int kx = e.ax, ky = e.ay;
        var o = mc.options;
        key(c, kx + 22, ky, 22, 20, "W", o.forwardKey.isPressed(), null);
        key(c, kx, ky + 22, 22, 20, "A", o.leftKey.isPressed(), null);
        key(c, kx + 22, ky + 22, 22, 20, "S", o.backKey.isPressed(), null);
        key(c, kx + 44, ky + 22, 22, 20, "D", o.rightKey.isPressed(), null);
        key(c, kx, ky + 44, 32, 22, "LMB", o.attackKey.isPressed(), AuroraVisuals.cpsLeft() + " CPS");
        key(c, kx + 34, ky + 44, 32, 22, "RMB", o.useKey.isPressed(), AuroraVisuals.cpsRight() + " CPS");
        key(c, kx, ky + 68, 66, 14, "Space", o.jumpKey.isPressed(), null);
    }

    private static void targetHud(DrawContext c, MinecraftClient mc, int sw, int sh) {
        Entity ent = mc.targetedEntity;
        if (ent instanceof LivingEntity t) {
            targetName = t.getName().getString();
            targetMax = Math.max(1f, t.getMaxHealth());
            float hp = Math.max(0f, t.getHealth());
            if (targetFade < 0.05f) shownHp = hp;
            shownHp += (hp - shownHp) * Math.min(1f, dt * 10f);
            targetFade += (1f - targetFade) * Math.min(1f, dt * 12f);
        } else if (HudLayout.editing) {
            targetName = "Zombie";
            targetMax = 20f;
            shownHp = 15f;
            targetFade = 1f;
        } else {
            targetFade += (0f - targetFade) * Math.min(1f, dt * 8f);
        }
        if (targetFade < 0.03f) return;
        float a = targetFade;
        int st = AuroraVisuals.TARGET_HUD.style.mode;
        String s = String.format("%.1f", shownHp);
        float pct = Math.max(0f, Math.min(1f, shownHp / targetMax));
        int bw = st == 1 ? 104 : st == 2 ? 80 : st == 3 ? 142 : st == 4 ? 124 : 132;
        int bh = st == 1 ? 23 : st == 2 ? 14 : st == 3 ? 36 : st == 4 ? 28 : 38;
        HudLayout.El e = HudLayout.TARGET;
        if (st == 4) HudLayout.layout(e, sw / 2 - bw / 2, sh / 2 + 70, bw, bh, sw, sh);
        else HudLayout.layout(e, sw / 2 + 16, sh / 2 + 14, bw, bh, sw, sh);
        int x = e.ax, y = e.ay;
        if (st == 4) {
            Ui.rrect(c, x, y, x + bw, y + bh, 6, Colors.mul(bg(), a));
            Ui.rrect(c, x + 4, y + 4, x + 24, y + 24, 4, Colors.mul(Colors.aurora(0.1), a));
            String ini = targetName.isEmpty() ? "?" : targetName.substring(0, 1).toUpperCase();
            Ui.ctext(c, ini, x + 14, y + 10, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, Ui.trim(targetName, bw - 66), x + 30, y + 6, Colors.mul(0xFFFFFFFF, a));
            Ui.rrect(c, x + 30, y + 18, x + 30 + 56, y + 21, 1, Colors.mul(0xFF2A2A3A, a));
            int fx = x + 30 + (int) (56 * pct);
            if (fx > x + 31) Ui.rrect(c, x + 30, y + 18, fx, y + 21, 1, Colors.mul(0xFFFF4D5E, a));
            Ui.rrect(c, x + bw - 28, y + 5, x + bw - 27, y + 23, 0, Colors.mul(0xFFFF4D5E, a));
            Ui.text(c, String.valueOf(Math.round(shownHp)), x + bw - 22, y + 10, Colors.mul(0xFFFF6B7A, a));
        } else if (st == 1) {
            Ui.rrect(c, x, y, x + bw, y + bh, 3, Colors.mul(bg(), a));
            Ui.text(c, targetName, x + 6, y + 4, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, s, x + bw - 6 - Ui.width(s), y + 4, Colors.mul(0xFFB8B8CC, a));
            Ui.rrect(c, x + 6, y + 15, x + bw - 6, y + 18, 1, Colors.mul(0xFF2A2A3A, a));
            int fx = x + 6 + (int) ((bw - 12) * pct);
            if (fx > x + 7) Ui.hgrad(c, x + 6, y + 15, fx, y + 18, a);
        } else if (st == 2) {
            Ui.text(c, targetName, x, y, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, s, x + Ui.width(targetName) + 6, y, Colors.mul(Colors.aurora(0.3), a));
            c.fill(x, y + 11, x + 72, y + 13, Colors.mul(0x80000000, a));
            int fx = x + (int) (72 * pct);
            if (fx > x) Ui.hgrad(c, x, y + 11, fx, y + 13, a);
        } else if (st == 3) {
            Ui.rrect(c, x, y, x + bw, y + bh, 2, Colors.mul(bg(), a));
            Ui.hgrad(c, x, y, x + bw, y + 1, a);
            Ui.hgrad(c, x, y + bh - 1, x + bw, y + bh, a);
            c.fill(x, y, x + 1, y + bh, Colors.mul(Colors.aurora(0), a));
            c.fill(x + bw - 1, y, x + bw, y + bh, Colors.mul(Colors.aurora(0.8), a));
            Ui.text(c, targetName, x + 7, y + 6, Colors.mul(0xFFFFFFFF, a));
            Ui.rrect(c, x + 7, y + 19, x + bw - 7, y + 29, 2, Colors.mul(0xFF22222F, a));
            int fx = x + 7 + (int) ((bw - 14) * pct);
            if (fx > x + 8) Ui.hgrad(c, x + 7, y + 19, fx, y + 29, a);
            String pc = Math.round(pct * 100) + "%";
            Ui.text(c, pc, x + (bw - Ui.width(pc)) / 2, y + 20, Colors.mul(0xFFFFFFFF, a));
        } else {
            Ui.rrect(c, x, y, x + bw, y + bh, 4, Colors.mul(bg(), a));
            Ui.hgrad(c, x + 3, y, x + bw - 3, y + 2, a);
            Ui.text(c, targetName, x + 7, y + 8, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, s, x + bw - 7 - Ui.width(s), y + 8, Colors.mul(0xFFB8B8CC, a));
            Ui.rrect(c, x + 7, y + 24, x + bw - 7, y + 30, 2, Colors.mul(0xFF2A2A3A, a));
            int fx = x + 7 + (int) ((bw - 14) * pct);
            if (fx > x + 8) Ui.hgrad(c, x + 7, y + 24, fx, y + 30, a);
        }
    }

    private static void session(DrawContext c, MinecraftClient mc, int sw, int sh) {
        String server = "Singleplayer";
        ServerInfo si = mc.getCurrentServerEntry();
        if (si != null && si.address != null) server = si.address;
        server = Ui.trim(server, 110);
        long sec = (System.currentTimeMillis() - AuroraVisuals.SESSION_START) / 1000;
        String time = String.format("%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60);
        HudLayout.El e = HudLayout.SESSION;
        HudLayout.layout(e, sw / 2 - 60, 4, 120, 28, sw, sh);
        Ui.rrect(c, e.ax, e.ay, e.ax + 120, e.ay + 28, 3, bg());
        Ui.hgrad(c, e.ax + 3, e.ay, e.ax + 117, e.ay + 1, 1f);
        Ui.text(c, server, e.ax + 6, e.ay + 5, 0xFFEDEDF7);
        Ui.text(c, "Playing " + time, e.ax + 6, e.ay + 16, 0xFF9A9AB4);
    }

    private static void combatInfo(DrawContext c, int sw, int sh) {
        long now = System.currentTimeMillis();
        int combo = (now - AuroraVisuals.lastHit < 2000) ? AuroraVisuals.combo : 0;
        HudLayout.El e = HudLayout.COMBAT;
        HudLayout.layout(e, 4, sh / 2 + 42, 84, 40, sw, sh);
        Ui.rrect(c, e.ax, e.ay, e.ax + 84, e.ay + 40, 3, bg());
        Ui.hgrad(c, e.ax + 3, e.ay, e.ax + 81, e.ay + 1, 1f);
        Ui.text(c, String.format("Reach %.2f", AuroraVisuals.lastReach), e.ax + 6, e.ay + 5, 0xFFEDEDF7);
        Ui.text(c, "Combo " + combo, e.ax + 6, e.ay + 16, Colors.aurora(0.3));
        Ui.text(c, "Hits " + AuroraVisuals.hits, e.ax + 6, e.ay + 27, 0xFF9A9AB4);
    }

    private static void moduleList(DrawContext c, int sw, int sh) {
        List<Feature> list = new ArrayList<>();
        for (Feature f : AuroraVisuals.FEATURES) {
            if (f.type != Feature.Type.TOGGLE) continue;
            f.anim += ((f.enabled ? 1f : 0f) - f.anim) * Math.min(1f, dt * 10f);
            if (f.anim > 0.02f && f != AuroraVisuals.MODULE_LIST && f != AuroraVisuals.NOTIFY) list.add(f);
        }
        if (!AuroraVisuals.MODULE_LIST.enabled) return;
        int st = AuroraVisuals.MODULE_LIST.style.mode;
        list.sort(Comparator.comparingInt((Feature f) -> Ui.width(f.name)).reversed());
        int wd = 60;
        for (Feature f : list) wd = Math.max(wd, Ui.width(f.name) + 14);
        int step = st == 2 ? 10 : 13;
        HudLayout.El e = HudLayout.MODULES;
        HudLayout.layout(e, sw - wd - 2, 4, wd, Math.max(13, list.size() * step), sw, sh);
        int right = e.ax + wd;
        int y = e.ay, i = 0;
        for (Feature f : list) {
            int tw = Ui.width(f.name);
            int slide = (int) ((1f - f.anim) * (tw + 14));
            int x = right - tw - 8 + slide;
            int col = Colors.mul(Colors.aurora(i * 0.1), f.anim);
            if (st == 0) {
                Ui.rrect(c, x - 4, y, right - 2 + slide, y + 12, 2, Colors.mul(bg(), f.anim));
                c.fill(right - 2 + slide, y + 1, right + slide, y + 11, col);
                Ui.text(c, f.name, x, y + 2, col);
            } else if (st == 1) {
                Ui.rrect(c, x - 5, y, right - 4 + slide, y + 12, 3, Colors.mul(bg(), f.anim));
                Ui.text(c, f.name, x, y + 2, col);
            } else {
                Ui.text(c, f.name, right - tw - 3 + slide, y, col);
            }
            y += step;
            i++;
        }
    }

    private static float hotbarX = -1f;

    public static void hotbar(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int x0 = sw / 2 - 91, y = sh - 22;
        int sel = p.getInventory().getSelectedSlot();
        float target = x0 + sel * 20;
        if (hotbarX < 0) hotbarX = target;
        hotbarX += (target - hotbarX) * Math.min(1f, dt * 18f + 0.02f);

        Ui.rrect(c, x0 - 2, y - 1, x0 + 184, y + 23, 5, bg());
        Ui.hgrad(c, x0 + 2, y - 1, x0 + 180, y, 1f);
        int hx = Math.round(hotbarX);
        Ui.rrect(c, hx, y + 1, hx + 22, y + 21, 4, Colors.alpha(Colors.aurora(0.3) & 0xFFFFFF, 90));
        Ui.outline(c, hx, y + 1, hx + 22, y + 21, Colors.aurora(0.1));
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty()) continue;
            int ix = x0 + 3 + i * 20, iy = y + 3;
            c.drawItem(s, ix, iy);
            if (s.getCount() > 1) {
                String t = String.valueOf(s.getCount());
                Ui.text(c, t, ix + 17 - Ui.width(t), iy + 9, 0xFFFFFFFF);
            }
            if (s.isDamageable() && s.getDamage() > 0 && s.getMaxDamage() > 0) {
                float f = 1f - (float) s.getDamage() / s.getMaxDamage();
                c.fill(ix + 1, iy + 14, ix + 15, iy + 16, 0xFF202030);
                c.fill(ix + 1, iy + 14, ix + 1 + Math.max(1, (int) (14 * f)), iy + 16, Colors.lerp(0xFFFF4D4D, 0xFF4ADE80, f));
            }
        }
        ItemStack off = p.getOffHandStack();
        if (!off.isEmpty()) {
            int ox = x0 - 28;
            Ui.rrect(c, ox - 2, y - 1, ox + 22, y + 23, 5, bg());
            c.drawItem(off, ox + 3, y + 3);
        }
    }

    private static void totemBar(DrawContext c, ClientPlayerEntity p, int sw, int sh) {
        int count = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(Items.TOTEM_OF_UNDYING)) count += s.getCount();
        }
        if (count == 0 && !HudLayout.editing) return;
        int shown = Math.max(1, Math.min(count, 6));
        int wd = shown * 17 + 12 + (count > 6 ? Ui.width("+" + (count - 6)) + 4 : 0);
        HudLayout.El e = HudLayout.TOTEMS;
        HudLayout.layout(e, sw / 2 + 12, sh - 62, wd, 22, sw, sh);
        Ui.rrect(c, e.ax, e.ay, e.ax + wd, e.ay + 22, 4, bg());
        for (int i = 0; i < shown; i++) c.drawItem(icons()[0], e.ax + 5 + i * 17, e.ay + 3);
        if (count > 6) Ui.text(c, "+" + (count - 6), e.ax + 8 + shown * 17, e.ay + 7, 0xFFFFFFFF);
    }

    private static void tntTimer(DrawContext c, MinecraftClient mc, ClientPlayerEntity p, int sw, int sh) {
        TntEntity best = null;
        double bestD = 1e9;
        if (mc.world != null) {
            for (TntEntity t : mc.world.getEntitiesByClass(TntEntity.class, p.getBoundingBox().expand(48), e -> true)) {
                double d = p.squaredDistanceTo(t);
                if (d < bestD) { bestD = d; best = t; }
            }
        }
        String s;
        if (best != null) s = String.format("TNT  %.1fs  |  %.1fm", best.getFuse() / 20.0, Math.sqrt(bestD));
        else if (HudLayout.editing) s = "TNT  2.4s  |  6.1m";
        else return;
        int wd = Ui.width(s) + 16;
        HudLayout.El e = HudLayout.TNT;
        HudLayout.layout(e, sw / 2 - wd / 2, 40, wd, 16, sw, sh);
        Ui.rrect(c, e.ax, e.ay, e.ax + wd, e.ay + 16, 4, bg());
        Ui.rrect(c, e.ax + 4, e.ay + 4, e.ax + 7, e.ay + 12, 1, 0xFFFF4D4D);
        Ui.text(c, s, e.ax + 11, e.ay + 4, 0xFFFFFFFF);
    }

    private static void pickupLog(DrawContext c, int sw, int sh) {
        List<String> lines = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Long> en : AuroraVisuals.PICKUPS.entrySet()) {
            if (now - en.getValue() < 4000) lines.add(en.getKey());
        }
        if (lines.isEmpty()) {
            if (!HudLayout.editing) return;
            lines.add("+3 Diamond");
        }
        int wd = 80;
        for (String l : lines) wd = Math.max(wd, Ui.width(l) + 16);
        HudLayout.El e = HudLayout.PICKUPS;
        HudLayout.layout(e, 4, sh / 2 + 90, wd, lines.size() * 12 + 4, sw, sh);
        Ui.rrect(c, e.ax, e.ay, e.ax + wd, e.ay + lines.size() * 12 + 4, 3, bg());
        int y = e.ay + 3;
        for (String l : lines) {
            Ui.text(c, l, e.ax + 8, y, Colors.aurora(y * 0.02));
            y += 12;
        }
    }

    public static void crosshair(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int cx = mc.getWindow().getScaledWidth() / 2, cy = mc.getWindow().getScaledHeight() / 2;
        int col = Colors.aurora(0);
        switch (AuroraVisuals.CROSS_STYLE.mode) {
            case 1 -> c.fill(cx - 1, cy - 1, cx + 2, cy + 2, col);
            case 2 -> {
                c.fill(cx - 6, cy, cx + 7, cy + 1, col);
                c.fill(cx, cy - 6, cx + 1, cy + 7, col);
            }
            default -> {
                c.fill(cx - 7, cy, cx - 3, cy + 1, col);
                c.fill(cx + 4, cy, cx + 8, cy + 1, col);
                c.fill(cx, cy - 7, cx + 1, cy - 3, col);
                c.fill(cx, cy + 4, cx + 1, cy + 8, col);
            }
        }
    }
}
