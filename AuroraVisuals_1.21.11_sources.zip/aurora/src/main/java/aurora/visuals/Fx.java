package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;

public final class Fx {
    private Fx() {}

    public static void spawn(ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        mc.particleManager.addParticle(e, x, y, z, vx, vy, vz);
    }
}
