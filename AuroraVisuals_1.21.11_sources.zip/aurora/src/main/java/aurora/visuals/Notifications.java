package aurora.visuals;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public final class Notifications {
    private Notifications() {}

    private static final class N {
        final String text;
        final long born;
        N(String t, long b) { text = t; born = b; }
    }

    private static final List<N> LIST = new ArrayList<>();

    public static void push(String t) {
        LIST.add(new N(t, System.currentTimeMillis()));
        if (LIST.size() > 5) LIST.remove(0);
    }

    public static void render(DrawContext c, int sw, int sh) {
        long now = System.currentTimeMillis();
        LIST.removeIf(n -> now - n.born > 2800);
        int idx = 0;
        for (int i = LIST.size() - 1; i >= 0; i--) {
            N n = LIST.get(i);
            long age = now - n.born;
            float in = Colors.ease(age / 260f);
            float out = age > 2500 ? Colors.ease((age - 2500) / 300f) : 0f;
            int wd = Ui.width(n.text) + 24;
            int x = sw - wd - 4 + (int) (((1f - in) + out) * (wd + 8));
            int y = sh - 96 - idx * 20;
            Ui.rrect(c, x, y, x + wd, y + 16, 3, Colors.alpha(0x0E0E16, (int) (AuroraVisuals.HUD_ALPHA.value * 235)));
            Ui.rrect(c, x + 4, y + 4, x + 7, y + 12, 1, Colors.aurora(idx * 0.3));
            Ui.text(c, n.text, x + 12, y + 4, 0xFFEDEDF7);
            idx++;
        }
    }
}
