package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Particle based visuals that run every client tick. */
public final class Effects {
    private Effects() {}

    public static void tick(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w) {
        if (AuroraVisuals.TARGET_ESP.enabled) targetEsp(mc, p);
        if (AuroraVisuals.CHINA_HAT.enabled && !mc.options.getPerspective().isFirstPerson()) chinaHat(p);
        if (AuroraVisuals.PREDICTION.enabled) prediction(p, w);
    }

    private static LivingEntity pickTarget(MinecraftClient mc, ClientPlayerEntity p) {
        Entity t = mc.targetedEntity;
        if (t instanceof LivingEntity le && le.isAlive() && le != p) return le;
        Entity last = AuroraVisuals.lastTarget;
        if (last instanceof LivingEntity le && le.isAlive() && AuroraVisuals.lastTargetAge < 60 && p.distanceTo(le) < 24f) return le;
        return null;
    }

    private static void targetEsp(MinecraftClient mc, ClientPlayerEntity p) {
        LivingEntity e = pickTarget(mc, p);
        if (e == null) return;
        ParticleEffect fx = AuroraVisuals.FX[AuroraVisuals.HIT_MODE.mode];
        double age = p.age;
        double h = e.getHeight(), r = e.getWidth() * 0.8 + 0.2;
        switch (AuroraVisuals.ESP_STYLE.mode) {
            case 1 -> {
                for (int k = 0; k < 3; k++) {
                    double a = age * 0.2 + k * 2.094;
                    Fx.spawn(fx, e.getX() + Math.cos(a) * (r + 0.2), e.getY() + h * 0.55 + Math.sin(age * 0.1 + k) * 0.25,
                            e.getZ() + Math.sin(a) * (r + 0.2), 0, 0, 0);
                }
            }
            case 2 -> {
                for (int k = 0; k < 4; k++) {
                    double t = (age * 0.04 + k * 0.25) % 1.0;
                    double a = age * 0.3 + k * 1.57;
                    Fx.spawn(fx, e.getX() + Math.cos(a) * r, e.getY() + t * h, e.getZ() + Math.sin(a) * r, 0, 0, 0);
                }
            }
            case 3 -> {
                for (int k = 0; k < 3; k++) {
                    double a = age * 0.35 + k * 2.094;
                    Fx.spawn(fx, e.getX() + Math.cos(a) * 0.45, e.getY() + h + 0.3, e.getZ() + Math.sin(a) * 0.45, 0, 0, 0);
                }
            }
            default -> {
                double y = e.getY() + (0.5 + 0.5 * Math.sin(age * 0.15)) * h;
                for (int k = 0; k < 2; k++) {
                    double a = age * 0.4 + k * Math.PI;
                    Fx.spawn(fx, e.getX() + Math.cos(a) * r, y, e.getZ() + Math.sin(a) * r, 0, 0, 0);
                }
            }
        }
    }

    private static void chinaHat(ClientPlayerEntity p) {
        double base = p.getY() + p.getStandingEyeHeight() + 0.3;
        for (int k = 0; k < 3; k++) {
            double r = 0.55 - k * 0.17;
            double a = p.age * 0.25 + k * 0.8;
            Fx.spawn(ParticleTypes.END_ROD, p.getX() + Math.cos(a) * r, base + k * 0.1, p.getZ() + Math.sin(a) * r, 0, 0, 0);
            Fx.spawn(ParticleTypes.END_ROD, p.getX() - Math.cos(a) * r, base + k * 0.1, p.getZ() - Math.sin(a) * r, 0, 0, 0);
        }
    }

    private static boolean throwable(ItemStack s) {
        return s.isOf(Items.ENDER_PEARL) || s.isOf(Items.SNOWBALL) || s.isOf(Items.EGG)
                || s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION) || s.isOf(Items.EXPERIENCE_BOTTLE);
    }

    private static void prediction(ClientPlayerEntity p, ClientWorld w) {
        ItemStack main = p.getMainHandStack(), off = p.getOffHandStack();
        double speed, grav;
        if (main.isOf(Items.BOW) && p.isUsingItem()) {
            speed = BowItem.getPullProgress(p.getItemUseTime()) * 3.0;
            grav = 0.05;
        } else if (main.isOf(Items.CROSSBOW) && CrossbowItem.isCharged(main)) {
            speed = 3.15;
            grav = 0.05;
        } else if (main.isOf(Items.TRIDENT) && p.isUsingItem()) {
            speed = 2.5;
            grav = 0.05;
        } else if (throwable(main) || throwable(off)) {
            ItemStack s = throwable(main) ? main : off;
            if (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION)) { speed = 0.5; grav = 0.05; }
            else if (s.isOf(Items.EXPERIENCE_BOTTLE)) { speed = 0.7; grav = 0.07; }
            else { speed = 1.5; grav = 0.03; }
        } else {
            return;
        }
        if (speed < 0.1) return;

        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
        Vec3d dir = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3d vel = dir.multiply(speed);
        Vec3d pv = p.getVelocity();
        vel = vel.add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);
        Vec3d pos = p.getEyePos().add(0.0, -0.1, 0.0);
        Vec3d land = null;
        for (int step = 0; step < 90; step++) {
            Vec3d next = pos.add(vel);
            BlockHitResult hit = w.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (hit.getType() != HitResult.Type.MISS) {
                land = hit.getPos();
                break;
            }
            if (step % 2 == 0 && step > 2) Fx.spawn(ParticleTypes.CRIT, pos.x, pos.y, pos.z, 0, 0, 0);
            pos = next;
            vel = vel.multiply(0.99).add(0.0, -grav, 0.0);
        }
        if (land != null) {
            for (int i = 0; i < 10; i++) {
                double a = i / 10.0 * Math.PI * 2;
                Fx.spawn(ParticleTypes.END_ROD, land.x + Math.cos(a) * 0.3, land.y + 0.05, land.z + Math.sin(a) * 0.3, 0, 0, 0);
            }
        }
    }
}
