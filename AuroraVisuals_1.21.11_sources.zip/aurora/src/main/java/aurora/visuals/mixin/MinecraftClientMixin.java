package aurora.visuals.mixin;

import aurora.visuals.AuroraTitleScreen;
import aurora.visuals.AuroraVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen aurora$title(Screen screen) {
        if (AuroraVisuals.CUSTOM_MENU.enabled && screen != null && screen.getClass() == TitleScreen.class) {
            return new AuroraTitleScreen();
        }
        return screen;
    }
}
