package aurora.visuals;

/** Retained for source compatibility; item swap is now controlled by the user in the client settings. */
public final class ServerGate {
    private ServerGate() {}
    public static boolean allowed(net.minecraft.client.MinecraftClient mc) { return true; }
}
