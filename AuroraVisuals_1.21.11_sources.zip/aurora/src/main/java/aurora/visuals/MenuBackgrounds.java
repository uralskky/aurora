package aurora.visuals;

import net.minecraft.client.gui.DrawContext;

import java.util.Random;

public final class MenuBackgrounds {
    private MenuBackgrounds() {}

    public static final String[] NAMES = {"Aurora", "Forest", "Field", "Lake", "Sunset", "Winter"};
    private static final int[][] SKY = {
            {0xFF05060D, 0xFF0F1428}, {0xFF07130E, 0xFF21443A}, {0xFF2B5C93, 0xFFA9D2EA},
            {0xFF050A18, 0xFF17305A}, {0xFF2A1745, 0xFFF08A5D}, {0xFF93AFC9, 0xFFEAF2F8}};
    private static final int[] GROUND = {0xFF05060B, 0xFF0B1B14, 0xFF3C7A35, 0xFF0B1630, 0xFF1A0F2B, 0xFFF4F8FB};

    public static void thumb(DrawContext c, int x, int y, int w, int h, int scene) {
        c.fillGradient(x, y, x + w, y + h, SKY[scene][0], SKY[scene][1]);
        c.fill(x, y + h * 2 / 3, x + w, y + h, GROUND[scene]);
    }

    public static void draw(DrawContext c, int w, int h, int scene, double t) {
        c.fillGradient(0, 0, w, h, SKY[scene][0], SKY[scene][1]);
        switch (scene) {
            case 1 -> forest(c, w, h, t);
            case 2 -> field(c, w, h, t);
            case 3 -> lake(c, w, h, t);
            case 4 -> sunset(c, w, h, t);
            case 5 -> winter(c, w, h, t);
            default -> aurora(c, w, h, t);
        }
    }

    private static void stars(DrawContext c, int w, int h, double t, int n, double maxY) {
        Random r = new Random(7);
        for (int i = 0; i < n; i++) {
            int sx = (int) (r.nextFloat() * w), sy = (int) (r.nextFloat() * h * maxY);
            double ph = r.nextFloat() * 6.28;
            int a = (int) (210 * Math.max(0.0, 0.35 + 0.65 * Math.sin(t * 1.5 + ph)));
            if (a < 10) continue;
            int sz = i % 7 == 0 ? 2 : 1;
            c.fill(sx, sy, sx + sz, sy + sz, Colors.alpha(0xFFFFFF, a));
        }
    }

    private static void aurora(DrawContext c, int w, int h, double t) {
        stars(c, w, h, t, 110, 0.75);
        for (int b = 0; b < 3; b++) {
            for (int x = 0; x < w; x += 3) {
                double wave = Math.sin(x * 0.012 + t * 0.45 + b * 2.1) * h * 0.07 + Math.sin(x * 0.027 - t * 0.3 + b) * h * 0.025;
                int mid = (int) (h * (0.30 + b * 0.07) + wave);
                double th = h * (0.10 + 0.05 * Math.sin(x * 0.02 - t * 0.6 + b * 1.3));
                int col = Colors.aurora(b * 0.8 + x * 0.003) & 0xFFFFFF;
                int top = (int) (mid - th), bot = (int) (mid + th * 0.6);
                c.fillGradient(x, top, x + 3, mid, Colors.alpha(col, 0), Colors.alpha(col, 70));
                c.fillGradient(x, mid, x + 3, bot, Colors.alpha(col, 70), Colors.alpha(col, 0));
            }
        }
        hills(c, w, h, 0.82, 0.035, 0xFF05060B, 0.018, 1.3);
        c.fillGradient(0, (int) (h * 0.72), w, h, 0x0005060B, 0xCC05060B);
    }

    private static void hills(DrawContext c, int w, int h, double base, double amp, int col, double f1, double ph) {
        for (int x = 0; x < w; x += 2) {
            double y = h * base - (Math.sin(x * f1) + Math.sin(x * f1 * 2.3 + ph) * 0.6) * h * amp;
            c.fill(x, (int) y, x + 2, h, col);
        }
    }

    private static void trees(DrawContext c, int w, int baseY, int spacing, int s, int col, long seed) {
        Random r = new Random(seed);
        for (int x = -10; x < w + 10; x += spacing + r.nextInt(spacing)) {
            int th = (6 + r.nextInt(5)) * s;
            c.fill(x - s, baseY - th, x + s, baseY, col);
            c.fill(x - 5 * s, baseY - th - 4 * s, x + 5 * s, baseY - th + 3 * s, col);
            c.fill(x - 3 * s, baseY - th - 7 * s, x + 3 * s, baseY - th - 4 * s, col);
        }
    }

    private static void forest(DrawContext c, int w, int h, double t) {
        stars(c, w, h, t, 40, 0.4);
        trees(c, w, (int) (h * 0.80), 16, 2, 0xFF13342B, 11);
        c.fillGradient(0, (int) (h * 0.55), w, (int) (h * 0.85), 0x00214438, 0x88214438);
        trees(c, w, (int) (h * 0.88), 22, 3, 0xFF081711, 23);
        c.fill(0, (int) (h * 0.88), w, h, 0xFF050E0A);
        Random r = new Random(5);
        for (int i = 0; i < 16; i++) {
            double ph = r.nextFloat() * 6.28;
            int fx = (int) (r.nextFloat() * w + Math.sin(t * 0.5 + ph) * 8);
            int fy = (int) (h * (0.5 + r.nextFloat() * 0.4) + Math.cos(t * 0.7 + ph) * 5);
            int a = (int) (230 * Math.max(0.0, 0.5 + 0.5 * Math.sin(t * 2 + ph)));
            c.fill(fx, fy, fx + 2, fy + 2, Colors.alpha(0xE8FF8A, a));
        }
    }

    private static void field(DrawContext c, int w, int h, double t) {
        c.fill((int) (w * 0.78), (int) (h * 0.14), (int) (w * 0.78) + 18, (int) (h * 0.14) + 18, 0xFFFFF3B0);
        for (int i = 0; i < 6; i++) {
            double cx = ((i * 83 + t * (4 + i)) % (w + 120)) - 60;
            int cy = (int) (h * (0.14 + (i % 3) * 0.08));
            c.fill((int) cx, cy, (int) cx + 34, cy + 7, 0xCCFFFFFF);
            c.fill((int) cx + 8, cy - 5, (int) cx + 24, cy, 0xCCFFFFFF);
        }
        hills(c, w, h, 0.70, 0.04, 0xFF4E9A44, 0.012, 0.5);
        hills(c, w, h, 0.82, 0.05, 0xFF3C7A35, 0.017, 2.1);
        c.fillGradient(0, (int) (h * 0.9), w, h, 0x00000000, 0x55000000);
    }

    private static void lake(DrawContext c, int w, int h, double t) {
        stars(c, w, h, t, 70, 0.45);
        int mx = (int) (w * 0.2), my = (int) (h * 0.12);
        c.fill(mx, my, mx + 14, my + 14, 0xFFE9EEFF);
        hills(c, w, h, 0.56, 0.05, 0xFF08122A, 0.011, 0.9);
        int wy = (int) (h * 0.60);
        c.fillGradient(0, wy, w, h, 0xFF0C1C3E, 0xFF050B1B);
        for (int y = wy + 2; y < h; y += 3) {
            double k = (y - wy) / (double) (h - wy);
            int len = 8 + (int) (14 * k);
            for (int x = 0; x < w; x += 29) {
                int sx = x + (int) (Math.sin(t * 0.8 + y * 0.3 + x) * 6);
                c.fill(sx, y, sx + len, y + 1, Colors.alpha(0xAFC4FF, (int) (40 * (1 - k * 0.5))));
            }
        }
        for (int y = wy + 2; y < h; y += 2) {
            int ox = mx + (int) (Math.sin(t * 1.3 + y * 0.4) * 3);
            c.fill(ox, y, ox + 14, y + 1, Colors.alpha(0xE9EEFF, 70));
        }
    }

    private static void sunset(DrawContext c, int w, int h, double t) {
        int sx = (int) (w * 0.62), sy = (int) (h * 0.52);
        for (int i = 5; i >= 1; i--) {
            int r = 12 + i * 14;
            c.fill(sx - r, sy - r, sx + r, sy + r, Colors.alpha(0xFFB36B, 14));
        }
        c.fill(sx - 12, sy - 12, sx + 12, sy + 12, 0xFFFFE2A8);
        for (int i = 0; i < 4; i++) {
            double cx = ((i * 140 + t * (3 + i)) % (w + 160)) - 80;
            int cy = (int) (h * (0.22 + i * 0.07));
            c.fill((int) cx, cy, (int) cx + 90, cy + 3, Colors.alpha(0xFFB1A0, 90));
        }
        hills(c, w, h, 0.72, 0.045, 0xFF2A1740, 0.010, 1.0);
        hills(c, w, h, 0.84, 0.05, 0xFF160B26, 0.015, 2.4);
    }

    private static void winter(DrawContext c, int w, int h, double t) {
        hills(c, w, h, 0.72, 0.04, 0xFFE8F1F8, 0.011, 0.4);
        hills(c, w, h, 0.84, 0.05, 0xFFFFFFFF, 0.016, 2.0);
        Random r = new Random(3);
        for (int x = 8; x < w; x += 26 + r.nextInt(30)) {
            int base = (int) (h * 0.78) + r.nextInt(8);
            int tier = 5 + r.nextInt(3);
            c.fill(x - 1, base, x + 1, base + 6, 0xFF4A3A2B);
            for (int i = 0; i < tier; i++) {
                int half = 2 + i * 2;
                c.fill(x - half, base - i * 5 - 4, x + half, base - i * 5, i % 2 == 0 ? 0xFF1F4A3C : 0xFF2A5E4C);
            }
        }
        for (int i = 0; i < 90; i++) {
            double fx = ((i * 37.0) % w + Math.sin(t * 0.6 + i) * 6 + w) % w;
            double fy = (i * 53.0 + t * (14 + (i % 5) * 6)) % h;
            int sz = i % 6 == 0 ? 2 : 1;
            c.fill((int) fx, (int) fy, (int) fx + sz, (int) fy + sz, 0xEEFFFFFF);
        }
    }
}
