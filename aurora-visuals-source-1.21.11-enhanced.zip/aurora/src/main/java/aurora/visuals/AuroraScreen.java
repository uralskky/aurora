package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class AuroraScreen extends Screen {
    public static final String[] CATS = {"HUD", "Combat", "View", "Effects", "World", "Player", "Theme", "Configs"};
    public static String selected = "HUD";
    public static Feature hover;
    public static String hoverTip;
    private static long openTime;
    private static long catStart;
    private static long lastNs = System.nanoTime();
    private static float dt = 0.016f;

    private int px, py, pw, ph, sbW;
    private int cfgX, cfgW, cfgTop;

    public AuroraScreen(boolean animate) {
        super(Text.literal(AuroraVisuals.NAME));
        if (animate) openTime = System.currentTimeMillis();
        catStart = System.currentTimeMillis();
    }

    public static float alpha() {
        return Colors.ease((System.currentTimeMillis() - openTime) / 220f);
    }

    public static float rowAnim(int index) {
        return Colors.ease((System.currentTimeMillis() - catStart - index * 30L) / 220f);
    }

    public static float step(float speed) {
        return Math.min(1f, dt * speed);
    }

    @Override
    protected void init() {
        pw = Math.min(width - 10, 520);
        ph = Math.min(height - 10, 270);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        sbW = Math.min(84, pw / 5);

        int stepY = Math.min(24, (ph - 80) / CATS.length);
        int y = py + 38;
        for (String cat : CATS) {
            addDrawableChild(new Widgets.CatButton(px + 6, y, sbW - 8, stepY - 3, cat));
            y += stepY;
        }
        addDrawableChild(new Widgets.PillButton(px + pw - 22, py + 7, 16, 16, "x", true, this::close));
        addDrawableChild(new Widgets.PillButton(px + pw - 92, py + 7, 66, 16, "Edit HUD", false,
                () -> MinecraftClient.getInstance().setScreen(new HudEditorScreen())));
        if (selected.equals("Player")) {
            addDrawableChild(new Widgets.PillButton(px + pw - 160, py + 7, 60, 16, "Swap now", false,
                    AuroraVisuals::requestSwap));
        }

        List<Feature> list = new ArrayList<>();
        for (Feature f : AuroraVisuals.FEATURES) if (f.category.equals(selected)) list.add(f);

        if (selected.equals("Configs")) {
            int ccx = px + sbW + 4, ccw = pw - sbW - 10, ctop = py + 34;
            cfgX = ccx; cfgW = ccw; cfgTop = ctop;
            for (int i = 1; i <= 5; i++) {
                int ry = ctop + (i - 1) * 28;
                final int slot = i;
                addDrawableChild(new Widgets.PillButton(ccx + ccw - 188, ry + 4, 56, 16, "Save", false, () -> {
                    AuroraVisuals.saveSlot(slot);
                    MinecraftClient.getInstance().setScreen(new AuroraScreen(false));
                }));
                addDrawableChild(new Widgets.PillButton(ccx + ccw - 126, ry + 4, 56, 16, "Load", false, () -> {
                    AuroraVisuals.loadSlot(slot);
                    MinecraftClient.getInstance().setScreen(new AuroraScreen(false));
                }));
                addDrawableChild(new Widgets.PillButton(ccx + ccw - 64, ry + 4, 56, 16, "Delete", true, () -> {
                    AuroraVisuals.deleteSlot(slot);
                    MinecraftClient.getInstance().setScreen(new AuroraScreen(false));
                }));
            }
            return;
        }

        int cx = px + sbW + 4, cw = pw - sbW - 10;
        int top = py + 34, bottom = py + ph - 18;
        int rowH = 24, gap = 4;
        int cols = Math.max(1, Math.min(3, cw / 150));
        int maxRows = Math.max(1, (bottom - top + gap) / (rowH + gap));
        while ((list.size() + cols - 1) / cols > maxRows && rowH > 18) {
            rowH -= 2;
            maxRows = Math.max(1, (bottom - top + gap) / (rowH + gap));
        }
        while ((list.size() + cols - 1) / cols > maxRows && cols < 4) cols++;
        int colW = (cw - (cols - 1) * gap) / cols;

        for (int i = 0; i < list.size(); i++) {
            Feature f = list.get(i);
            int x = cx + (i % cols) * (colW + gap);
            int yy = top + (i / cols) * (rowH + gap);
            if (f.type == Feature.Type.SLIDER) {
                addDrawableChild(new Widgets.RowSlider(x, yy, colW, rowH, f, i));
            } else if (f.style != null) {
                int pillW = Math.min(54, colW / 2 - 4);
                addDrawableChild(new Widgets.RowToggle(x, yy, colW - pillW - 3, rowH, f, i));
                addDrawableChild(new Widgets.StylePill(x + colW - pillW, yy, pillW, rowH, f.style));
            } else {
                addDrawableChild(new Widgets.RowToggle(x, yy, colW, rowH, f, i));
            }
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        hover = null;
        hoverTip = null;
        float a = alpha();

        Ui.rrect(c, px - 2, py - 2, px + pw + 2, py + ph + 2, 6, Colors.mul(0x70000000, a));
        Ui.rrect(c, px, py, px + pw, py + ph, 5, Colors.mul(0xC00B0E18, a));
        Ui.rrect(c, px, py, px + sbW, py + ph, 5, Colors.mul(0xB00A0D16, a));
        MinecraftClient mcl = MinecraftClient.getInstance();
        String user = mcl.player != null ? mcl.player.getName().getString() : "Player";
        Ui.rrect(c, px + 6, py + ph - 28, px + sbW - 2, py + ph - 6, 4, Colors.mul(0xFF171C2B, a));
        Ui.rrect(c, px + 10, py + ph - 24, px + 24, py + ph - 10, 3, Colors.mul(Colors.aurora(0.2), a));
        Ui.text(c, user.substring(0, 1).toUpperCase(), px + 14, py + ph - 20, Colors.mul(0xFFFFFFFF, a));
        Ui.text(c, Ui.trim(user, sbW - 42), px + 28, py + ph - 23, Colors.mul(0xFFFFFFFF, a));
        Ui.text(c, "Aurora", px + 28, py + ph - 14, Colors.mul(0xFF7F88A6, a));
        if (selected.equals("Configs")) {
            for (int i = 1; i <= 5; i++) {
                int ry = cfgTop + (i - 1) * 28;
                Ui.rrect(c, cfgX, ry, cfgX + cfgW, ry + 24, 4, Colors.mul(0xFF181D2C, a));
                Ui.text(c, "Config " + i, cfgX + 10, ry + 4, Colors.mul(0xFFFFFFFF, a));
                boolean ex = AuroraVisuals.slotExists(i);
                Ui.text(c, ex ? "saved" : "empty", cfgX + 10, ry + 14, Colors.mul(ex ? Colors.aurora(0.3) : 0xFF6F7896, a));
            }
        }
        Ui.hgrad(c, px + 4, py, px + pw - 4, py + 2, a);

        Ui.gtext(c, AuroraVisuals.NAME, px + 10, py + 12, 0, a);
        Ui.rrect(c, px + sbW + 6, py + 8, px + sbW + 6 + Ui.width(selected.toUpperCase()) + 14, py + 24, 4, Colors.mul(0xFF1A2033, a));
        Ui.text(c, selected.toUpperCase(), px + sbW + 13, py + 12, Colors.mul(0xFFFFFFFF, a));

        super.render(c, mx, my, delta);

        String foot = hoverTip != null ? hoverTip : hover != null ? hover.desc
                : "RShift opens Aurora  |  Tap a module to toggle it  |  Style pills change appearance";
        Ui.text(c, foot, px + sbW + 8, py + ph - 12, Colors.mul(0xFF7F88A6, a));
    }

    @Override
    public void removed() {
        AuroraVisuals.saveConfig();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
