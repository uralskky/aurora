package aurora.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class AuroraVisuals implements ClientModInitializer {
    public static final String NAME = "Aurora Visuals";
    public static final List<Feature> FEATURES = new ArrayList<>();
    public static final List<Feature> STYLES = new ArrayList<>();

    // HUD
    public static final Feature WATERMARK   = add(Feature.toggle("Watermark", "Client name, FPS, ping and clock", "HUD", true));
    public static final Feature MODULE_LIST = add(Feature.toggle("Module List", "Animated list of active features", "HUD", true));
    public static final Feature INFO        = add(Feature.toggle("Coordinates", "XYZ, direction and speed in BPS", "HUD", true));
    public static final Feature POTIONS     = add(Feature.toggle("Potions", "Active effects with timers", "HUD", true));
    public static final Feature KEYSTROKES  = add(Feature.toggle("Keystrokes", "WASD, mouse buttons and CPS", "HUD", true));
    public static final Feature ARMOR       = add(Feature.toggle("Armor HUD", "Worn armor with durability bars", "HUD", true));
    public static final Feature INVENTORY   = add(Feature.toggle("Inventory HUD", "Your backpack on the screen", "HUD", false));
    public static final Feature COUNTER     = add(Feature.toggle("Item Counter", "Totems, golden apples, pearls, XP", "HUD", true));
    public static final Feature SESSION     = add(Feature.toggle("Session Info", "Server address and play time", "HUD", false));
    public static final Feature COMBAT_INFO = add(Feature.toggle("Combat Info", "Reach, combo and hit counter", "HUD", false));
    public static final Feature NOTIFY      = add(Feature.toggle("Notifications", "Pop-ups when you toggle features", "HUD", true));
    public static final Feature HOTBAR_ANIM = add(Feature.toggle("Hotbar Animation", "Glass hotbar with a sliding selector", "HUD", false));
    public static final Feature TOTEM_BAR   = add(Feature.toggle("Totem Bar", "Shows how many totems you carry", "HUD", false));
    public static final Feature TNT_TIMER   = add(Feature.toggle("TNT Timer", "Countdown of the nearest lit TNT", "HUD", false));
    public static final Feature PICKUP_LOG  = add(Feature.toggle("Pickup Log", "Items you just picked up", "HUD", false));
    public static final Feature TOTEM_ALERT = add(Feature.toggle("Totem Warning", "Notify when your totem supply gets low", "HUD", false));
    public static final Feature DURABILITY_ALERT = add(Feature.toggle("Durability Warning", "Notify when worn gear is close to breaking", "HUD", false));

    // Combat visuals
    public static final Feature TARGET_HUD  = add(Feature.toggle("Target HUD", "Health panel of the entity you look at", "Combat", true));
    public static final Feature HIT_FX      = add(Feature.toggle("Hit Effect", "Particles when you hit something", "Combat", true));
    public static final Feature HIT_MODE    = add(Feature.mode("Hit Style", "Particle type for hit and trail effects", "Combat", 0, "Stars", "Hearts", "Flames", "Magic", "Crit", "Souls"));
    public static final Feature HIT_SOUND   = add(Feature.toggle("Hit Sound", "Soft chime on every hit", "Combat", false));
    public static final Feature KILL_FX     = add(Feature.toggle("Kill Effect", "Burst when your target dies", "Combat", true));
    public static final Feature TARGET_ESP  = add(Feature.toggle("Target ESP", "Effect around the target you aim at", "Combat", false));
    public static final Feature ESP_STYLE   = add(Feature.mode("Target ESP Style", "Shape of the target effect", "Combat", 0, "Ring", "Orbit", "Spiral", "Halo"));
    public static final Feature PREDICTION  = add(Feature.toggle("Prediction", "Flight path of arrows, pearls, potions", "Combat", false));
    public static final Feature CROSSHAIR   = add(Feature.toggle("Custom Crosshair", "Replaces the vanilla crosshair", "Combat", false));
    public static final Feature CROSS_STYLE = add(Feature.mode("Crosshair Style", "Shape of the custom crosshair", "Combat", 0, "Cross", "Dot", "Plus"));

    // View
    public static final Feature VIEW_MODEL  = add(Feature.toggle("View Model", "Moves and scales the item in your hand", "View", false));
    public static final Feature VM_X        = add(Feature.slider("Hand X", "Left / right offset of the hand", "View", -1.0, 1.0, 0.0, false));
    public static final Feature VM_Y        = add(Feature.slider("Hand Y", "Up / down offset of the hand", "View", -1.0, 1.0, 0.0, false));
    public static final Feature VM_Z        = add(Feature.slider("Hand Z", "Forward / back offset of the hand", "View", -1.0, 1.0, 0.0, false));
    public static final Feature VM_SCALE    = add(Feature.slider("Hand Scale", "Size of the item in your hand", "View", 0.4, 1.6, 1.0, false));
    public static final Feature SWING_ANIM  = add(Feature.mode("Swing Animation", "Style of the hand swing", "View", 0, "Vanilla", "Smooth", "Slash", "Poke", "Spin", "Chop"));
    public static final Feature SWING       = add(Feature.mode("Swing Speed", "Slows the hand swing", "View", 0, "Off", "Slow", "Slower"));

    // Effects
    public static final Feature TRAIL       = add(Feature.toggle("Trail", "Particles behind you while moving", "Effects", false));
    public static final Feature JUMP_FX     = add(Feature.toggle("Jump Circles", "Ring of sparks when you jump", "Effects", true));
    public static final Feature HALO        = add(Feature.toggle("Halo", "Glowing ring above your head", "Effects", false));
    public static final Feature CHINA_HAT   = add(Feature.toggle("China Hat", "Glowing cone above your head (3rd person)", "Effects", false));
    public static final Feature BODY_GLOW   = add(Feature.toggle("Body Glow", "Outline around your own character", "Effects", false));
    public static final Feature ORBIT       = add(Feature.toggle("Orbit", "Sparkles circling around you", "Effects", false));
    public static final Feature WEATHER     = add(Feature.toggle("Weather Particles", "Ambient particles around you", "Effects", false));
    public static final Feature WEATHER_TYPE = add(Feature.mode("Weather Type", "Which particles fall around you", "Effects", 0, "Snow", "Sakura", "Embers", "Fireflies", "Ash"));
    public static final Feature WEATHER_AMOUNT = add(Feature.slider("Weather Density", "How many particles spawn", "Effects", 1, 14, 4, true));
    public static final Feature PTEST       = add(Feature.toggle("Particle Test", "Spawns a test burst in front of you", "Effects", false));

    // World
    public static final Feature FULLBRIGHT  = add(Feature.toggle("Fullbright", "Sees everything in the dark", "World", false));
    public static final Feature FOV_ON      = add(Feature.toggle("FOV Changer", "Uses the FOV slider below", "World", false));
    public static final Feature FOV         = add(Feature.slider("FOV", "Field of view", "World", 30, 110, 90, true));
    public static final Feature ZOOM        = add(Feature.toggle("Zoom", "Hold C to zoom in", "World", true));
    public static final Feature OPTIMIZATION = add(Feature.toggle("Optimization", "Lower entity distance and biome blend for FPS", "World", false));
    public static final Feature ZOOM_FOV    = add(Feature.slider("Zoom FOV", "Field of view while zooming", "World", 10, 60, 30, true));

    // Player
    public static final Feature AUTO_SPRINT  = add(Feature.toggle("Auto Sprint", "Sprints while you walk forward", "Player", false));
    public static final Feature AUTO_RESPAWN = add(Feature.toggle("Auto Respawn", "Respawns instantly after death", "Player", false));
    public static final Feature ITEM_SWAP   = add(Feature.toggle("Item Swap", "Key G moves the chosen item to your offhand (FunTime / SkyTime only)", "Player", false));
    public static final Feature SWAP_ITEM   = add(Feature.mode("Swap Item", "Which item Item Swap looks for", "Player", 0, "Totem", "Golden Apple", "Ender Pearl", "Shield"));

    // Theme
    public static final Feature THEME       = add(Feature.mode("Color Theme", "Accent colors of the whole client", "Theme", 5, Colors.THEME_NAMES));
    public static final Feature COLOR_SPEED = add(Feature.slider("Color Speed", "Speed of the color animation", "Theme", 0.2, 3.0, 1.0, false));
    public static final Feature HUD_ALPHA   = add(Feature.slider("HUD Opacity", "Background opacity of HUD panels", "Theme", 0.3, 1.0, 0.75, false));
    public static final Feature CUSTOM_FONT = add(Feature.toggle("Custom Font", "Aurora font in menus and HUD", "Theme", true));
    public static final Feature CUSTOM_MENU = add(Feature.toggle("Custom Main Menu", "Aurora title screen (restart menu to apply)", "Theme", true));

    static {
        WATERMARK.style = style("Watermark Style", "Glass", "Compact", "Minimal", "Aura", "Rage");
        WATERMARK.style.mode = 4;
        INFO.style = style("Coordinates Style", "Bar", "Panel", "Corner");
        MODULE_LIST.style = style("Module List Style", "Bar", "Glass", "Minimal");
        POTIONS.style = style("Potions Style", "Panel", "Compact", "Minimal");
        TARGET_HUD.style = style("Target HUD Style", "Glass", "Compact", "Minimal", "Neon", "Pill");
    }

    public static final Feature MENU_BG = style("Menu Background", MenuBackgrounds.NAMES);

    private static Feature style(String n, String... modes) {
        Feature f = Feature.mode(n, "Style", "_style", 0, modes);
        STYLES.add(f);
        return f;
    }

    public static final ParticleEffect[] FX = {
            ParticleTypes.END_ROD, ParticleTypes.HEART, ParticleTypes.FLAME,
            ParticleTypes.WITCH, ParticleTypes.CRIT, ParticleTypes.SOUL_FIRE_FLAME};

    public static double bps;
    public static Entity lastTarget;
    public static double lastReach;
    public static int combo, hits;
    public static long lastHit;
    public static final long SESSION_START = System.currentTimeMillis();

    public static int lastTargetAge;
    public static final Map<String, Long> PICKUPS = new LinkedHashMap<>();
    private static Map<Item, Integer> lastInv = new HashMap<>();
    private static boolean invInit, glowSet;
    private static double optEntity = -1;
    private static int optBlend = -1;
    private static KeyBinding openKey, zoomKey, swapKey;
    private static boolean pendingOpen;
    private static boolean wasOnGround = true;
    private static double prevX, prevZ;
    private static boolean zoomActive;
    private static int zoomSaved = 70;
    private static int origFov = -1;
    private static boolean wasAtk, wasUse, sprintForced;
    private static boolean totemLowState, durabilityLowState;
    private static long lastResourceCheck;
    private static double gammaSaved = -1;
    private static Field gammaField;
    private static final ArrayDeque<Long> LMB = new ArrayDeque<>();
    private static final ArrayDeque<Long> RMB = new ArrayDeque<>();

    private static Feature add(Feature f) {
        FEATURES.add(f);
        return f;
    }

    public static int cpsLeft() { return LMB.size(); }
    public static int cpsRight() { return RMB.size(); }

    public static void onToggle(Feature f) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (f == FULLBRIGHT) {
            if (f.enabled) {
                double cur = mc.options.getGamma().getValue();
                if (cur <= 1.0) gammaSaved = cur;
            } else {
                restoreGamma(mc);
                if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            }
        }
        if (f == FOV_ON) {
            if (f.enabled) {
                origFov = mc.options.getFov().getValue();
            } else if (origFov > 0) {
                mc.options.getFov().setValue(origFov);
                origFov = -1;
            }
        }
        if (f == OPTIMIZATION) {
            if (f.enabled) {
                optEntity = mc.options.getEntityDistanceScaling().getValue();
                optBlend = mc.options.getBiomeBlendRadius().getValue();
                mc.options.getEntityDistanceScaling().setValue(0.5);
                mc.options.getBiomeBlendRadius().setValue(1);
            } else {
                if (optEntity > 0) mc.options.getEntityDistanceScaling().setValue(optEntity);
                if (optBlend >= 0) mc.options.getBiomeBlendRadius().setValue(optBlend);
            }
        }
        if (NOTIFY.enabled && f != NOTIFY && f != PTEST) {
            Notifications.push(f.name + (f.enabled ? " enabled" : " disabled"));
        }
    }

    private static boolean setGamma(MinecraftClient mc, double v) {
        try {
            SimpleOption<Double> o = mc.options.getGamma();
            if (gammaField == null) {
                for (Field fl : SimpleOption.class.getDeclaredFields()) {
                    if (!Modifier.isStatic(fl.getModifiers()) && !Modifier.isFinal(fl.getModifiers())
                            && fl.getType() == Object.class) {
                        fl.setAccessible(true);
                        gammaField = fl;
                        break;
                    }
                }
            }
            if (gammaField == null) return false;
            gammaField.set(o, Double.valueOf(v));
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void restoreGamma(MinecraftClient mc) {
        if (gammaSaved >= 0 && gammaField != null) {
            setGamma(mc, gammaSaved);
        }
        gammaSaved = -1;
    }

    @Override
    public void onInitializeClient() {
        loadConfig();

        KeyBinding.Category keyCategory = KeyBinding.Category.create(Identifier.of("aurora", "main"));
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, keyCategory));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, keyCategory));

        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora.swap", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, keyCategory));

        HudElementRegistry.replaceElement(VanillaHudElements.HOTBAR, original -> (ctx, tick) -> {
            if (HOTBAR_ANIM.enabled) AuroraHud.hotbar(ctx);
            else original.render(ctx, tick);
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("aurora", "hud"),
                (ctx, tick) -> AuroraHud.render(ctx));

        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tick) -> {
            if (CROSSHAIR.enabled) AuroraHud.crosshair(ctx);
            else original.render(ctx, tick);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("aurora").executes(ctx -> {
                    pendingOpen = true;
                    return 1;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(AuroraVisuals::tick);

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            restoreGamma(client);
            saveConfig();
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) {
                lastTarget = entity;
                lastTargetAge = 0;
                long now = System.currentTimeMillis();
                combo = (now - lastHit < 2000) ? combo + 1 : 1;
                lastHit = now;
                hits++;
                lastReach = player.distanceTo(entity);
                if (HIT_FX.enabled) {
                    ParticleEffect fx = FX[HIT_MODE.mode];
                    for (int i = 0; i < 18; i++) {
                        double a = Math.random() * Math.PI * 2;
                        double s = 0.05 + Math.random() * 0.12;
                        Fx.spawn(fx, entity.getX(), entity.getBodyY(0.5), entity.getZ(),
                                Math.cos(a) * s, 0.05 + Math.random() * 0.12, Math.sin(a) * s);
                    }
                }
                if (HIT_SOUND.enabled) player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.7f);
            }
            return ActionResult.PASS;
        });
    }

    private static double rnd() { return Math.random(); }

    private static void tick(MinecraftClient mc) {
        if (pendingOpen && mc.currentScreen == null) {
            pendingOpen = false;
            mc.setScreen(new AuroraScreen(true));
        }
        while (openKey.wasPressed()) mc.setScreen(new AuroraScreen(true));
        while (swapKey.wasPressed()) doSwap(mc);

        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return;

        double dx = p.getX() - prevX, dz = p.getZ() - prevZ;
        prevX = p.getX(); prevZ = p.getZ();
        bps += (Math.sqrt(dx * dx + dz * dz) * 20.0 - bps) * 0.25;

        long now = System.currentTimeMillis();
        boolean atk = mc.options.attackKey.isPressed();
        if (atk && !wasAtk) LMB.addLast(now);
        wasAtk = atk;
        boolean use = mc.options.useKey.isPressed();
        if (use && !wasUse) RMB.addLast(now);
        wasUse = use;
        while (!LMB.isEmpty() && now - LMB.peekFirst() > 1000) LMB.pollFirst();
        while (!RMB.isEmpty() && now - RMB.peekFirst() > 1000) RMB.pollFirst();

        if (AUTO_RESPAWN.enabled && p.isDead()) p.requestRespawn();

        if (BODY_GLOW.enabled) {
            p.setGlowing(true);
            glowSet = true;
        } else if (glowSet) {
            p.setGlowing(false);
            glowSet = false;
        }

        if (PICKUP_LOG.enabled && p.age % 5 == 0) trackPickups(p, now);
        if (now - lastResourceCheck >= 1000L) {
            lastResourceCheck = now;
            checkResourceWarnings(p);
        }
        Effects.tick(mc, p, w);

        if (AUTO_SPRINT.enabled) {
            if (mc.options.forwardKey.isPressed() && !p.isSneaking()) {
                mc.options.sprintKey.setPressed(true);
                sprintForced = true;
            } else if (sprintForced) {
                mc.options.sprintKey.setPressed(false);
                sprintForced = false;
            }
        } else if (sprintForced) {
            mc.options.sprintKey.setPressed(false);
            sprintForced = false;
        }

        if (FULLBRIGHT.enabled) {
            double cur = mc.options.getGamma().getValue();
            if (cur <= 1.0 && gammaSaved < 0) gammaSaved = cur;
            boolean ok = cur > 14.0 || setGamma(mc, 15.0);
            if (!ok && p.age % 100 == 0) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            }
        }

        var fovOpt = mc.options.getFov();
        boolean zooming = ZOOM.enabled && zoomKey.isPressed();
        if (zooming) {
            if (!zoomActive) { zoomActive = true; zoomSaved = fovOpt.getValue(); }
            int zf = ZOOM_FOV.intValue();
            if (fovOpt.getValue() != zf) fovOpt.setValue(zf);
        } else if (zoomActive) {
            zoomActive = false;
            fovOpt.setValue(zoomSaved);
        } else if (FOV_ON.enabled) {
            if (origFov < 0) origFov = fovOpt.getValue();
            int t = FOV.intValue();
            if (fovOpt.getValue() != t) fovOpt.setValue(t);
        }

        if (WEATHER.enabled) {
            int n = WEATHER_AMOUNT.intValue();
            int type = WEATHER_TYPE.mode;
            for (int i = 0; i < n; i++) {
                double x = p.getX() + (rnd() * 2 - 1) * 14, z = p.getZ() + (rnd() * 2 - 1) * 14;
                switch (type) {
                    case 0 -> Fx.spawn(ParticleTypes.SNOWFLAKE, x, p.getY() + 2 + rnd() * 8, z,
                            (rnd() - 0.5) * 0.02, -0.06, (rnd() - 0.5) * 0.02);
                    case 1 -> Fx.spawn(ParticleTypes.CHERRY_LEAVES, x, p.getY() + 3 + rnd() * 7, z,
                            (rnd() - 0.5) * 0.03, -0.04, (rnd() - 0.5) * 0.03);
                    case 2 -> Fx.spawn(ParticleTypes.SMALL_FLAME, x, p.getY() + rnd() * 3, z,
                            (rnd() - 0.5) * 0.01, 0.03, (rnd() - 0.5) * 0.01);
                    case 3 -> Fx.spawn(ParticleTypes.END_ROD, p.getX() + (rnd() * 2 - 1) * 8, p.getY() + rnd() * 3,
                            p.getZ() + (rnd() * 2 - 1) * 8, (rnd() - 0.5) * 0.01, (rnd() - 0.5) * 0.005, (rnd() - 0.5) * 0.01);
                    default -> Fx.spawn(ParticleTypes.WHITE_ASH, x, p.getY() + 2 + rnd() * 8, z,
                            (rnd() - 0.5) * 0.02, -0.03, (rnd() - 0.5) * 0.02);
                }
            }
        }

        if (PTEST.enabled) {
            PTEST.enabled = false;
            PTEST.guiAnim = 0f;
            double yaw = Math.toRadians(p.getYaw());
            double cx = p.getX() - Math.sin(yaw) * 2.0, cz = p.getZ() + Math.cos(yaw) * 2.0;
            for (int k = 0; k < FX.length; k++) {
                for (int i = 0; i < 14; i++) {
                    double a = rnd() * Math.PI * 2;
                    Fx.spawn(FX[k], cx + (k - 2.5) * 0.5, p.getY() + 1.2, cz, Math.cos(a) * 0.05, 0.06 + rnd() * 0.05, Math.sin(a) * 0.05);
                }
            }
            Notifications.push("Particle test sent");
        }

        double speedSq = p.getVelocity().x * p.getVelocity().x + p.getVelocity().z * p.getVelocity().z;
        if (TRAIL.enabled && p.age % 2 == 0 && speedSq > 0.0009) {
            Fx.spawn(FX[HIT_MODE.mode], p.getX(), p.getY() + 0.1, p.getZ(), 0, 0.01, 0);
        }

        boolean onGround = p.isOnGround();
        if (JUMP_FX.enabled && wasOnGround && !onGround && p.getVelocity().y > 0) {
            for (int i = 0; i < 36; i++) {
                double a = i / 36.0 * Math.PI * 2;
                Fx.spawn(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(a) * 0.6, p.getY() + 0.05, p.getZ() + Math.sin(a) * 0.6,
                        Math.cos(a) * 0.04, 0.0, Math.sin(a) * 0.04);
            }
        }
        wasOnGround = onGround;

        if (HALO.enabled) {
            double a = p.age * 0.35;
            double y = p.getY() + p.getStandingEyeHeight() + 0.4;
            for (int k = 0; k < 2; k++) {
                double aa = a + k * Math.PI;
                Fx.spawn(ParticleTypes.END_ROD, p.getX() + Math.cos(aa) * 0.4, y, p.getZ() + Math.sin(aa) * 0.4, 0, 0, 0);
            }
        }

        if (ORBIT.enabled) {
            for (int k = 0; k < 3; k++) {
                double a = p.age * 0.12 + k * 2.094;
                Fx.spawn(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(a) * 0.9, p.getY() + 0.9 + Math.sin(p.age * 0.1 + k) * 0.5,
                        p.getZ() + Math.sin(a) * 0.9, 0, 0, 0);
            }
        }

        if (SWING.mode > 0 && p.handSwinging && p.handSwingTicks > 0 && p.age % (SWING.mode + 1) == 0) {
            p.handSwingTicks--;
        }

        if (lastTarget != null) {
            if (++lastTargetAge > 100) {
                lastTarget = null;
            } else if (lastTarget instanceof LivingEntity le && le.getHealth() <= 0f) {
                if (KILL_FX.enabled) {
                    for (int i = 0; i < 40; i++) {
                        Fx.spawn(ParticleTypes.TOTEM_OF_UNDYING, le.getX(), le.getBodyY(0.5), le.getZ(),
                                (rnd() - 0.5) * 0.5, rnd() * 0.5, (rnd() - 0.5) * 0.5);
                    }
                }
                lastTarget = null;
            }
        }
    }

    private static void trackPickups(ClientPlayerEntity p, long now) {
        Map<Item, Integer> cur = new HashMap<>();
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty()) cur.merge(s.getItem(), s.getCount(), Integer::sum);
        }
        if (invInit) {
            for (Map.Entry<Item, Integer> e : cur.entrySet()) {
                int prev = lastInv.getOrDefault(e.getKey(), 0);
                if (e.getValue() > prev) {
                    PICKUPS.put("+" + (e.getValue() - prev) + " " + e.getKey().getName().getString(), now);
                }
            }
        }
        PICKUPS.values().removeIf(t -> now - t > 5000);
        lastInv = cur;
        invInit = true;
    }

    public static void requestSwap() {
        doSwap(MinecraftClient.getInstance(), false);
    }

    private static void checkResourceWarnings(ClientPlayerEntity p) {
        int totems = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) totems += stack.getCount();
        }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) totems += p.getOffHandStack().getCount();
        boolean nowTotemLow = totems <= 1;
        if (TOTEM_ALERT.enabled && nowTotemLow && !totemLowState) {
            Notifications.push(totems == 0 ? "No totems left" : "Low totems: " + totems);
        }
        totemLowState = TOTEM_ALERT.enabled && nowTotemLow;

        int lowestPercent = 100;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isEmpty() || !stack.isDamageable()) continue;
            int max = stack.getMaxDamage();
            if (max <= 0) continue;
            int percent = Math.max(0, (max - stack.getDamage()) * 100 / max);
            lowestPercent = Math.min(lowestPercent, percent);
        }
        boolean nowDurabilityLow = lowestPercent <= 10;
        if (DURABILITY_ALERT.enabled && nowDurabilityLow && !durabilityLowState) {
            Notifications.push("Gear durability low: " + lowestPercent + "%");
        }
        durabilityLowState = DURABILITY_ALERT.enabled && nowDurabilityLow;
    }

    private static void doSwap(MinecraftClient mc) {
        doSwap(mc, true);
    }

    private static void doSwap(MinecraftClient mc, boolean requireModuleEnabled) {
        if ((requireModuleEnabled && !ITEM_SWAP.enabled) || mc.player == null || mc.interactionManager == null) return;
        if (!ServerGate.allowed(mc)) {
            Notifications.push("Item Swap is not allowed on this server");
            return;
        }
        ClientPlayerEntity p = mc.player;
        Item want = switch (SWAP_ITEM.mode) {
            case 0 -> Items.TOTEM_OF_UNDYING;
            case 1 -> Items.GOLDEN_APPLE;
            case 2 -> Items.ENDER_PEARL;
            default -> Items.SHIELD;
        };
        if (p.getOffHandStack().isOf(want)) return;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getStack(i).isOf(want)) {
                int slot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                return;
            }
        }
        Notifications.push("No " + SWAP_ITEM.modes[SWAP_ITEM.mode] + " to swap");
    }

    private static List<Feature> all() {
        List<Feature> l = new ArrayList<>(FEATURES);
        l.addAll(STYLES);
        return l;
    }

    private static Path slot(int i) {
        return FabricLoader.getInstance().getConfigDir().resolve("aurora_configs").resolve("slot" + i + ".properties");
    }

    public static boolean slotExists(int i) {
        return Files.exists(slot(i));
    }

    public static void saveSlot(int i) {
        try {
            Files.createDirectories(slot(i).getParent());
        } catch (IOException ignored) {
        }
        saveTo(slot(i));
        Notifications.push("Config " + i + " saved");
    }

    public static void loadSlot(int i) {
        if (!slotExists(i)) return;
        loadFrom(slot(i));
        saveConfig();
        Notifications.push("Config " + i + " loaded");
    }

    public static void deleteSlot(int i) {
        try {
            Files.deleteIfExists(slot(i));
        } catch (IOException ignored) {
        }
        Notifications.push("Config " + i + " deleted");
    }

    private static Path cfg() {
        return FabricLoader.getInstance().getConfigDir().resolve("aurora_visuals.properties");
    }

    private static String key(Feature f) {
        return f.name.replace(' ', '_');
    }

    public static void saveConfig() {
        saveTo(cfg());
    }

    private static void saveTo(Path path) {
        Properties p = new Properties();
        for (Feature f : all()) {
            switch (f.type) {
                case TOGGLE -> p.setProperty(key(f), String.valueOf(f.enabled));
                case SLIDER -> p.setProperty(key(f), String.valueOf(f.value));
                case MODE -> p.setProperty(key(f), String.valueOf(f.mode));
            }
        }
        for (HudLayout.El e : HudLayout.ALL.values()) {
            p.setProperty("hud." + e.id + ".dx", String.valueOf(e.dx));
            p.setProperty("hud." + e.id + ".dy", String.valueOf(e.dy));
        }
        p.setProperty("_origFov", String.valueOf(origFov));
        try (Writer w = Files.newBufferedWriter(path)) {
            p.store(w, NAME);
        } catch (IOException ignored) {
        }
    }

    private static void loadConfig() {
        loadFrom(cfg());
    }

    private static void loadFrom(Path path) {
        if (!Files.exists(path)) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(path)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        for (Feature f : all()) {
            String v = p.getProperty(key(f));
            if (v == null) continue;
            try {
                switch (f.type) {
                    case TOGGLE -> { f.enabled = Boolean.parseBoolean(v); f.anim = f.enabled ? 1 : 0; f.guiAnim = f.anim; }
                    case SLIDER -> f.value = Math.max(f.min, Math.min(f.max, Double.parseDouble(v)));
                    case MODE -> f.mode = Math.max(0, Math.min(f.modes.length - 1, Integer.parseInt(v)));
                }
            } catch (NumberFormatException ignored) {
            }
        }
        for (HudLayout.El e : HudLayout.ALL.values()) {
            try {
                e.dx = Integer.parseInt(p.getProperty("hud." + e.id + ".dx", "0"));
                e.dy = Integer.parseInt(p.getProperty("hud." + e.id + ".dy", "0"));
            } catch (NumberFormatException ignored) {
            }
        }
        try {
            origFov = Integer.parseInt(p.getProperty("_origFov", "-1"));
        } catch (NumberFormatException ignored) {
        }
        PTEST.enabled = false;
    }
}
