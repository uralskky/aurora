package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class HudEditorScreen extends Screen {
    private HudLayout.El drag;
    private int grabX, grabY;

    public HudEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    protected void init() {
        HudLayout.editing = true;
        addDrawableChild(new Widgets.PillButton(width / 2 - 70, height - 26, 66, 18, "Done", false, this::close));
        addDrawableChild(new Widgets.PillButton(width / 2 + 4, height - 26, 66, 18, "Reset", true, HudLayout::reset));
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        // keep the HUD sharp: no blur
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0x55000000);
        String t = "HUD Editor: drag elements with the mouse, right click resets one";
        Ui.text(c, t, (width - Ui.width(t)) / 2, 8, 0xFFFFFFFF);
        for (HudLayout.El e : HudLayout.ALL.values()) {
            if (!HudLayout.visible(e)) continue;
            boolean hot = e == drag || (mx >= e.ax && mx < e.ax + e.w && my >= e.ay && my < e.ay + e.h);
            int col = hot ? Colors.aurora(0.2) : Colors.alpha(0xFFFFFF, 120);
            Ui.outline(c, e.ax - 1, e.ay - 1, e.ax + e.w + 1, e.ay + e.h + 1, col);
            int lw = Ui.width(e.name) + 6;
            int ly = e.ay > 12 ? e.ay - 12 : e.ay + e.h + 1;
            Ui.rrect(c, e.ax - 1, ly, e.ax - 1 + lw, ly + 11, 2, Colors.alpha(0x0E0E16, 220));
            Ui.text(c, e.name, e.ax + 2, ly + 2, hot ? 0xFFFFFFFF : 0xFFB8B8CC);
        }
        super.render(c, mx, my, delta);
    }

    private HudLayout.El at(double x, double y) {
        List<HudLayout.El> list = new ArrayList<>(HudLayout.ALL.values());
        for (int i = list.size() - 1; i >= 0; i--) {
            HudLayout.El e = list.get(i);
            if (HudLayout.visible(e) && x >= e.ax && x < e.ax + e.w && y >= e.ay && y < e.ay + e.h) return e;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        HudLayout.El e = at(mouseX, mouseY);
        if (e == null) return false;
        if (button == 1) {
            e.dx = 0;
            e.dy = 0;
            return true;
        }
        if (button == 0) {
            drag = e;
            grabX = (int) (mouseX - e.ax);
            grabY = (int) (mouseY - e.ay);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double offsetX, double offsetY) {
        if (drag != null && button == 0) {
            drag.dx = (int) (mouseX - grabX) - drag.baseX;
            drag.dy = (int) (mouseY - grabY) - drag.baseY;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (drag != null) {
            drag = null;
            AuroraVisuals.saveConfig();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(new AuroraScreen(true));
    }

    @Override
    public void removed() {
        HudLayout.editing = false;
        AuroraVisuals.saveConfig();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
