package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

public final class Ui {
    private Ui() {}

    private static final Style FONT_STYLE =
            Style.EMPTY.withFont(Identifier.of("aurora", "main"));
    private static final Map<String, Text> CACHE = new HashMap<>();

    public static TextRenderer tr() {
        return MinecraftClient.getInstance().textRenderer;
    }

    private static Text t(String s) {
        if (!AuroraVisuals.CUSTOM_FONT.enabled) return Text.literal(s);
        Text c = CACHE.get(s);
        if (c == null) {
            if (CACHE.size() > 900) CACHE.clear();
            c = Text.literal(s).setStyle(FONT_STYLE);
            CACHE.put(s, c);
        }
        return c;
    }

    public static int width(String s) {
        return tr().getWidth(t(s));
    }

    public static String trim(String s, int w) {
        if (width(s) <= w) return s;
        while (s.length() > 1 && width(s + "..") > w) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    public static void rrect(DrawContext c, int x1, int y1, int x2, int y2, int r, int col) {
        if ((col >>> 24) < 2) return;
        if (r <= 0 || y2 - y1 < 2 * r + 1 || x2 - x1 < 2 * r + 1) {
            c.fill(x1, y1, x2, y2, col);
            return;
        }
        c.fill(x1, y1 + r, x2, y2 - r, col);
        for (int i = 0; i < r; i++) {
            int in = r - i;
            c.fill(x1 + in, y1 + i, x2 - in, y1 + i + 1, col);
            c.fill(x1 + in, y2 - i - 1, x2 - in, y2 - i, col);
        }
    }

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }

    public static void text(DrawContext c, String s, int x, int y, int col) {
        if ((col >>> 24) < 8) return;
        c.drawTextWithShadow(tr(), t(s), x, y, col);
    }

    public static void ctext(DrawContext c, String s, int cx, int y, int col) {
        text(c, s, cx - width(s) / 2, y, col);
    }

    public static void gtext(DrawContext c, String s, int x, int y, double off, float a) {
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(c, ch, x, y, Colors.mul(Colors.aurora(off + i * 0.05), a));
            x += width(ch);
        }
    }

    public static void hgrad(DrawContext c, int x1, int y1, int x2, int y2, float a) {
        for (int x = x1; x < x2; x += 4) {
            int xe = Math.min(x2, x + 4);
            c.fill(x, y1, xe, y2, Colors.mul(Colors.aurora((x - x1) * 0.006), a));
        }
    }
}
