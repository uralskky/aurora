Aurora Visuals - Minecraft 1.21.4 / Fabric source port

This is an initial source adaptation from the supplied 1.21.11 project.

Target versions configured:
- Minecraft 1.21.4
- Yarn 1.21.4+build.8
- Fabric Loader 0.16.10
- Fabric API 0.119.2+1.21.4
- Java 21

Important limitations:
- This environment had no network access and no Gradle installation, so dependency resolution and compilation could not be run here.
- The 1.21.4 HUD callback API does not expose the newer element-replacement API used by the original source. The custom HUD is registered using HudRenderCallback; the vanilla hotbar/crosshair may still render underneath custom versions. A further Mixin pass may be needed to fully suppress vanilla elements.
- Mixin targets and any other version-sensitive methods must be verified by building and launching against a real 1.21.4 Fabric development environment.

Build using Gradle with Java 21 and an internet connection. If compilation reports errors, use the first error in the Gradle output as the next compatibility fix.

Changes in this pass:
- Enlarged the Aurora menu with an adaptive layout and subtle accent line/shadow polish inspired by modern visual-client menus.
- Renamed the Player toggle to Auto Swap; G triggers the configured swap when enabled.
- Added a visible “Swap Now” button in the Player tab. It performs a one-time swap even if the G hotkey toggle is off.
- The existing “Swap Item” mode cycles between Totem, Golden Apple, Ender Pearl and Shield.
- Added notifications when the item is already equipped, a swap succeeds, or no matching item is found.

The one-click action retains the source project's server restriction (singleplayer, FunTime, and SkyTime). The project still requires a real Gradle build and in-game test before it can be considered verified.
