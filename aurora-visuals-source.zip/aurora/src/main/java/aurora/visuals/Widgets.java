package aurora.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class Widgets {
    private Widgets() {}

    public static class RowToggle extends ButtonWidget {
        final Feature f;

        public RowToggle(int x, int y, int w, int h, Feature f) {
            super(x, y, w, h, Text.literal(f.name), b -> {
                if (f.type == Feature.Type.TOGGLE) f.toggle();
                else f.cycle();
            }, DEFAULT_NARRATION_SUPPLIER);
            this.f = f;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            boolean hov = isHovered();
            if (hov) AuroraScreen.hover = f;
            float target = (f.type == Feature.Type.TOGGLE && f.enabled) ? 1f : 0f;
            f.guiAnim += (target - f.guiAnim) * AuroraScreen.step(12f);

            Ui.rrect(c, x, y, x + w, y + h, 3, Colors.mul(hov ? 0xFF2A2A3D : 0xFF1C1C29, a));
            if (f.guiAnim > 0.03f) {
                Ui.rrect(c, x, y + 3, x + 2, y + h - 3, 1, Colors.mul(Colors.aurora(y * 0.01), a * f.guiAnim));
            }
            Ui.text(c, f.name, x + 8, y + (h - 8) / 2, Colors.mul(0xFFEDEDF7, a));

            if (f.type == Feature.Type.TOGGLE) {
                int sw = 20, sh = 10;
                int sx = x + w - sw - 7, sy = y + (h - sh) / 2;
                int track = Colors.lerp(0xFF3B3B4E, Colors.aurora(y * 0.01), f.guiAnim);
                Ui.rrect(c, sx, sy, sx + sw, sy + sh, 4, Colors.mul(track, a));
                int kx = sx + 2 + Math.round(f.guiAnim * 10f);
                Ui.rrect(c, kx, sy + 2, kx + 6, sy + 8, 2, Colors.mul(0xFFFFFFFF, a));
            } else {
                String t = f.valueText();
                int tw = Ui.width(t);
                Ui.rrect(c, x + w - tw - 14, y + 3, x + w - 4, y + h - 3, 3, Colors.mul(0xFF2B2B3F, a));
                Ui.text(c, t, x + w - tw - 9, y + (h - 8) / 2, Colors.mul(Colors.aurora(0.3), a));
            }
        }
    }

    public static class RowSlider extends SliderWidget {
        final Feature f;

        public RowSlider(int x, int y, int w, int h, Feature f) {
            super(x, y, w, h, Text.empty(), (f.value - f.min) / (f.max - f.min));
            this.f = f;
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(f == null ? "" : f.name));
        }

        @Override
        protected void applyValue() {
            double v = f.min + (f.max - f.min) * this.value;
            if (f.integer) v = Math.round(v);
            f.value = v;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            boolean hov = isHovered();
            if (hov) AuroraScreen.hover = f;
            Ui.rrect(c, x, y, x + w, y + h, 3, Colors.mul(hov ? 0xFF2A2A3D : 0xFF1C1C29, a));
            Ui.text(c, f.name, x + 8, y + 3, Colors.mul(0xFFEDEDF7, a));
            String t = f.valueText();
            Ui.text(c, t, x + w - Ui.width(t) - 8, y + 3, Colors.mul(Colors.aurora(0.3), a));
            double n = (f.value - f.min) / (f.max - f.min);
            int bx1 = x + 8, bx2 = x + w - 8, by = y + h - 6;
            Ui.rrect(c, bx1, by, bx2, by + 3, 1, Colors.mul(0xFF383849, a));
            int fx = bx1 + (int) ((bx2 - bx1) * n);
            Ui.hgrad(c, bx1, by, Math.max(bx1 + 1, fx), by + 3, a);
            Ui.rrect(c, fx - 2, by - 2, fx + 2, by + 5, 1, Colors.mul(0xFFFFFFFF, a));
        }
    }

    public static class CatButton extends ButtonWidget {
        final String cat;
        float anim;

        public CatButton(int x, int y, int w, int h, String cat) {
            super(x, y, w, h, Text.literal(cat), b -> {
                AuroraScreen.selected = cat;
                net.minecraft.client.MinecraftClient.getInstance().setScreen(new AuroraScreen(false));
            }, DEFAULT_NARRATION_SUPPLIER);
            this.cat = cat;
            this.anim = cat.equals(AuroraScreen.selected) ? 1f : 0f;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            boolean sel = cat.equals(AuroraScreen.selected);
            anim += ((sel ? 1f : 0f) - anim) * AuroraScreen.step(14f);
            int bg = Colors.lerp(isHovered() ? 0xFF1F1F2D : 0xFF151520, 0xFF2A2A40, anim);
            Ui.rrect(c, x, y, x + w, y + h, 3, Colors.mul(bg, a));
            if (anim > 0.03f) {
                Ui.rrect(c, x, y + 4, x + 2, y + h - 4, 1, Colors.mul(Colors.aurora(0.2), a * anim));
            }
            Ui.rrect(c, x + 6, y + 4, x + 18, y + h - 4, 3, Colors.mul(Colors.lerp(0xFF2B2B3D, Colors.aurora(0.1), anim), a));
            Ui.text(c, cat.substring(0, 1), x + 10, y + (h - 8) / 2, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, cat, x + 24, y + (h - 8) / 2, Colors.mul(sel ? 0xFFFFFFFF : 0xFFA8A8BE, a));
        }
    }

    public static class CloseButton extends ButtonWidget {
        public CloseButton(int x, int y, int s, AuroraScreen screen) {
            super(x, y, s, s, Text.literal("x"), b -> screen.close(), DEFAULT_NARRATION_SUPPLIER);
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            Ui.rrect(c, x, y, x + w, y + h, 3, Colors.mul(isHovered() ? 0xFF5A2A35 : 0xFF2B2B3D, a));
            Ui.text(c, "x", x + (w - 5) / 2, y + (h - 8) / 2, Colors.mul(0xFFFFFFFF, a));
        }
    }

    public static class StylePill extends ButtonWidget {
        final Feature style;

        public StylePill(int x, int y, int w, int h, Feature style) {
            super(x, y, w, h, Text.literal(style.name), b -> style.cycle(), DEFAULT_NARRATION_SUPPLIER);
            this.style = style;
        }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            float a = AuroraScreen.alpha();
            boolean hov = isHovered();
            if (hov) AuroraScreen.hoverTip = style.name + ": tap to change the look of this element";
            Ui.rrect(c, x, y, x + w, y + h, 3, Colors.mul(hov ? 0xFF34344C : 0xFF25253A, a));
            Ui.hgrad(c, x + 3, y + h - 2, x + w - 3, y + h - 1, a * 0.8f);
            String t = style.modes[style.mode];
            Ui.text(c, t, x + (w - Ui.width(t)) / 2, y + (h - 8) / 2, Colors.mul(0xFFFFFFFF, a));
        }
    }
}
