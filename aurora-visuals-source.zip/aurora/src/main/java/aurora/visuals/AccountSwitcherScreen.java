package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/** Local/offline profile manager. Offline profiles are intended for single-player and servers that permit them. */
public final class AccountSwitcherScreen extends Screen {
    private final Screen parent;
    private final List<String> profiles = new ArrayList<>();
    private String input = "";
    private String message = "Add a username, then select a profile";
    private int scroll;
    private static final Path FILE = net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("aurora-accounts.properties");

    public AccountSwitcherScreen(Screen parent) {
        super(Text.literal("Aurora Account Switcher"));
        this.parent = parent;
        load();
    }

    private void load() {
        profiles.clear();
        Properties p = new Properties();
        if (Files.exists(FILE)) try (var r = Files.newBufferedReader(FILE)) { p.load(r); } catch (IOException ignored) {}
        int count = Integer.parseInt(p.getProperty("count", "0").replaceAll("[^0-9]", ""));
        for (int i = 0; i < Math.min(count, 100); i++) {
            String name = p.getProperty("profile." + i, "").trim();
            if (name.matches("[A-Za-z0-9_]{1,16}") && !profiles.contains(name)) profiles.add(name);
        }
    }

    private void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Properties p = new Properties();
            p.setProperty("count", Integer.toString(profiles.size()));
            for (int i = 0; i < profiles.size(); i++) p.setProperty("profile." + i, profiles.get(i));
            try (var w = Files.newBufferedWriter(FILE)) { p.store(w, "Aurora offline profiles; no passwords or tokens are stored"); }
        } catch (IOException e) { message = "Could not save profiles"; }
    }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0xE9080B12);
        Ui.hgrad(c, 0, 0, width, 2, 1f);
        Ui.text(c, "ACCOUNT SWITCHER", width / 2 - 68, 24, 0xFFFFFFFF);
        Ui.text(c, "OFFLINE PROFILES", width / 2 - 56, 46, 0xFF8D96B5);
        int x = width / 2 - 125, y = 72;
        Ui.rrect(c, x, y, x + 250, y + 24, 5, 0xFF171C28);
        Ui.outline(c, x, y, x + 250, y + 24, 0xFF343B50);
        Ui.text(c, input.isEmpty() ? "Type username (1-16 chars)" : input + "_", x + 9, y + 8, input.isEmpty() ? 0xFF737D98 : 0xFFFFFFFF);
        button(c, x + 170, y + 34, 80, 22, "Add profile", mx, my, true);
        Ui.text(c, message, x, y + 63, 0xFF9CA6C1);
        int listY = y + 88;
        for (int i = scroll; i < Math.min(profiles.size(), scroll + 7); i++) {
            int ry = listY + (i - scroll) * 25;
            boolean hov = mx >= x && mx < x + 250 && my >= ry && my < ry + 22;
            Ui.rrect(c, x, ry, x + 250, ry + 22, 4, hov ? 0xFF272E40 : 0xFF151923);
            Ui.text(c, profiles.get(i), x + 10, ry + 7, 0xFFE7EAF5);
            Ui.text(c, "USE", x + 190, ry + 7, 0xFF9F8BFF);
            Ui.text(c, "×", x + 232, ry + 5, 0xFFCF8D9D);
        }
        button(c, width / 2 - 48, height - 42, 96, 26, "Back", mx, my, false);
        super.render(c, mx, my, delta);
    }

    private void button(DrawContext c, int x, int y, int w, int h, String s, int mx, int my, boolean accent) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        Ui.rrect(c, x, y, x + w, y + h, 5, accent ? (hov ? 0xFF7864E8 : 0xFF5947B7) : (hov ? 0xFF30374B : 0xFF202636));
        Ui.ctext(c, s, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        int x = width / 2 - 125, y = 72;
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        if (click.y() >= y + 34 && click.y() < y + 56 && click.x() >= x + 170 && click.x() < x + 250) {
            if (input.matches("[A-Za-z0-9_]{1,16}")) {
                if (!profiles.contains(input)) profiles.add(input);
                save(); message = "Profile saved locally: " + input; input = "";
            } else message = "Use 1–16 letters, numbers or underscores";
            return true;
        }
        int listY = y + 88;
        if (click.x() >= x && click.x() < x + 250 && click.y() >= listY && click.y() < listY + 175) {
            int index = scroll + (int) ((click.y() - listY) / 25);
            if (index >= 0 && index < profiles.size()) {
                int localX = (int) click.x() - x;
                if (localX >= 225) { profiles.remove(index); save(); message = "Profile removed"; }
                else if (localX >= 175) { activate(profiles.get(index)); }
                return true;
            }
        }
        if (click.y() >= height - 42 && click.y() < height - 16) { client.setScreen(parent); return true; }
        return true;
    }

    private void activate(String name) {
        try {
            Class<?> sessionClass = Class.forName("net.minecraft.client.session.Session");
            Object session = null;
            for (Constructor<?> ctor : sessionClass.getDeclaredConstructors()) {
                Class<?>[] types = ctor.getParameterTypes();
                Object[] args = new Object[types.length];
                boolean supported = true;
                int stringIndex = 0;
                for (int i = 0; i < types.length; i++) {
                    Class<?> t = types[i];
                    if (t == String.class) args[i] = stringIndex++ == 0 ? name : "";
                    else if (t == UUID.class) args[i] = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    else if (t.getName().equals("java.util.Optional")) args[i] = java.util.Optional.empty();
                    else if (t.isEnum()) {
                        Object[] constants = t.getEnumConstants();
                        Object chosen = null;
                        for (Object constant : constants) if (constant.toString().equalsIgnoreCase("LEGACY") || constant.toString().equalsIgnoreCase("OFFLINE")) { chosen = constant; break; }
                        if (chosen == null && constants.length > 0) chosen = constants[0];
                        args[i] = chosen;
                    } else { supported = false; break; }
                }
                if (supported) try { ctor.setAccessible(true); session = ctor.newInstance(args); break; } catch (ReflectiveOperationException ignored) {}
            }
            if (session == null) { message = "This Minecraft build does not expose a compatible offline session constructor"; return; }
            Field target = null;
            for (Field f : MinecraftClient.class.getDeclaredFields()) if (f.getType() == sessionClass && f.getName().toLowerCase().contains("session")) { target = f; break; }
            if (target == null) for (Field f : MinecraftClient.class.getDeclaredFields()) if (f.getType() == sessionClass) { target = f; break; }
            if (target == null) { message = "Could not find the session field; restart and try again"; return; }
            target.setAccessible(true);
            target.set(client, session);
            message = "Switched local session to " + name + " (some servers reject offline profiles)";
        } catch (Throwable e) { message = "Switch failed: " + e.getClass().getSimpleName(); }
    }

    @Override public boolean charTyped(CharInput inputEvent) {
        String typed = inputEvent.asString();
        if (inputEvent.isValidChar() && !typed.isEmpty() && input.length() + typed.length() <= 16
                && typed.chars().allMatch(ch -> Character.isLetterOrDigit(ch) || ch == '_')) {
            input += typed;
        }
        return true;
    }

    @Override public boolean keyPressed(KeyInput inputEvent) {
        int keyCode = inputEvent.key();
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { client.setScreen(parent); return true; }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) { input = input.substring(0, input.length() - 1); return true; }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            if (input.matches("[A-Za-z0-9_]{1,16}") && !profiles.contains(input)) {
                profiles.add(input); save(); input = ""; message = "Profile saved";
            }
            return true;
        }
        return super.keyPressed(inputEvent);
    }
    @Override public boolean shouldCloseOnEsc() { return false; }
}
