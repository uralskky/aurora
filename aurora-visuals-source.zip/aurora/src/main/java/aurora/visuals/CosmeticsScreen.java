package aurora.visuals;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Local cosmetic preferences and preview panel. Cosmetic assets can be added without changing the menu model. */
public final class CosmeticsScreen extends Screen {
    private final Screen parent;
    private static final String[] ITEMS = {"Wings", "Hats & accessories", "Capes"};
    private static final String[] KEYS = {"wings", "accessories", "capes"};
    private final boolean[] enabled = new boolean[ITEMS.length];
    private int selected;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("aurora-cosmetics.properties");

    public CosmeticsScreen(Screen parent) {
        super(Text.literal("Aurora Cosmetics")); this.parent = parent;
        Properties p = new Properties();
        if (Files.exists(FILE)) try (var r = Files.newBufferedReader(FILE)) { p.load(r); } catch (IOException ignored) {}
        for (int i = 0; i < KEYS.length; i++) enabled[i] = Boolean.parseBoolean(p.getProperty(KEYS[i], "false"));
    }
    private void save() {
        Properties p = new Properties(); for (int i = 0; i < KEYS.length; i++) p.setProperty(KEYS[i], Boolean.toString(enabled[i]));
        try { Files.createDirectories(FILE.getParent()); try (var w = Files.newBufferedWriter(FILE)) { p.store(w, "Aurora cosmetic preferences"); } } catch (IOException ignored) {}
    }
    @Override public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0xE9080B12); Ui.hgrad(c, 0, 0, width, 2, 1f);
        Ui.text(c, "COSMETICS", width / 2 - 37, 24, 0xFFFFFFFF);
        Ui.text(c, "PERSONAL STYLE", width / 2 - 43, 43, 0xFF8D96B5);
        int x = width / 2 - 145, y = 70;
        for (int i = 0; i < ITEMS.length; i++) {
            int ry = y + i * 34; boolean hov = mx >= x && mx < x + 290 && my >= ry && my < ry + 28;
            Ui.rrect(c, x, ry, x + 290, ry + 28, 5, selected == i ? 0xFF292441 : hov ? 0xFF242A3A : 0xFF151923);
            Ui.text(c, ITEMS[i], x + 12, ry + 10, 0xFFE7EAF5);
            Ui.rrect(c, x + 246, ry + 8, x + 278, ry + 21, 6, enabled[i] ? 0xFF7661E7 : 0xFF363C4D);
            Ui.rrect(c, x + (enabled[i] ? 263 : 248), ry + 10, x + (enabled[i] ? 276 : 261), ry + 19, 4, 0xFFFFFFFF);
        }
        int py = y + 124;
        Ui.rrect(c, x, py, x + 290, py + 78, 6, 0xA0121722);
        Ui.text(c, "PREVIEW", x + 12, py + 10, 0xFFB7A9FF);
        Ui.ctext(c, selected == 0 ? "WINGS" : selected == 1 ? "ACCESSORIES" : "CAPE", x + 145, py + 30, enabled[selected] ? 0xFFFFFFFF : 0xFF626B84);
        Ui.ctext(c, enabled[selected] ? "Selected in local preferences" : "Disabled", x + 145, py + 49, 0xFF929BB4);
        Ui.text(c, "Cosmetic rendering requires player-render hooks and assets.", x, py + 88, 0xFF747F9B);
        Ui.text(c, "These toggles save your choices; they do not add visible models yet.", x, py + 101, 0xFF747F9B);
        Ui.rrect(c, width / 2 - 45, height - 40, width / 2 + 45, height - 14, 5, 0xFF242A3A);
        Ui.ctext(c, "Back", width / 2, height - 31, 0xFFFFFFFF);
        super.render(c, mx, my, delta);
    }
    @Override public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        int x = width / 2 - 145, y = 70;
        for (int i = 0; i < ITEMS.length; i++) if (click.x() >= x && click.x() < x + 290 && click.y() >= y + i * 34 && click.y() < y + i * 34 + 28) {
            selected = i; enabled[i] = !enabled[i]; save(); return true;
        }
        if (click.y() >= height - 40 && click.y() < height - 14) { client.setScreen(parent); return true; }
        return true;
    }
    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) { if (keyCode == 256) { client.setScreen(parent); return true; } return super.keyPressed(keyCode, scanCode, modifiers); }
}
