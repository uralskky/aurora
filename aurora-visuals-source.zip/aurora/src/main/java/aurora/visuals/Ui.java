package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Ui {
    private Ui() {}

    public static TextRenderer tr() {
        return MinecraftClient.getInstance().textRenderer;
    }

    public static int width(String s) {
        return tr().getWidth(s);
    }

    public static void rrect(DrawContext c, int x1, int y1, int x2, int y2, int r, int col) {
        if ((col >>> 24) < 2) return;
        if (r <= 0 || y2 - y1 < 2 * r + 1 || x2 - x1 < 2 * r + 1) {
            c.fill(x1, y1, x2, y2, col);
            return;
        }
        c.fill(x1, y1 + r, x2, y2 - r, col);
        for (int i = 0; i < r; i++) {
            int in = r - i;
            c.fill(x1 + in, y1 + i, x2 - in, y1 + i + 1, col);
            c.fill(x1 + in, y2 - i - 1, x2 - in, y2 - i, col);
        }
    }

    public static void text(DrawContext c, String s, int x, int y, int col) {
        if ((col >>> 24) < 8) return;
        c.drawTextWithShadow(tr(), s, x, y, col);
    }

    public static void gtext(DrawContext c, String s, int x, int y, double off, float a) {
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(c, ch, x, y, Colors.mul(Colors.aurora(off + i * 0.05), a));
            x += width(ch);
        }
    }

    public static void hgrad(DrawContext c, int x1, int y1, int x2, int y2, float a) {
        for (int x = x1; x < x2; x += 4) {
            int xe = Math.min(x2, x + 4);
            c.fill(x, y1, xe, y2, Colors.mul(Colors.aurora((x - x1) * 0.006), a));
        }
    }
}
