package aurora.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class AuroraScreen extends Screen {
    public static final String[] CATS = {"HUD", "Combat", "Player", "World", "Effects", "Theme"};
    public static String selected = "HUD";
    public static Feature hover;
    public static String hoverTip;
    private static long openTime;
    private static long lastNs = System.nanoTime();
    private static float dt = 0.016f;

    private int px, py, pw, ph, sbW;

    public AuroraScreen(boolean animate) {
        super(Text.literal(AuroraVisuals.NAME));
        if (animate) openTime = System.currentTimeMillis();
    }

    public static float alpha() {
        float t = (System.currentTimeMillis() - openTime) / 220f;
        t = Math.max(0f, Math.min(1f, t));
        return 1f - (1f - t) * (1f - t);
    }

    public static float step(float speed) {
        return Math.min(1f, dt * speed);
    }

    @Override
    protected void init() {
        pw = Math.min(width - 12, 430);
        ph = Math.min(height - 12, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        sbW = Math.min(92, pw / 4);

        int stepY = Math.min(23, (ph - 44) / CATS.length);
        int y = py + 36;
        for (String cat : CATS) {
            addDrawableChild(new Widgets.CatButton(px + 6, y, sbW - 8, stepY - 3, cat));
            y += stepY;
        }
        addDrawableChild(new Widgets.CloseButton(px + pw - 22, py + 6, 16, this));

        List<Feature> list = new ArrayList<>();
        for (Feature f : AuroraVisuals.FEATURES) if (f.category.equals(selected)) list.add(f);

        int cx = px + sbW + 6, cw = pw - sbW - 12;
        int top = py + 34, bottom = py + ph - 18;
        int rowH = 22, gap = 3;
        int per = Math.max(1, (bottom - top + gap) / (rowH + gap));
        int cols = (list.size() + per - 1) / per;
        if (cols > 2) {
            rowH = 18; gap = 2;
            per = Math.max(1, (bottom - top + gap) / (rowH + gap));
            cols = (list.size() + per - 1) / per;
        }
        cols = Math.max(1, cols);
        int colW = (cw - (cols - 1) * 4) / cols;
        for (int i = 0; i < list.size(); i++) {
            Feature f = list.get(i);
            int x = cx + (i / per) * (colW + 4);
            int yy = top + (i % per) * (rowH + gap);
            if (f.type == Feature.Type.SLIDER) {
                addDrawableChild(new Widgets.RowSlider(x, yy, colW, rowH, f));
            } else if (f.style != null) {
                int pillW = 54;
                addDrawableChild(new Widgets.RowToggle(x, yy, colW - pillW - 3, rowH, f));
                addDrawableChild(new Widgets.StylePill(x + colW - pillW, yy, pillW, rowH, f.style));
            } else {
                addDrawableChild(new Widgets.RowToggle(x, yy, colW, rowH, f));
            }
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        hover = null;
        hoverTip = null;
        float a = alpha();

        Ui.rrect(c, px - 2, py - 2, px + pw + 2, py + ph + 2, 5, Colors.mul(0x70000000, a));
        Ui.rrect(c, px, py, px + pw, py + ph, 4, Colors.mul(0xF20C0C14, a));
        Ui.rrect(c, px, py, px + sbW, py + ph, 4, Colors.mul(0xFF11111B, a));
        Ui.hgrad(c, px + 4, py, px + pw - 4, py + 2, a);

        Ui.gtext(c, AuroraVisuals.NAME, px + 10, py + 11, 0, a);
        Ui.text(c, "v2", px + 10 + Ui.width(AuroraVisuals.NAME) + 5, py + 11, Colors.mul(0xFF77778F, a));

        super.render(c, mx, my, delta);

        String foot = hoverTip != null ? hoverTip : hover != null ? hover.desc : "RShift or /aurora opens this menu. Tap the style pill to change a theme.";
        Ui.text(c, foot, px + sbW + 8, py + ph - 12, Colors.mul(0xFF8C8CA6, a));
    }

    @Override
    public void removed() {
        AuroraVisuals.saveConfig();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
