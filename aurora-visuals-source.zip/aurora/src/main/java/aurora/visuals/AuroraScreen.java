package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Column ClickGUI: five translucent panels, each a scrollable list of modules with inline settings. */
public class AuroraScreen extends Screen {
    // kept for the older widgets that still reference them
    public static String selected = "HUD";
    public static Feature hover;
    public static String hoverTip;

    private static long openTime;
    private static long catStart;
    private static long lastNs = System.nanoTime();
    private static float dt = 0.016f;

    private static final String[] PANEL_NAMES = {"Combat", "Movement", "Render", "HUD", "Misc"};
    private static final List<List<Feature>> PANELS = new ArrayList<>();
    private static final Map<Feature, List<Feature>> KIDS = new HashMap<>();
    private static final Set<Feature> OPEN = new HashSet<>();
    private static final int[] SCROLL = new int[5];

    static {
        PANELS.add(List.of(AuroraVisuals.TARGET_HUD, AuroraVisuals.HIT_FX, AuroraVisuals.HIT_SOUND, AuroraVisuals.KILL_FX,
                AuroraVisuals.TARGET_ESP, AuroraVisuals.PREDICTION, AuroraVisuals.CROSSHAIR, AuroraVisuals.COMBAT_INFO));
        PANELS.add(List.of(AuroraVisuals.AUTO_SPRINT, AuroraVisuals.JUMP_FX, AuroraVisuals.TRAIL,
                AuroraVisuals.ZOOM, AuroraVisuals.FOV_ON));
        PANELS.add(List.of(AuroraVisuals.FULLBRIGHT, AuroraVisuals.VIEW_MODEL, AuroraVisuals.SWING_ANIM, AuroraVisuals.SWING,
                AuroraVisuals.BODY_GLOW, AuroraVisuals.CHINA_HAT, AuroraVisuals.HALO, AuroraVisuals.ORBIT,
                AuroraVisuals.WEATHER, AuroraVisuals.OPTIMIZATION));
        PANELS.add(List.of(AuroraVisuals.WATERMARK, AuroraVisuals.MODULE_LIST, AuroraVisuals.INFO, AuroraVisuals.POTIONS,
                AuroraVisuals.KEYSTROKES, AuroraVisuals.ARMOR, AuroraVisuals.INVENTORY, AuroraVisuals.COUNTER,
                AuroraVisuals.HOTBAR_ANIM, AuroraVisuals.GLASS_BARS, AuroraVisuals.TOTEM_BAR, AuroraVisuals.SESSION));
        PANELS.add(List.of(AuroraVisuals.AUTO_RESPAWN, AuroraVisuals.ITEM_SWAP, AuroraVisuals.TNT_TIMER,
                AuroraVisuals.PICKUP_LOG, AuroraVisuals.NOTIFY, AuroraVisuals.PTEST, AuroraVisuals.THEME,
                AuroraVisuals.COLOR_SPEED, AuroraVisuals.HUD_ALPHA, AuroraVisuals.CUSTOM_FONT, AuroraVisuals.CUSTOM_MENU));
        kids(AuroraVisuals.HIT_FX, AuroraVisuals.HIT_MODE);
        kids(AuroraVisuals.TARGET_ESP, AuroraVisuals.ESP_STYLE);
        kids(AuroraVisuals.CROSSHAIR, AuroraVisuals.CROSS_STYLE);
        kids(AuroraVisuals.ZOOM, AuroraVisuals.ZOOM_FOV);
        kids(AuroraVisuals.FOV_ON, AuroraVisuals.FOV);
        kids(AuroraVisuals.VIEW_MODEL, AuroraVisuals.VM_X, AuroraVisuals.VM_Y, AuroraVisuals.VM_Z, AuroraVisuals.VM_SCALE);
        kids(AuroraVisuals.WEATHER, AuroraVisuals.WEATHER_TYPE, AuroraVisuals.WEATHER_AMOUNT);
        kids(AuroraVisuals.ITEM_SWAP, AuroraVisuals.SWAP_ITEM);
    }

    private static void kids(Feature parent, Feature... k) {
        List<Feature> l = new ArrayList<>();
        for (Feature f : k) l.add(f);
        KIDS.put(parent, l);
    }

    private static boolean hasKids(Feature f) {
        return KIDS.containsKey(f) || f.style != null;
    }

    private static final class Hit {
        int x, y, w, h, act, bx1, bx2;
        Feature f;
        String tip;
    }

    private final List<Hit> hits = new ArrayList<>();
    private final int[] content = new int[5];
    private final int[] view = new int[5];
    private int pnlW, pnlH, left, top, gap = 4;
    private Feature dragF;
    private int dragX1, dragX2;

    public AuroraScreen(boolean animate) {
        super(Text.literal(AuroraVisuals.NAME));
        if (animate) openTime = System.currentTimeMillis();
        catStart = System.currentTimeMillis();
    }

    public static float alpha() {
        return Colors.ease((System.currentTimeMillis() - openTime) / 220f);
    }

    public static float rowAnim(int index) {
        return Colors.ease((System.currentTimeMillis() - catStart - index * 30L) / 220f);
    }

    public static float step(float speed) {
        return Math.min(1f, dt * speed);
    }

    @Override
    protected void init() {
        int n = PANEL_NAMES.length;
        pnlW = Math.max(80, Math.min(116, (width - 24) / n - gap));
        pnlH = Math.max(120, Math.min(height - 70, 210));
        int total = n * pnlW + (n - 1) * gap;
        left = (width - total) / 2;
        top = Math.max(22, (height - pnlH) / 2 - 8);
    }

    private static Hit hit(int x, int y, int w, int h, int act, Feature f) {
        Hit t = new Hit();
        t.x = x; t.y = y; t.w = w; t.h = h; t.act = act; t.f = f;
        return t;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long nn = System.nanoTime();
        dt = Math.min(0.1f, (nn - lastNs) / 1e9f);
        lastNs = nn;
        hits.clear();
        hover = null;
        hoverTip = null;

        super.render(c, mx, my, delta);
        float a = alpha();
        int slide = (int) ((1f - a) * 10f);

        for (int i = 0; i < PANEL_NAMES.length; i++) {
            drawPanel(c, i, left + i * (pnlW + gap), top + slide, a, mx, my);
        }

        // bottom bar
        int bw = 250, bh = 18;
        int bx = (width - bw) / 2, by = top + pnlH + 10 + slide;
        Ui.rrect(c, bx, by, bx + bw, by + bh, 6, Colors.mul(0xB0121419, a));
        Ui.outline(c, bx, by, bx + bw, by + bh, Colors.mul(0x18FFFFFF, a));
        Ui.text(c, "Configs", bx + 8, by + 5, Colors.mul(0xFF8E96B4, a));
        for (int i = 1; i <= 5; i++) {
            int cx = bx + 54 + (i - 1) * 20;
            boolean ex = AuroraVisuals.slotExists(i);
            boolean hv = mx >= cx && mx < cx + 16 && my >= by + 3 && my < by + 15;
            Ui.rrect(c, cx, by + 3, cx + 16, by + 15, 3,
                    Colors.mul(ex ? Colors.lerp(0xFF2A2F3E, Colors.aurora(i * 0.3), hv ? 0.9 : 0.6) : (hv ? 0xFF2F3548 : 0xFF222737), a));
            Ui.text(c, String.valueOf(i), cx + 5, by + 5, Colors.mul(0xFFFFFFFF, a));
            Hit h = hit(cx, by + 3, 16, 12, 10 + i, null);
            h.tip = "Config " + i + ": left click loads (or saves if empty), right click saves";
            hits.add(h);
            if (hv) hoverTip = h.tip;
        }
        int ex0 = bx + bw - 62;
        boolean hvE = mx >= ex0 && mx < ex0 + 54 && my >= by + 3 && my < by + 15;
        Ui.rrect(c, ex0, by + 3, ex0 + 54, by + 15, 3, Colors.mul(hvE ? 0xFF343B52 : 0xFF222737, a));
        Ui.ctext(c, "Edit HUD", ex0 + 27, by + 5, Colors.mul(0xFFFFFFFF, a));
        Hit he = hit(ex0, by + 3, 54, 12, 20, null);
        he.tip = "Drag every HUD element where you want it";
        hits.add(he);
        if (hvE) hoverTip = he.tip;

        String tip = hoverTip != null ? hoverTip : hover != null ? hover.desc : null;
        if (tip != null) {
            int tw = Ui.width(tip) + 16;
            int tx = (width - tw) / 2, ty = Math.max(4, top - 18) + slide;
            Ui.rrect(c, tx, ty, tx + tw, ty + 14, 5, Colors.mul(0xC0121419, a));
            Ui.text(c, tip, tx + 8, ty + 3, Colors.mul(0xFFE8EAF4, a));
        }
    }

    private void drawPanel(DrawContext c, int i, int x, int y, float a, int mx, int my) {
        int accent = Colors.aurora(i * 0.35);
        Ui.rrect(c, x, y, x + pnlW, y + pnlH, 6, Colors.mul(0xB0121419, a));
        Ui.outline(c, x, y, x + pnlW, y + pnlH, Colors.mul(0x18FFFFFF, a));

        List<Feature> list = PANELS.get(i);
        int on = 0;
        for (Feature f : list) if (f.type == Feature.Type.TOGGLE && f.enabled) on++;
        Ui.text(c, PANEL_NAMES[i], x + 8, y + 6, Colors.mul(0xFFFFFFFF, a));
        String cnt = String.valueOf(on);
        Ui.text(c, cnt, x + pnlW - 8 - Ui.width(cnt), y + 6, Colors.mul(accent, a));
        c.fill(x + 6, y + 18, x + pnlW - 6, y + 19, Colors.mul(Colors.alpha(accent, 90), a));

        int vy0 = y + 22, vy1 = y + pnlH - 4;
        view[i] = vy1 - vy0;
        int cur = vy0 - SCROLL[i];
        int rx = x + 4, rw = pnlW - 8;

        for (Feature f : list) {
            int rh = f.type == Feature.Type.SLIDER ? 20 : 14;
            if (cur >= vy0 && cur + rh <= vy1) drawRow(c, f, rx, cur, rw, rh, a, mx, my, accent, false);
            cur += rh;
            if (OPEN.contains(f) && hasKids(f)) {
                List<Feature> subs = new ArrayList<>();
                if (f.style != null) subs.add(f.style);
                List<Feature> k = KIDS.get(f);
                if (k != null) subs.addAll(k);
                for (Feature s : subs) {
                    int sh = s.type == Feature.Type.SLIDER ? 20 : 14;
                    if (cur >= vy0 && cur + sh <= vy1) drawRow(c, s, rx + 5, cur, rw - 5, sh, a, mx, my, accent, true);
                    cur += sh;
                }
            }
        }
        content[i] = cur - (vy0 - SCROLL[i]);
        int maxScroll = Math.max(0, content[i] - view[i]);
        if (SCROLL[i] > maxScroll) SCROLL[i] = maxScroll;
        if (maxScroll > 0) {
            int trackH = view[i];
            int barH = Math.max(10, trackH * view[i] / content[i]);
            int barY = vy0 + (int) ((trackH - barH) * (SCROLL[i] / (double) maxScroll));
            Ui.rrect(c, x + pnlW - 3, barY, x + pnlW - 1, barY + barH, 1, Colors.mul(Colors.alpha(accent, 150), a));
        }
    }

    private void drawRow(DrawContext c, Feature f, int x, int y, int w, int h, float a, int mx, int my, int accent, boolean sub) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        if (hov) hover = f;
        if (f.type == Feature.Type.TOGGLE) {
            f.guiAnim += ((f.enabled ? 1f : 0f) - f.guiAnim) * step(14f);
        }
        if (hov) Ui.rrect(c, x, y, x + w, y + h, 3, Colors.mul(0x22FFFFFF, a));
        else if (sub) Ui.rrect(c, x, y, x + w, y + h, 3, Colors.mul(0x12FFFFFF, a));

        if (f.type == Feature.Type.TOGGLE) {
            Ui.text(c, f.name, x + 6, y + (h - 8) / 2, Colors.mul(Colors.lerp(0xFF8F97B5, 0xFFFFFFFF, f.guiAnim), a));
            int sx = x + w - 20, sy = y + (h - 8) / 2;
            Ui.rrect(c, sx, sy, sx + 16, sy + 8, 4, Colors.mul(Colors.lerp(0xFF343A4D, accent, f.guiAnim), a));
            int kx = sx + 1 + Math.round(f.guiAnim * 8f);
            Ui.rrect(c, kx, sy + 1, kx + 6, sy + 7, 3, Colors.mul(0xFFFFFFFF, a));
            if (hasKids(f)) {
                Ui.text(c, OPEN.contains(f) ? "v" : ">", x + w - 30, y + (h - 8) / 2, Colors.mul(0xFF59607A, a));
            }
            Hit t = hit(x, y, w, h, 0, f);
            t.tip = hasKids(f) ? f.desc + "  (right click: settings)" : f.desc;
            hits.add(t);
            if (hov) hoverTip = t.tip;
        } else if (f.type == Feature.Type.MODE) {
            String label = sub ? f.name.replace(" Style", "") : f.name;
            Ui.text(c, label, x + 6, y + (h - 8) / 2, Colors.mul(0xFFB3BAD0, a));
            String v = f.valueText();
            int vw = Ui.width(v);
            Ui.rrect(c, x + w - vw - 14, y + 2, x + w - 3, y + h - 2, 3, Colors.mul(0xFF262B3A, a));
            Ui.text(c, v, x + w - vw - 8, y + (h - 8) / 2, Colors.mul(accent, a));
            hits.add(hit(x, y, w, h, 3, f));
        } else {
            Ui.text(c, f.name, x + 6, y + 3, Colors.mul(0xFFB3BAD0, a));
            String v = f.valueText();
            Ui.text(c, v, x + w - 6 - Ui.width(v), y + 3, Colors.mul(accent, a));
            int bx1 = x + 6, bx2 = x + w - 6, by = y + h - 6;
            Ui.rrect(c, bx1, by, bx2, by + 3, 1, Colors.mul(0xFF2E3448, a));
            double n = (f.value - f.min) / (f.max - f.min);
            int fx = bx1 + (int) ((bx2 - bx1) * n);
            if (fx > bx1) Ui.rrect(c, bx1, by, fx, by + 3, 1, Colors.mul(accent, a));
            Ui.rrect(c, fx - 2, by - 1, fx + 2, by + 4, 1, Colors.mul(0xFFFFFFFF, a));
            Hit t = hit(x, y, w, h, 2, f);
            t.bx1 = bx1; t.bx2 = bx2;
            hits.add(t);
        }
    }

    private void setSlider(Feature f, double mx) {
        double n = Math.max(0.0, Math.min(1.0, (mx - dragX1) / Math.max(1.0, (double) (dragX2 - dragX1))));
        double v = f.min + (f.max - f.min) * n;
        if (f.integer) v = Math.round(v);
        f.value = v;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int b = click.button();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) continue;
            switch (h.act) {
                case 0 -> {
                    if (b == 0) h.f.toggle();
                    else if (b == 1 && hasKids(h.f)) {
                        if (!OPEN.remove(h.f)) OPEN.add(h.f);
                    }
                }
                case 2 -> {
                    if (b == 0) {
                        dragF = h.f;
                        dragX1 = h.bx1;
                        dragX2 = h.bx2;
                        setSlider(h.f, mx);
                    }
                }
                case 3 -> h.f.cycle();
                case 20 -> MinecraftClient.getInstance().setScreen(new HudEditorScreen());
                default -> {
                    if (h.act >= 11 && h.act <= 15) {
                        int slot = h.act - 10;
                        if (b == 0 && AuroraVisuals.slotExists(slot)) AuroraVisuals.loadSlot(slot);
                        else AuroraVisuals.saveSlot(slot);
                    }
                }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragF != null) {
            setSlider(dragF, click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragF != null) {
            dragF = null;
            AuroraVisuals.saveConfig();
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int i = 0; i < PANEL_NAMES.length; i++) {
            int x = left + i * (pnlW + gap);
            if (mouseX >= x && mouseX < x + pnlW && mouseY >= top && mouseY < top + pnlH) {
                int max = Math.max(0, content[i] - view[i]);
                SCROLL[i] = Math.max(0, Math.min(max, SCROLL[i] - (int) Math.signum(verticalAmount) * 14));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void removed() {
        AuroraVisuals.saveConfig();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
