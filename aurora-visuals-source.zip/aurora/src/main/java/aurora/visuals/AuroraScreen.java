package aurora.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class AuroraScreen extends Screen {
    private static final int PW = 360, PH = 210;
    private int px, py;

    public AuroraScreen() {
        super(Text.literal(AuroraVisuals.NAME));
    }

    private static String label(Module m) {
        return m.name + ": " + (m.enabled ? "§aON" : "§cOFF");
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;

        Map<String, List<Module>> cats = new LinkedHashMap<>();
        for (Module m : AuroraVisuals.MODULES) cats.computeIfAbsent(m.category, k -> new ArrayList<>()).add(m);

        int col = 0;
        for (Map.Entry<String, List<Module>> e : cats.entrySet()) {
            int x = px + 10 + col * 116;
            int y = py + 46;
            for (Module m : e.getValue()) {
                addDrawableChild(ButtonWidget.builder(Text.literal(label(m)), b -> {
                    m.toggle();
                    b.setMessage(Text.literal(label(m)));
                }).dimensions(x, y, 108, 20).build());
                y += 24;
            }
            col++;
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(px, py, px + PW, py + PH, 0xE00D0D14);
        c.fillGradient(px, py, px + PW, py + 3, Colors.aurora(0), Colors.aurora(0.4));
        c.fill(px, py + 3, px + PW, py + 30, 0xE0151520);

        String title = AuroraVisuals.NAME;
        int x = px + 10;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            c.drawTextWithShadow(textRenderer, ch, x, py + 12, Colors.aurora(i * 0.05));
            x += textRenderer.getWidth(ch);
        }

        int cx = px + 10;
        Map<String, Boolean> seen = new LinkedHashMap<>();
        for (Module m : AuroraVisuals.MODULES) seen.putIfAbsent(m.category, true);
        for (String cat : seen.keySet()) {
            c.drawTextWithShadow(textRenderer, cat.toUpperCase(), cx, py + 34, 0xFF9A9AB0);
            cx += 116;
        }
        c.drawTextWithShadow(textRenderer, "RShift - close", px + 10, py + PH - 14, 0xFF6A6A80);
        super.render(c, mx, my, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
