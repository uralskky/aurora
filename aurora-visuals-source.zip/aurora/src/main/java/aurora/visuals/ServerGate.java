package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

/** Features that automate inventory actions are only allowed where the user said the server permits them. */
public final class ServerGate {
    private ServerGate() {}

    public static boolean allowed(MinecraftClient mc) {
        if (mc.isInSingleplayer()) return true;
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null || si.address == null) return false;
        String a = si.address.toLowerCase();
        return a.contains("funtime.su") || a.contains("skytime.su");
    }
}
