package aurora.visuals.mixin;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public final class SwingAnim {
    private SwingAnim() {}

    public static boolean apply(MatrixStack m, Arm arm, float sp, int mode) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        float f = MathHelper.sin(sp * sp * (float) Math.PI);
        float g = MathHelper.sin(MathHelper.sqrt(sp) * (float) Math.PI);
        switch (mode) {
            case 1 -> {
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (45.0f + f * -10.0f)));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * g * -10.0f));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -40.0f));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45.0f));
            }
            case 2 -> {
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (45.0f + f * -30.0f)));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * g * -60.0f));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -30.0f));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45.0f));
            }
            case 3 -> {
                m.translate(0.0f, 0.0f, -g * 0.5f);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * 45.0f));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -10.0f));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45.0f));
            }
            case 4 -> {
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * 45.0f));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sp * -360.0f));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45.0f));
            }
            case 5 -> {
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * 45.0f));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -110.0f));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45.0f));
            }
            default -> {
                return false;
            }
        }
        return true;
    }
}
