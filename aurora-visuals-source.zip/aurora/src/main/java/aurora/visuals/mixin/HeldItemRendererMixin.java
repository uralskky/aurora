package aurora.visuals.mixin;

import aurora.visuals.AuroraVisuals;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {

    @Inject(method = "applyEquipOffset", at = @At("HEAD"))
    private void aurora$viewModel(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
        if (!AuroraVisuals.VIEW_MODEL.enabled) return;
        int side = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(AuroraVisuals.VM_X.value * side, AuroraVisuals.VM_Y.value, AuroraVisuals.VM_Z.value);
        float s = (float) AuroraVisuals.VM_SCALE.value;
        matrices.scale(s, s, s);
    }

    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
    private void aurora$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        int mode = AuroraVisuals.SWING_ANIM.mode;
        if (mode > 0 && SwingAnim.apply(matrices, arm, swingProgress, mode)) ci.cancel();
    }
}
