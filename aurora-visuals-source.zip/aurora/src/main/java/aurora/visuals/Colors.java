package aurora.visuals;

import java.awt.Color;

public final class Colors {
    private Colors() {}

    /** Aurora gradient: green -> cyan -> violet -> pink, animated over time. */
    public static int aurora(double offset) {
        double t = (System.currentTimeMillis() / 2500.0 + offset) % 1.0;
        float hue = 0.38f + 0.5f * (float) (0.5 + 0.5 * Math.sin(t * Math.PI * 2));
        return 0xFF000000 | (Color.HSBtoRGB(hue, 0.65f, 1.0f) & 0xFFFFFF);
    }

    public static int alpha(int argb, int a) {
        return (a << 24) | (argb & 0xFFFFFF);
    }
}
