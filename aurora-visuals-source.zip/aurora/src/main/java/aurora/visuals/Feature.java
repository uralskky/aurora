package aurora.visuals;

public class Feature {
    public enum Type { TOGGLE, SLIDER, MODE }

    public final String name, desc, category;
    public final Type type;
    public boolean enabled;
    public double value, min, max;
    public boolean integer;
    public String[] modes;
    public int mode;
    public float anim;
    public float guiAnim;
    public Feature style;

    private Feature(String n, String d, String c, Type t) {
        name = n; desc = d; category = c; type = t;
    }

    public static Feature toggle(String n, String d, String c, boolean def) {
        Feature f = new Feature(n, d, c, Type.TOGGLE);
        f.enabled = def;
        f.anim = def ? 1 : 0;
        f.guiAnim = f.anim;
        return f;
    }

    public static Feature slider(String n, String d, String c, double min, double max, double def, boolean integer) {
        Feature f = new Feature(n, d, c, Type.SLIDER);
        f.min = min; f.max = max; f.value = def; f.integer = integer;
        return f;
    }

    public static Feature mode(String n, String d, String c, int def, String... modes) {
        Feature f = new Feature(n, d, c, Type.MODE);
        f.modes = modes; f.mode = def;
        return f;
    }

    public void toggle() {
        enabled = !enabled;
        AuroraVisuals.onToggle(this);
    }

    public void cycle() {
        mode = (mode + 1) % modes.length;
    }

    public int intValue() {
        return (int) Math.round(value);
    }

    public String valueText() {
        if (type == Type.MODE) return modes[mode];
        if (name.equals("HUD Opacity")) return Math.round(value * 100) + "%";
        if (integer) return String.valueOf(intValue());
        return String.format("%.1f", value);
    }
}
