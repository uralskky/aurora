package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class AuroraHud {
    private AuroraHud() {}

    public static void render(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        if (AuroraVisuals.WATERMARK.enabled) watermark(c, tr, mc);
        if (AuroraVisuals.ARRAYLIST.enabled) arrayList(c, tr, w);
        if (AuroraVisuals.INFO.enabled) info(c, tr, mc, h);
        if (AuroraVisuals.TARGET_HUD.enabled) targetHud(c, tr, mc, w, h);
        if (AuroraVisuals.CROSSHAIR.enabled) crosshair(c, w, h);
    }

    private static void watermark(DrawContext c, TextRenderer tr, MinecraftClient mc) {
        String name = AuroraVisuals.NAME;
        String tail = " | " + mc.getCurrentFps() + " fps";
        int width = tr.getWidth(name) + tr.getWidth(tail) + 12;
        c.fill(4, 4, 4 + width, 20, 0xB0101018);
        c.fillGradient(4, 4, 4 + width, 6, Colors.aurora(0), Colors.aurora(0.35));
        int x = 10;
        for (int i = 0; i < name.length(); i++) {
            String ch = String.valueOf(name.charAt(i));
            c.drawTextWithShadow(tr, ch, x, 9, Colors.aurora(i * 0.04));
            x += tr.getWidth(ch);
        }
        c.drawTextWithShadow(tr, tail, x, 9, 0xFFB8B8C8);
    }

    private static void arrayList(DrawContext c, TextRenderer tr, int w) {
        List<Module> on = new ArrayList<>();
        for (Module m : AuroraVisuals.MODULES) if (m.enabled) on.add(m);
        on.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.name)).reversed());
        int y = 4, i = 0;
        for (Module m : on) {
            int tw = tr.getWidth(m.name);
            int x = w - tw - 8;
            c.fill(x - 3, y, w, y + 11, 0x90101018);
            c.fill(w - 2, y, w, y + 11, Colors.aurora(i * 0.08));
            c.drawTextWithShadow(tr, m.name, x, y + 2, Colors.aurora(i * 0.08));
            y += 11; i++;
        }
    }

    private static void info(DrawContext c, TextRenderer tr, MinecraftClient mc, int h) {
        String xyz = String.format("XYZ  %.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        int bw = tr.getWidth(xyz) + 10;
        c.fill(4, h - 18, 4 + bw, h - 4, 0xB0101018);
        c.fill(4, h - 18, 6, h - 4, Colors.aurora(0.5));
        c.drawTextWithShadow(tr, xyz, 10, h - 14, 0xFFE8E8F4);
    }

    private static void targetHud(DrawContext c, TextRenderer tr, MinecraftClient mc, int w, int h) {
        Entity e = mc.targetedEntity;
        if (!(e instanceof LivingEntity t)) return;
        int bw = 130, bh = 36;
        int x = w / 2 + 14, y = h / 2 + 14;
        c.fill(x, y, x + bw, y + bh, 0xC0101018);
        c.fillGradient(x, y, x + bw, y + 2, Colors.aurora(0), Colors.aurora(0.4));
        c.drawTextWithShadow(tr, t.getName().getString(), x + 6, y + 7, 0xFFFFFFFF);
        float hp = Math.max(0, t.getHealth());
        float pct = Math.min(1f, hp / t.getMaxHealth());
        c.fill(x + 6, y + 22, x + bw - 6, y + 28, 0xFF2A2A38);
        c.fillGradient(x + 6, y + 22, x + 6 + (int) ((bw - 12) * pct), y + 28, Colors.aurora(0.1), Colors.aurora(0.5));
        String s = String.format("%.1f", hp);
        c.drawTextWithShadow(tr, s, x + bw - 6 - tr.getWidth(s), y + 7, 0xFFB8B8C8);
    }

    private static void crosshair(DrawContext c, int w, int h) {
        int cx = w / 2, cy = h / 2, col = Colors.aurora(0);
        c.fill(cx - 5, cy, cx - 2, cy + 1, col);
        c.fill(cx + 3, cy, cx + 6, cy + 1, col);
        c.fill(cx, cy - 5, cx + 1, cy - 2, col);
        c.fill(cx, cy + 3, cx + 1, cy + 6, col);
    }
}
