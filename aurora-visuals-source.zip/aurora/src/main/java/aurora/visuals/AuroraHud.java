package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public final class AuroraHud {
    private AuroraHud() {}

    private static long lastNs = System.nanoTime();
    private static float dt = 0.016f;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final String[] ROMAN = {"", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final String[] DIRS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
    private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static ItemStack[] counterIcons;

    private static float targetFade, shownHp;
    private static String targetName = "";
    private static float targetMax = 20f;

    private static int bg() {
        return Colors.alpha(0x0E0E16, (int) (AuroraVisuals.HUD_ALPHA.value * 235));
    }

    public static void render(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;

        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        ClientPlayerEntity p = mc.player;

        if (AuroraVisuals.WATERMARK.enabled) watermark(c, mc, p);
        if (AuroraVisuals.INFO.enabled) info(c, p);
        if (AuroraVisuals.POTIONS.enabled) potions(c, p);
        if (AuroraVisuals.COUNTER.enabled) counter(c, p, h);
        if (AuroraVisuals.INVENTORY.enabled) inventory(c, p, h);
        if (AuroraVisuals.ARMOR.enabled) armor(c, p, w, h);
        if (AuroraVisuals.KEYSTROKES.enabled) keystrokes(c, mc, w, h);
        if (AuroraVisuals.TARGET_HUD.enabled) targetHud(c, mc, w, h);
        moduleList(c, w);
    }

    private static void watermark(DrawContext c, MinecraftClient mc, ClientPlayerEntity p) {
        int st = AuroraVisuals.WATERMARK.style.mode;
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            if (e != null) ping = e.getLatency();
        }
        int nameW = Ui.width(AuroraVisuals.NAME);
        if (st == 2) {
            Ui.gtext(c, AuroraVisuals.NAME, 6, 6, 0, 1f);
            Ui.text(c, mc.getCurrentFps() + " fps", 6 + nameW + 6, 6, 0xFFE8E8F4);
            return;
        }
        if (st == 1) {
            String r = String.valueOf(mc.getCurrentFps());
            int wd = nameW + Ui.width(r) + 26;
            Ui.rrect(c, 4, 4, 4 + wd, 18, 3, bg());
            Ui.hgrad(c, 7, 4, 4 + wd - 3, 5, 1f);
            Ui.gtext(c, AuroraVisuals.NAME, 10, 8, 0, 1f);
            Ui.text(c, r, 10 + nameW + 10, 8, 0xFFE8E8F4);
            return;
        }
        String right = mc.getCurrentFps() + " fps  |  " + ping + " ms  |  " + LocalTime.now().format(CLOCK);
        int wd = nameW + Ui.width(right) + 30;
        Ui.rrect(c, 4, 4, 4 + wd, 21, 3, bg());
        Ui.rrect(c, 8, 8, 12, 17, 1, Colors.aurora(0));
        Ui.gtext(c, AuroraVisuals.NAME, 17, 9, 0, 1f);
        Ui.text(c, right, 17 + nameW + 10, 9, 0xFFB8B8CC);
    }

    private static void info(DrawContext c, ClientPlayerEntity p) {
        float yaw = p.getYaw() % 360f;
        if (yaw > 180f) yaw -= 360f;
        if (yaw < -180f) yaw += 360f;
        String dir = DIRS[(Math.round(yaw / 45f) + 8) % 8];
        String s = String.format("XYZ %.1f %.1f %.1f  |  %s  |  %.1f BPS", p.getX(), p.getY(), p.getZ(), dir, AuroraVisuals.bps);
        int wd = Ui.width(s) + 14;
        Ui.rrect(c, 4, 25, 4 + wd, 40, 3, bg());
        Ui.rrect(c, 4, 28, 6, 37, 1, Colors.aurora(0.4));
        Ui.text(c, s, 11, 29, 0xFFE8E8F4);
    }

    private static void potions(DrawContext c, ClientPlayerEntity p) {
        Collection<StatusEffectInstance> effs = p.getStatusEffects();
        if (effs.isEmpty()) return;
        int st = AuroraVisuals.POTIONS.style.mode;
        int x = 4, y = 45, wd = 120;
        int rows = effs.size();
        int yy = y;
        if (st == 0) {
            Ui.rrect(c, x, y, x + wd, y + 15 + rows * 12, 3, bg());
            Ui.hgrad(c, x + 3, y, x + wd - 3, y + 1, 1f);
            Ui.text(c, "Potions", x + 6, y + 4, 0xFF9A9AB4);
            yy = y + 15;
        }
        for (StatusEffectInstance e : effs) {
            String name = e.getEffectType().value().getName().getString();
            int amp = e.getAmplifier();
            if (amp > 0 && amp < ROMAN.length) name += " " + ROMAN[amp + 1];
            else if (amp >= ROMAN.length) name += " " + (amp + 1);
            int d = e.getDuration();
            String t = d < 0 ? "inf" : String.format("%d:%02d", d / 1200, (d / 20) % 60);
            int tc = d >= 0 && d < 200 ? 0xFFFF6B6B : Colors.aurora(0.3);
            if (st == 1) {
                Ui.rrect(c, x, yy, x + wd, yy + 13, 3, bg());
                Ui.rrect(c, x, yy + 2, x + 2, yy + 11, 1, Colors.aurora(yy * 0.02));
                Ui.text(c, name, x + 7, yy + 3, 0xFFEDEDF7);
                Ui.text(c, t, x + wd - 5 - Ui.width(t), yy + 3, tc);
                yy += 15;
            } else if (st == 2) {
                Ui.text(c, name + "  " + t, x + 2, yy, tc == 0xFFFF6B6B ? tc : 0xFFEDEDF7);
                yy += 11;
            } else {
                Ui.text(c, name, x + 6, yy, 0xFFEDEDF7);
                Ui.text(c, t, x + wd - 6 - Ui.width(t), yy, tc);
                yy += 12;
            }
        }
    }

    private static ItemStack[] icons() {
        if (counterIcons == null) {
            counterIcons = new ItemStack[]{
                    new ItemStack(Items.TOTEM_OF_UNDYING), new ItemStack(Items.GOLDEN_APPLE),
                    new ItemStack(Items.ENDER_PEARL), new ItemStack(Items.EXPERIENCE_BOTTLE)};
        }
        return counterIcons;
    }

    private static void counter(DrawContext c, ClientPlayerEntity p, int h) {
        int[] cnt = new int[4];
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            if (s.isOf(Items.TOTEM_OF_UNDYING)) cnt[0] += s.getCount();
            else if (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)) cnt[1] += s.getCount();
            else if (s.isOf(Items.ENDER_PEARL)) cnt[2] += s.getCount();
            else if (s.isOf(Items.EXPERIENCE_BOTTLE)) cnt[3] += s.getCount();
        }
        int x = 4, y = h / 2 - 40;
        Ui.rrect(c, x, y, x + 50, y + 76, 3, bg());
        Ui.hgrad(c, x + 3, y, x + 47, y + 1, 1f);
        ItemStack[] ic = icons();
        for (int i = 0; i < 4; i++) {
            int yy = y + 3 + i * 18;
            c.drawItem(ic[i], x + 4, yy);
            Ui.text(c, String.valueOf(cnt[i]), x + 25, yy + 4, cnt[i] == 0 ? 0xFF77778F : 0xFFFFFFFF);
        }
    }

    private static void inventory(DrawContext c, ClientPlayerEntity p, int h) {
        int x = 4, y = h - 4 - 72, wd = 170;
        Ui.rrect(c, x, y, x + wd, y + 72, 3, bg());
        Ui.hgrad(c, x + 3, y, x + wd - 3, y + 1, 1f);
        Ui.text(c, "Inventory", x + 6, y + 4, 0xFF9A9AB4);
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 27; i++) {
            ItemStack s = inv.getStack(9 + i);
            int sx = x + 4 + (i % 9) * 18, sy = y + 15 + (i / 9) * 18;
            c.fill(sx, sy, sx + 17, sy + 17, 0x30FFFFFF);
            if (s.isEmpty()) continue;
            c.drawItem(s, sx + 1, sy + 1);
            if (s.getCount() > 1) {
                String t = String.valueOf(s.getCount());
                Ui.text(c, t, sx + 17 - Ui.width(t), sy + 9, 0xFFFFFFFF);
            }
        }
    }

    private static void armor(DrawContext c, ClientPlayerEntity p, int w, int h) {
        boolean any = false;
        for (EquipmentSlot s : ARMOR_SLOTS) if (!p.getEquippedStack(s).isEmpty()) any = true;
        if (!any) return;
        int x = w / 2 - 40, y = h - 84;
        Ui.rrect(c, x - 4, y - 4, x + 84, y + 24, 3, bg());
        for (int i = 0; i < 4; i++) {
            ItemStack s = p.getEquippedStack(ARMOR_SLOTS[i]);
            int sx = x + i * 21;
            c.fill(sx, y, sx + 18, y + 18, 0x28FFFFFF);
            if (s.isEmpty()) continue;
            c.drawItem(s, sx + 1, y + 1);
            if (s.isDamageable() && s.getMaxDamage() > 0) {
                float f = 1f - (float) s.getDamage() / s.getMaxDamage();
                int col = Colors.lerp(0xFFFF4D4D, 0xFF4ADE80, f);
                c.fill(sx + 1, y + 20, sx + 17, y + 22, 0xFF202030);
                c.fill(sx + 1, y + 20, sx + 1 + Math.max(1, (int) (16 * f)), y + 22, col);
            }
        }
    }

    private static void key(DrawContext c, int x, int y, int wd, int ht, String label, boolean down, String sub) {
        int base = down ? Colors.alpha(Colors.aurora(x * 0.02) & 0xFFFFFF, 190) : bg();
        Ui.rrect(c, x, y, x + wd, y + ht, 3, base);
        int ty = sub == null ? y + (ht - 8) / 2 : y + 3;
        Ui.text(c, label, x + (wd - Ui.width(label)) / 2, ty, down ? 0xFF101018 : 0xFFE8E8F4);
        if (sub != null) Ui.text(c, sub, x + (wd - Ui.width(sub)) / 2, y + 12, down ? 0xFF101018 : 0xFF9A9AB4);
    }

    private static void keystrokes(DrawContext c, MinecraftClient mc, int w, int h) {
        int kx = w - 4 - 66, ky = h - 4 - 82;
        var o = mc.options;
        key(c, kx + 22, ky, 22, 20, "W", o.forwardKey.isPressed(), null);
        key(c, kx, ky + 22, 22, 20, "A", o.leftKey.isPressed(), null);
        key(c, kx + 22, ky + 22, 22, 20, "S", o.backKey.isPressed(), null);
        key(c, kx + 44, ky + 22, 22, 20, "D", o.rightKey.isPressed(), null);
        key(c, kx, ky + 44, 32, 22, "LMB", o.attackKey.isPressed(), AuroraVisuals.cpsLeft() + " CPS");
        key(c, kx + 34, ky + 44, 32, 22, "RMB", o.useKey.isPressed(), AuroraVisuals.cpsRight() + " CPS");
        key(c, kx, ky + 68, 66, 14, "Space", o.jumpKey.isPressed(), null);
    }

    private static void targetHud(DrawContext c, MinecraftClient mc, int w, int h) {
        Entity e = mc.targetedEntity;
        if (e instanceof LivingEntity t) {
            targetName = t.getName().getString();
            targetMax = Math.max(1f, t.getMaxHealth());
            float hp = Math.max(0f, t.getHealth());
            if (targetFade < 0.05f) shownHp = hp;
            shownHp += (hp - shownHp) * Math.min(1f, dt * 10f);
            targetFade += (1f - targetFade) * Math.min(1f, dt * 12f);
        } else {
            targetFade += (0f - targetFade) * Math.min(1f, dt * 8f);
        }
        if (targetFade < 0.03f) return;
        float a = targetFade;
        int st = AuroraVisuals.TARGET_HUD.style.mode;
        int x = w / 2 + 16, y = h / 2 + 14;
        String s = String.format("%.1f", shownHp);
        float pct = Math.max(0f, Math.min(1f, shownHp / targetMax));
        if (st == 1) {
            int bw = 104, bh = 23;
            Ui.rrect(c, x, y, x + bw, y + bh, 3, Colors.mul(bg(), a));
            Ui.text(c, targetName, x + 6, y + 4, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, s, x + bw - 6 - Ui.width(s), y + 4, Colors.mul(0xFFB8B8CC, a));
            Ui.rrect(c, x + 6, y + 15, x + bw - 6, y + 18, 1, Colors.mul(0xFF2A2A3A, a));
            int fx = x + 6 + (int) ((bw - 12) * pct);
            if (fx > x + 7) Ui.hgrad(c, x + 6, y + 15, fx, y + 18, a);
        } else if (st == 2) {
            Ui.text(c, targetName, x, y, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, s, x + Ui.width(targetName) + 6, y, Colors.mul(Colors.aurora(0.3), a));
            c.fill(x, y + 11, x + 72, y + 13, Colors.mul(0x80000000, a));
            int fx = x + (int) (72 * pct);
            if (fx > x) Ui.hgrad(c, x, y + 11, fx, y + 13, a);
        } else if (st == 3) {
            int bw = 142, bh = 36;
            Ui.rrect(c, x, y, x + bw, y + bh, 2, Colors.mul(bg(), a));
            Ui.hgrad(c, x, y, x + bw, y + 1, a);
            Ui.hgrad(c, x, y + bh - 1, x + bw, y + bh, a);
            c.fill(x, y, x + 1, y + bh, Colors.mul(Colors.aurora(0), a));
            c.fill(x + bw - 1, y, x + bw, y + bh, Colors.mul(Colors.aurora(0.8), a));
            Ui.text(c, targetName, x + 7, y + 6, Colors.mul(0xFFFFFFFF, a));
            Ui.rrect(c, x + 7, y + 19, x + bw - 7, y + 29, 2, Colors.mul(0xFF22222F, a));
            int fx = x + 7 + (int) ((bw - 14) * pct);
            if (fx > x + 8) Ui.hgrad(c, x + 7, y + 19, fx, y + 29, a);
            String pc = Math.round(pct * 100) + "%";
            Ui.text(c, pc, x + (bw - Ui.width(pc)) / 2, y + 20, Colors.mul(0xFFFFFFFF, a));
        } else {
            int bw = 132, bh = 38;
            Ui.rrect(c, x, y, x + bw, y + bh, 4, Colors.mul(bg(), a));
            Ui.hgrad(c, x + 3, y, x + bw - 3, y + 2, a);
            Ui.text(c, targetName, x + 7, y + 8, Colors.mul(0xFFFFFFFF, a));
            Ui.text(c, s, x + bw - 7 - Ui.width(s), y + 8, Colors.mul(0xFFB8B8CC, a));
            Ui.rrect(c, x + 7, y + 24, x + bw - 7, y + 30, 2, Colors.mul(0xFF2A2A3A, a));
            int fx = x + 7 + (int) ((bw - 14) * pct);
            if (fx > x + 8) Ui.hgrad(c, x + 7, y + 24, fx, y + 30, a);
        }
    }

    private static void moduleList(DrawContext c, int w) {
        List<Feature> list = new ArrayList<>();
        for (Feature f : AuroraVisuals.FEATURES) {
            if (f.type != Feature.Type.TOGGLE) continue;
            f.anim += ((f.enabled ? 1f : 0f) - f.anim) * Math.min(1f, dt * 10f);
            if (f.anim > 0.02f && f != AuroraVisuals.MODULE_LIST) list.add(f);
        }
        if (!AuroraVisuals.MODULE_LIST.enabled) return;
        int st = AuroraVisuals.MODULE_LIST.style.mode;
        list.sort(Comparator.comparingInt((Feature f) -> Ui.width(f.name)).reversed());
        int y = 4, i = 0;
        for (Feature f : list) {
            int tw = Ui.width(f.name);
            int slide = (int) ((1f - f.anim) * (tw + 14));
            int x = w - tw - 10 + slide;
            int col = Colors.mul(Colors.aurora(i * 0.1), f.anim);
            if (st == 0) {
                Ui.rrect(c, x - 4, y, w - 2 + slide, y + 12, 2, Colors.mul(bg(), f.anim));
                c.fill(w - 2 + slide, y + 1, w + slide, y + 11, col);
                Ui.text(c, f.name, x, y + 2, col);
            } else if (st == 1) {
                Ui.rrect(c, x - 5, y, w - 4 + slide, y + 12, 3, Colors.mul(bg(), f.anim));
                Ui.text(c, f.name, x, y + 2, col);
            } else {
                Ui.text(c, f.name, w - tw - 5 + slide, y, col);
            }
            y += st == 2 ? 10 : 13;
            i++;
        }
    }

    public static void crosshair(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int cx = mc.getWindow().getScaledWidth() / 2, cy = mc.getWindow().getScaledHeight() / 2;
        int col = Colors.aurora(0);
        switch (AuroraVisuals.CROSS_STYLE.mode) {
            case 1 -> c.fill(cx - 1, cy - 1, cx + 2, cy + 2, col);
            case 2 -> {
                c.fill(cx - 6, cy, cx + 7, cy + 1, col);
                c.fill(cx, cy - 6, cx + 1, cy + 7, col);
            }
            default -> {
                c.fill(cx - 7, cy, cx - 3, cy + 1, col);
                c.fill(cx + 4, cy, cx + 8, cy + 1, col);
                c.fill(cx, cy - 7, cx + 1, cy - 3, col);
                c.fill(cx, cy + 4, cx + 1, cy + 8, col);
            }
        }
    }
}
