package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

import java.util.Random;

public class AuroraTitleScreen extends Screen {
    public static long openTime = System.currentTimeMillis();

    private static final String[][] FONT = {
            {"01110", "10001", "10001", "11111", "10001", "10001", "10001"}, // A
            {"10001", "10001", "10001", "10001", "10001", "10001", "01110"}, // U
            {"11110", "10001", "10001", "11110", "10100", "10010", "10001"}, // R
            {"01110", "10001", "10001", "10001", "10001", "10001", "01110"}  // O
    };
    private static final int[] WORD = {0, 1, 2, 3, 2, 0}; // A U R O R A

    private final float[] starX = new float[110], starY = new float[110], starP = new float[110];
    private int logoBottom;

    public AuroraTitleScreen() {
        super(Text.literal("Aurora Visuals"));
        openTime = System.currentTimeMillis();
        Random r = new Random(7);
        for (int i = 0; i < starX.length; i++) {
            starX[i] = r.nextFloat();
            starY[i] = r.nextFloat() * 0.75f;
            starP[i] = r.nextFloat() * 6.28f;
        }
    }

    @Override
    protected void init() {
        MinecraftClient mc = MinecraftClient.getInstance();
        int cell = Math.max(3, Math.min(6, height / 60));
        int y0 = (int) (height * 0.10);
        logoBottom = y0 + 7 * cell + 24;

        int bw = Math.min(200, width - 40);
        int count = 5;
        int start = logoBottom + 12;
        int avail = height - start - 22;
        int step = Math.max(20, Math.min(28, avail / count));
        int bh = step - 4;
        int x = (width - bw) / 2;
        int i = 0;
        addDrawableChild(new Widgets.MenuButton(x, start + step * i, bw, bh, "Singleplayer", i++,
                () -> mc.setScreen(new SelectWorldScreen(this))));
        addDrawableChild(new Widgets.MenuButton(x, start + step * i, bw, bh, "Multiplayer", i++,
                () -> mc.setScreen(new MultiplayerScreen(this))));
        addDrawableChild(new Widgets.MenuButton(x, start + step * i, bw, bh, "Options", i++,
                () -> mc.setScreen(new OptionsScreen(this, mc.options))));
        addDrawableChild(new Widgets.MenuButton(x, start + step * i, bw, bh, "Aurora Settings", i++,
                () -> mc.setScreen(new AuroraScreen(true))));
        addDrawableChild(new Widgets.MenuButton(x, start + step * i, bw, bh, "Quit Game", i,
                mc::scheduleStop));
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        // custom background is drawn in render()
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        double t = System.currentTimeMillis() / 1000.0;
        c.fillGradient(0, 0, width, height, 0xFF05060D, 0xFF0F1428);

        for (int i = 0; i < starX.length; i++) {
            float tw = 0.35f + 0.65f * (float) Math.sin(t * 1.5 + starP[i]);
            int a = (int) (210 * Math.max(0f, tw));
            if (a < 10) continue;
            int sx = (int) (starX[i] * width), sy = (int) (starY[i] * height);
            int sz = i % 7 == 0 ? 2 : 1;
            c.fill(sx, sy, sx + sz, sy + sz, Colors.alpha(0xFFFFFF, a));
        }

        for (int b = 0; b < 3; b++) {
            for (int x = 0; x < width; x += 3) {
                double wave = Math.sin(x * 0.012 + t * 0.45 + b * 2.1) * height * 0.07
                        + Math.sin(x * 0.027 - t * 0.3 + b) * height * 0.025;
                int mid = (int) (height * (0.30 + b * 0.07) + wave);
                double th = height * (0.10 + 0.05 * Math.sin(x * 0.02 - t * 0.6 + b * 1.3));
                int col = Colors.aurora(b * 0.8 + x * 0.003) & 0xFFFFFF;
                int top = (int) (mid - th), bot = (int) (mid + th * 0.6);
                c.fillGradient(x, top, x + 3, mid, Colors.alpha(col, 0), Colors.alpha(col, 70));
                c.fillGradient(x, mid, x + 3, bot, Colors.alpha(col, 70), Colors.alpha(col, 0));
            }
        }

        for (int x = 0; x < width; x += 2) {
            double h1 = height * 0.82 - (Math.sin(x * 0.018) + Math.sin(x * 0.041 + 1.3) * 0.6) * height * 0.035;
            c.fill(x, (int) h1, x + 2, height, 0xFF05060B);
        }
        c.fillGradient(0, (int) (height * 0.72), width, height, 0x0005060B, 0xCC05060B);

        int cell = Math.max(3, Math.min(6, height / 60));
        int y0 = (int) (height * 0.10);
        int totalW = WORD.length * 5 * cell + (WORD.length - 1) * cell;
        int x0 = (width - totalW) / 2;
        for (int li = 0; li < WORD.length; li++) {
            String[] rows = FONT[WORD[li]];
            int lx = x0 + li * 6 * cell;
            int bob = (int) Math.round(Math.sin(t * 2.0 + li * 0.7) * 1.5);
            for (int ry = 0; ry < 7; ry++) {
                for (int rx = 0; rx < 5; rx++) {
                    if (rows[ry].charAt(rx) != '1') continue;
                    int px = lx + rx * cell, py = y0 + ry * cell + bob;
                    c.fill(px + 1, py + 1, px + cell + 1, py + cell + 1, 0x60000000);
                    c.fill(px, py, px + cell, py + cell, Colors.aurora(li * 0.35 + ry * 0.05 + rx * 0.03));
                }
            }
        }
        String sub = "V I S U A L S";
        Ui.gtext(c, sub, (width - Ui.width(sub)) / 2, y0 + 7 * cell + 10, 0.5, 1f);

        super.render(c, mx, my, delta);

        Ui.text(c, "Minecraft 1.21.11  |  Aurora Visuals v3", 6, height - 12, 0xFF8C8CA6);
        String r = "Fabric";
        Ui.text(c, r, width - Ui.width(r) - 6, height - 12, 0xFF8C8CA6);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
