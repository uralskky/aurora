package aurora.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public class AuroraTitleScreen extends Screen {
    public static long openTime = System.currentTimeMillis();

    private static final String[][] FONT = {
            {"01110", "10001", "10001", "11111", "10001", "10001", "10001"},
            {"10001", "10001", "10001", "10001", "10001", "10001", "01110"},
            {"11110", "10001", "10001", "11110", "10100", "10010", "10001"},
            {"01110", "10001", "10001", "10001", "10001", "10001", "01110"}
    };
    private static final int[] WORD = {0, 1, 2, 3, 2, 0};

    private int panelX, panelY, panelW, thumbW, thumbH, rowH;
    private final String[] labels = {"Singleplayer", "Multiplayer", "Options", "Aurora Settings", "Cosmetics", "Account Switcher", "Exit"};
    private final float[] hov = new float[5];
    private int listX, listY, itemH;

    public AuroraTitleScreen() {
        super(Text.literal("Aurora Visuals"));
        openTime = System.currentTimeMillis();
    }

    @Override
    protected void init() {
        panelW = 112;
        panelX = width - panelW - 8;
        panelY = 8;
        thumbW = 46;
        rowH = Math.max(28, Math.min(40, (height - 40) / 3));
        thumbH = rowH - 12;
        itemH = Math.max(15, Math.min(22, (height - 105) / labels.length));
        listX = Math.max(18, width / 12);
        listY = height / 2 - itemH * 5 / 2;
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        // custom background is drawn in render()
    }

    private int thumbX(int i) { return panelX + 6 + (i % 2) * (thumbW + 4); }

    private int thumbY(int i) { return panelY + 16 + (i / 2) * rowH; }

    private void run(int i) {
        MinecraftClient mc = MinecraftClient.getInstance();
        switch (i) {
            case 0 -> mc.setScreen(new SelectWorldScreen(this));
            case 1 -> mc.setScreen(new MultiplayerScreen(this));
            case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
            case 3 -> mc.setScreen(new AuroraScreen(true));
            case 4 -> mc.setScreen(new CosmeticsScreen(this));
            case 5 -> mc.setScreen(new AccountSwitcherScreen(this));
            default -> mc.scheduleStop();
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        double t = System.currentTimeMillis() / 1000.0;
        long since = System.currentTimeMillis() - openTime;
        MenuBackgrounds.draw(c, width, height, AuroraVisuals.MENU_BG.mode, t);
        c.fillGradient(0, 0, width / 2, height, 0x99000000, 0x00000000);

        // pixel logo, top-left
        int cell = 2;
        int lx0 = listX, ly0 = 14;
        for (int li = 0; li < WORD.length; li++) {
            String[] rows = FONT[WORD[li]];
            int lx = lx0 + li * 6 * cell;
            for (int ry = 0; ry < 7; ry++)
                for (int rx = 0; rx < 5; rx++) {
                    if (rows[ry].charAt(rx) != '1') continue;
                    c.fill(lx + rx * cell, ly0 + ry * cell, lx + rx * cell + cell, ly0 + ry * cell + cell,
                            Colors.aurora(li * 0.35 + ry * 0.05));
                }
        }
        Ui.text(c, "VISUALS", lx0, ly0 + 18, 0xFFB0B8D0);

        // left menu list
        for (int i = 0; i < labels.length; i++) {
            int y = listY + i * itemH;
            float ra = Colors.ease((since - i * 70L) / 320f);
            if (ra <= 0.01f) continue;
            int off = (int) ((1f - ra) * 14f);
            boolean h = mx >= listX - 6 && mx < listX + 150 && my >= y && my < y + itemH;
            hov[i] += ((h ? 1f : 0f) - hov[i]) * 0.25f;
            int x = listX - off + (int) (hov[i] * 4);
            int dot = Colors.lerp(0xFF5A6078, Colors.aurora(i * 0.4), hov[i]);
            Ui.rrect(c, x, y + itemH / 2 - 2, x + 4, y + itemH / 2 + 2, 2, Colors.mul(dot, ra));
            Ui.text(c, labels[i], x + 12, y + (itemH - 8) / 2,
                    Colors.mul(Colors.lerp(0xFFC9CEE0, 0xFFFFFFFF, hov[i]), ra));
        }

        // user card, bottom-left
        MinecraftClient mc = MinecraftClient.getInstance();
        String user = mc.player != null ? mc.player.getName().getString() : "Player";
        Ui.rrect(c, listX - 6, height - 38, listX + 112, height - 12, 6, 0xA0101319);
        Ui.rrect(c, listX - 1, height - 33, listX + 15, height - 17, 4, Colors.aurora(0.2));
        Ui.ctext(c, user.substring(0, 1).toUpperCase(), listX + 7, height - 29, 0xFFFFFFFF);
        Ui.text(c, Ui.trim(user, 84), listX + 21, height - 34, 0xFFFFFFFF);
        Ui.text(c, "Aurora Visuals", listX + 21, height - 24, 0xFF7F88A6);

        // background picker, top-right
        Ui.rrect(c, panelX, panelY, panelX + panelW, panelY + 16 + rowH * 3, 6, 0xB00A0C11);
        Ui.ctext(c, "BACKGROUND", panelX + panelW / 2, panelY + 4, 0xFFC8CEE3);
        for (int i = 0; i < MenuBackgrounds.NAMES.length; i++) {
            int tx = thumbX(i), tyy = thumbY(i);
            MenuBackgrounds.thumb(c, tx, tyy, thumbW, thumbH, i);
            boolean sel = i == AuroraVisuals.MENU_BG.mode;
            boolean hv = mx >= tx && mx < tx + thumbW && my >= tyy && my < tyy + thumbH;
            if (sel) Ui.outline(c, tx - 1, tyy - 1, tx + thumbW + 1, tyy + thumbH + 1, Colors.aurora(i * 0.3));
            else if (hv) Ui.outline(c, tx - 1, tyy - 1, tx + thumbW + 1, tyy + thumbH + 1, 0x88FFFFFF);
            Ui.ctext(c, MenuBackgrounds.NAMES[i], tx + thumbW / 2, tyy + thumbH + 2, sel ? 0xFFFFFFFF : 0xFF8F98B5);
        }

        Ui.text(c, "Minecraft 1.21.11  |  Aurora Visuals v6", width - Ui.width("Minecraft 1.21.11  |  Aurora Visuals v6") - 8,
                height - 12, 0xFF7F88A6);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return false;
        for (int i = 0; i < labels.length; i++) {
            int y = listY + i * itemH;
            if (click.x() >= listX - 6 && click.x() < listX + 150 && click.y() >= y && click.y() < y + itemH) {
                run(i);
                return true;
            }
        }
        for (int i = 0; i < MenuBackgrounds.NAMES.length; i++) {
            int tx = thumbX(i), ty = thumbY(i);
            if (click.x() >= tx && click.x() < tx + thumbW && click.y() >= ty && click.y() < ty + thumbH) {
                AuroraVisuals.MENU_BG.mode = i;
                AuroraVisuals.saveConfig();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
