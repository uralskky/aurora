package aurora.visuals;

import java.util.LinkedHashMap;
import java.util.Map;

public final class HudLayout {
    private HudLayout() {}

    public static final class El {
        public final String id, name;
        public int dx, dy;
        public int baseX, baseY, w, h, ax, ay;
        public long seen = -1;

        El(String id, String name) { this.id = id; this.name = name; }
    }

    public static final Map<String, El> ALL = new LinkedHashMap<>();
    public static boolean editing;
    public static long frame;

    public static final El WATERMARK = reg("watermark", "Watermark");
    public static final El INFO = reg("info", "Coordinates");
    public static final El POTIONS = reg("potions", "Potions");
    public static final El COUNTER = reg("counter", "Item Counter");
    public static final El INVENTORY = reg("inventory", "Inventory");
    public static final El ARMOR = reg("armor", "Armor");
    public static final El KEYS = reg("keys", "Keystrokes");
    public static final El TARGET = reg("target", "Target HUD");
    public static final El MODULES = reg("modules", "Module List");
    public static final El SESSION = reg("session", "Session");
    public static final El COMBAT = reg("combat", "Combat Info");

    private static El reg(String id, String name) {
        El e = new El(id, name);
        ALL.put(id, e);
        return e;
    }

    public static void layout(El e, int baseX, int baseY, int w, int h, int sw, int sh) {
        e.baseX = baseX; e.baseY = baseY; e.w = w; e.h = h;
        e.ax = Math.max(0, Math.min(Math.max(0, sw - w), baseX + e.dx));
        e.ay = Math.max(0, Math.min(Math.max(0, sh - h), baseY + e.dy));
        e.seen = frame;
    }

    public static boolean visible(El e) {
        return e.seen == frame;
    }

    public static void reset() {
        for (El e : ALL.values()) { e.dx = 0; e.dy = 0; }
    }
}
