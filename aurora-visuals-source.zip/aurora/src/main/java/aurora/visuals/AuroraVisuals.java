package aurora.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class AuroraVisuals implements ClientModInitializer {
    public static final String NAME = "Aurora Visuals";
    public static final List<Feature> FEATURES = new ArrayList<>();
    public static final List<Feature> STYLES = new ArrayList<>();

    // HUD
    public static final Feature WATERMARK  = add(Feature.toggle("Watermark", "Client name, FPS, ping and clock", "HUD", true));
    public static final Feature MODULE_LIST = add(Feature.toggle("Module List", "Animated list of active features", "HUD", true));
    public static final Feature INFO       = add(Feature.toggle("Coordinates", "XYZ, direction and speed in BPS", "HUD", true));
    public static final Feature POTIONS    = add(Feature.toggle("Potions", "Active effects with timers", "HUD", true));
    public static final Feature KEYSTROKES = add(Feature.toggle("Keystrokes", "WASD, mouse buttons and CPS", "HUD", true));
    public static final Feature ARMOR      = add(Feature.toggle("Armor HUD", "Worn armor with durability bars", "HUD", true));
    public static final Feature INVENTORY  = add(Feature.toggle("Inventory HUD", "Your backpack on the screen", "HUD", false));
    public static final Feature COUNTER    = add(Feature.toggle("Item Counter", "Totems, golden apples, pearls, XP", "HUD", true));

    // Combat visuals
    public static final Feature TARGET_HUD = add(Feature.toggle("Target HUD", "Health panel of the entity you look at", "Combat", true));
    public static final Feature HIT_FX     = add(Feature.toggle("Hit Effect", "Particles when you hit something", "Combat", true));
    public static final Feature HIT_MODE   = add(Feature.mode("Hit Style", "Particle type for hit and trail effects", "Combat", 0, "Stars", "Hearts", "Flames", "Magic"));
    public static final Feature HIT_SOUND  = add(Feature.toggle("Hit Sound", "Soft chime on every hit", "Combat", false));
    public static final Feature KILL_FX    = add(Feature.toggle("Kill Effect", "Burst when your target dies", "Combat", true));
    public static final Feature SWING      = add(Feature.mode("Swing Speed", "Slows the hand swing animation", "Combat", 0, "Off", "Slow", "Slower"));
    public static final Feature CROSSHAIR  = add(Feature.toggle("Custom Crosshair", "Replaces the vanilla crosshair", "Combat", false));
    public static final Feature CROSS_STYLE = add(Feature.mode("Crosshair Style", "Shape of the custom crosshair", "Combat", 0, "Cross", "Dot", "Plus"));

    // Player
    public static final Feature AUTO_SPRINT = add(Feature.toggle("Auto Sprint", "Sprints automatically while you walk forward", "Player", false));
    public static final Feature AUTO_RESPAWN = add(Feature.toggle("Auto Respawn", "Respawns instantly after death", "Player", false));

    // World
    public static final Feature FULLBRIGHT = add(Feature.toggle("Fullbright", "Sees everything in the dark", "World", false));
    public static final Feature SNOW       = add(Feature.toggle("Snow", "Falling snowflakes around you", "World", false));
    public static final Feature SNOW_AMOUNT = add(Feature.slider("Snow Density", "How many snowflakes spawn", "World", 1, 14, 4, true));
    public static final Feature FOV_ON     = add(Feature.toggle("FOV Changer", "Uses the FOV slider below", "World", false));
    public static final Feature FOV        = add(Feature.slider("FOV", "Field of view", "World", 30, 110, 90, true));
    public static final Feature ZOOM       = add(Feature.toggle("Zoom", "Hold C to zoom in", "World", true));

    // Effects
    public static final Feature TRAIL      = add(Feature.toggle("Trail", "Particles behind you while moving", "Effects", false));
    public static final Feature JUMP_FX    = add(Feature.toggle("Jump Circles", "Ring of sparks when you jump", "Effects", true));
    public static final Feature HALO       = add(Feature.toggle("Halo", "Glowing ring above your head", "Effects", false));
    public static final Feature ORBIT      = add(Feature.toggle("Orbit", "Sparkles circling around you", "Effects", false));

    // Theme
    public static final Feature THEME      = add(Feature.mode("Color Theme", "Accent colors of the whole client", "Theme", 0, Colors.THEME_NAMES));
    public static final Feature COLOR_SPEED = add(Feature.slider("Color Speed", "Speed of the color animation", "Theme", 0.2, 3.0, 1.0, false));
    public static final Feature HUD_ALPHA  = add(Feature.slider("HUD Opacity", "Background opacity of HUD panels", "Theme", 0.3, 1.0, 0.75, false));

    static {
        WATERMARK.style = style("Watermark Style", "Glass", "Compact", "Minimal");
        MODULE_LIST.style = style("Module List Style", "Bar", "Glass", "Minimal");
        POTIONS.style = style("Potions Style", "Panel", "Compact", "Minimal");
        TARGET_HUD.style = style("Target HUD Style", "Glass", "Compact", "Minimal", "Neon");
    }

    private static Feature style(String n, String... modes) {
        Feature f = Feature.mode(n, "Style", "_style", 0, modes);
        STYLES.add(f);
        return f;
    }

    public static final ParticleEffect[] FX = {ParticleTypes.END_ROD, ParticleTypes.HEART, ParticleTypes.FLAME, ParticleTypes.WITCH};

    public static double bps;
    public static Entity lastTarget;
    private static int lastTargetAge;

    private static KeyBinding openKey, zoomKey;
    private static boolean pendingOpen;
    private static boolean wasOnGround = true;
    private static double prevX, prevZ;
    private static boolean zoomActive;
    private static int zoomSaved = 70;
    private static int origFov = -1;
    private static boolean wasAtk, wasUse, sprintForced;
    private static final ArrayDeque<Long> LMB = new ArrayDeque<>();
    private static final ArrayDeque<Long> RMB = new ArrayDeque<>();

    private static Feature add(Feature f) {
        FEATURES.add(f);
        return f;
    }

    public static int cpsLeft() { return LMB.size(); }
    public static int cpsRight() { return RMB.size(); }

    public static void onToggle(Feature f) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (f == FULLBRIGHT && !f.enabled && mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        if (f == FOV_ON) {
            if (f.enabled) {
                origFov = mc.options.getFov().getValue();
            } else if (origFov > 0) {
                mc.options.getFov().setValue(origFov);
                origFov = -1;
            }
        }
    }

    @Override
    public void onInitializeClient() {
        loadConfig();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("aurora", "main"))));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C,
                KeyBinding.Category.create(Identifier.of("aurora", "main"))));

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("aurora", "hud"),
                (ctx, tick) -> AuroraHud.render(ctx));

        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tick) -> {
            if (CROSSHAIR.enabled) AuroraHud.crosshair(ctx);
            else original.render(ctx, tick);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("aurora").executes(ctx -> {
                    pendingOpen = true;
                    return 1;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(AuroraVisuals::tick);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) {
                lastTarget = entity;
                lastTargetAge = 0;
                if (HIT_FX.enabled) {
                    ParticleEffect fx = FX[HIT_MODE.mode];
                    for (int i = 0; i < 18; i++) {
                        double a = Math.random() * Math.PI * 2;
                        double s = 0.05 + Math.random() * 0.12;
                        world.addParticleClient(fx, entity.getX(), entity.getBodyY(0.5), entity.getZ(),
                                Math.cos(a) * s, 0.05 + Math.random() * 0.12, Math.sin(a) * s);
                    }
                }
                if (HIT_SOUND.enabled) player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.7f);
            }
            return ActionResult.PASS;
        });
    }

    private static double rnd() { return Math.random(); }

    private static void tick(MinecraftClient mc) {
        if (pendingOpen && mc.currentScreen == null) {
            pendingOpen = false;
            mc.setScreen(new AuroraScreen(true));
        }
        while (openKey.wasPressed()) mc.setScreen(new AuroraScreen(true));

        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return;

        double dx = p.getX() - prevX, dz = p.getZ() - prevZ;
        prevX = p.getX(); prevZ = p.getZ();
        bps += (Math.sqrt(dx * dx + dz * dz) * 20.0 - bps) * 0.25;

        long now = System.currentTimeMillis();
        boolean atk = mc.options.attackKey.isPressed();
        if (atk && !wasAtk) LMB.addLast(now);
        wasAtk = atk;
        boolean use = mc.options.useKey.isPressed();
        if (use && !wasUse) RMB.addLast(now);
        wasUse = use;
        while (!LMB.isEmpty() && now - LMB.peekFirst() > 1000) LMB.pollFirst();
        while (!RMB.isEmpty() && now - RMB.peekFirst() > 1000) RMB.pollFirst();

        if (AUTO_RESPAWN.enabled && p.isDead()) p.requestRespawn();

        if (AUTO_SPRINT.enabled) {
            if (mc.options.forwardKey.isPressed() && !p.isSneaking()) {
                mc.options.sprintKey.setPressed(true);
                sprintForced = true;
            } else if (sprintForced) {
                mc.options.sprintKey.setPressed(false);
                sprintForced = false;
            }
        } else if (sprintForced) {
            mc.options.sprintKey.setPressed(false);
            sprintForced = false;
        }

        if (FULLBRIGHT.enabled && p.age % 100 == 0) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }

        var fovOpt = mc.options.getFov();
        boolean zooming = ZOOM.enabled && zoomKey.isPressed();
        if (zooming) {
            if (!zoomActive) { zoomActive = true; zoomSaved = fovOpt.getValue(); }
            if (fovOpt.getValue() != 30) fovOpt.setValue(30);
        } else if (zoomActive) {
            zoomActive = false;
            fovOpt.setValue(zoomSaved);
        } else if (FOV_ON.enabled) {
            if (origFov < 0) origFov = fovOpt.getValue();
            int t = FOV.intValue();
            if (fovOpt.getValue() != t) fovOpt.setValue(t);
        }

        if (SNOW.enabled) {
            int n = SNOW_AMOUNT.intValue();
            for (int i = 0; i < n; i++) {
                w.addParticleClient(ParticleTypes.SNOWFLAKE,
                        p.getX() + (rnd() * 2 - 1) * 14, p.getY() + 2 + rnd() * 8, p.getZ() + (rnd() * 2 - 1) * 14,
                        (rnd() - 0.5) * 0.02, -0.06, (rnd() - 0.5) * 0.02);
            }
        }

        double speedSq = p.getVelocity().x * p.getVelocity().x + p.getVelocity().z * p.getVelocity().z;
        if (TRAIL.enabled && p.age % 2 == 0 && speedSq > 0.0009) {
            w.addParticleClient(FX[HIT_MODE.mode], p.getX(), p.getY() + 0.1, p.getZ(), 0, 0.01, 0);
        }

        boolean onGround = p.isOnGround();
        if (JUMP_FX.enabled && wasOnGround && !onGround && p.getVelocity().y > 0) {
            for (int i = 0; i < 36; i++) {
                double a = i / 36.0 * Math.PI * 2;
                w.addParticleClient(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(a) * 0.6, p.getY() + 0.05, p.getZ() + Math.sin(a) * 0.6,
                        Math.cos(a) * 0.04, 0.0, Math.sin(a) * 0.04);
            }
        }
        wasOnGround = onGround;

        if (HALO.enabled) {
            double a = p.age * 0.35;
            double y = p.getY() + p.getStandingEyeHeight() + 0.4;
            for (int k = 0; k < 2; k++) {
                double aa = a + k * Math.PI;
                w.addParticleClient(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(aa) * 0.4, y, p.getZ() + Math.sin(aa) * 0.4, 0, 0, 0);
            }
        }

        if (ORBIT.enabled) {
            for (int k = 0; k < 3; k++) {
                double a = p.age * 0.12 + k * 2.094;
                w.addParticleClient(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(a) * 0.9, p.getY() + 0.9 + Math.sin(p.age * 0.1 + k) * 0.5,
                        p.getZ() + Math.sin(a) * 0.9, 0, 0, 0);
            }
        }

        if (SWING.mode > 0 && p.handSwinging && p.handSwingTicks > 0 && p.age % (SWING.mode + 1) == 0) {
            p.handSwingTicks--;
        }

        if (lastTarget != null) {
            if (++lastTargetAge > 100) {
                lastTarget = null;
            } else if (lastTarget instanceof LivingEntity le && le.getHealth() <= 0f) {
                if (KILL_FX.enabled) {
                    for (int i = 0; i < 40; i++) {
                        w.addParticleClient(ParticleTypes.TOTEM_OF_UNDYING,
                                le.getX(), le.getBodyY(0.5), le.getZ(),
                                (rnd() - 0.5) * 0.5, rnd() * 0.5, (rnd() - 0.5) * 0.5);
                    }
                }
                lastTarget = null;
            }
        }
    }

    private static List<Feature> all() {
        List<Feature> l = new ArrayList<>(FEATURES);
        l.addAll(STYLES);
        return l;
    }

    private static Path cfg() {
        return FabricLoader.getInstance().getConfigDir().resolve("aurora_visuals.properties");
    }

    private static String key(Feature f) {
        return f.name.replace(' ', '_');
    }

    public static void saveConfig() {
        Properties p = new Properties();
        for (Feature f : all()) {
            switch (f.type) {
                case TOGGLE -> p.setProperty(key(f), String.valueOf(f.enabled));
                case SLIDER -> p.setProperty(key(f), String.valueOf(f.value));
                case MODE -> p.setProperty(key(f), String.valueOf(f.mode));
            }
        }
        p.setProperty("_origFov", String.valueOf(origFov));
        try (Writer w = Files.newBufferedWriter(cfg())) {
            p.store(w, NAME);
        } catch (IOException ignored) {
        }
    }

    private static void loadConfig() {
        Path path = cfg();
        if (!Files.exists(path)) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(path)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        for (Feature f : all()) {
            String v = p.getProperty(key(f));
            if (v == null) continue;
            try {
                switch (f.type) {
                    case TOGGLE -> { f.enabled = Boolean.parseBoolean(v); f.anim = f.enabled ? 1 : 0; f.guiAnim = f.anim; }
                    case SLIDER -> f.value = Math.max(f.min, Math.min(f.max, Double.parseDouble(v)));
                    case MODE -> f.mode = Math.max(0, Math.min(f.modes.length - 1, Integer.parseInt(v)));
                }
            } catch (NumberFormatException ignored) {
            }
        }
        try {
            origFov = Integer.parseInt(p.getProperty("_origFov", "-1"));
        } catch (NumberFormatException ignored) {
        }
    }
}
