package aurora.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class AuroraVisuals implements ClientModInitializer {
    public static final String NAME = "Aurora Visuals";
    public static final List<Module> MODULES = new ArrayList<>();

    public static final Module WATERMARK  = add("Watermark",     "HUD", true);
    public static final Module ARRAYLIST  = add("ArrayList",     "HUD", true);
    public static final Module INFO       = add("Info (XYZ/FPS)","HUD", true);
    public static final Module TARGET_HUD = add("Target HUD",    "HUD", true);
    public static final Module CROSSHAIR  = add("Crosshair",     "HUD", false);
    public static final Module FULLBRIGHT = add("Fullbright",    "World", false);
    public static final Module HIT_FX     = add("Hit Particles", "Effects", true);
    public static final Module TRAIL      = add("Trail",         "Effects", false);
    public static final Module JUMP_FX    = add("Jump Circles",  "Effects", true);

    private static KeyBinding openKey;
    private static boolean wasOnGround = true;

    private static Module add(String n, String c, boolean e) {
        Module m = new Module(n, c, e);
        MODULES.add(m);
        return m;
    }

    public static void onToggle(Module m) {
        if (m == FULLBRIGHT && !m.enabled) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("aurora", "main"))));

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("aurora", "hud"),
                (ctx, tick) -> AuroraHud.render(ctx));

        ClientTickEvents.END_CLIENT_TICK.register(AuroraVisuals::tick);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (HIT_FX.enabled && world.isClient()) {
                for (int i = 0; i < 18; i++) {
                    double a = Math.random() * Math.PI * 2;
                    double s = 0.05 + Math.random() * 0.12;
                    world.addParticleClient(ParticleTypes.END_ROD,
                            entity.getX(), entity.getBodyY(0.5), entity.getZ(),
                            Math.cos(a) * s, 0.05 + Math.random() * 0.12, Math.sin(a) * s);
                }
            }
            return ActionResult.PASS;
        });
    }

    private static void tick(MinecraftClient mc) {
        while (openKey.wasPressed()) mc.setScreen(new AuroraScreen());
        if (mc.player == null || mc.world == null) return;

        if (FULLBRIGHT.enabled && mc.player.age % 100 == 0) {
            mc.player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }

        if (TRAIL.enabled && mc.player.age % 2 == 0
                && (Math.abs(mc.player.getVelocity().x) + Math.abs(mc.player.getVelocity().z)) > 0.03) {
            mc.world.addParticleClient(ParticleTypes.END_ROD,
                    mc.player.getX(), mc.player.getY() + 0.1, mc.player.getZ(), 0, 0.01, 0);
        }

        boolean onGround = mc.player.isOnGround();
        if (JUMP_FX.enabled && wasOnGround && !onGround && mc.player.getVelocity().y > 0) {
            for (int i = 0; i < 36; i++) {
                double a = i / 36.0 * Math.PI * 2;
                mc.world.addParticleClient(ParticleTypes.END_ROD,
                        mc.player.getX() + Math.cos(a) * 0.6, mc.player.getY() + 0.05,
                        mc.player.getZ() + Math.sin(a) * 0.6,
                        Math.cos(a) * 0.04, 0.0, Math.sin(a) * 0.04);
            }
        }
        wasOnGround = onGround;
    }
}
