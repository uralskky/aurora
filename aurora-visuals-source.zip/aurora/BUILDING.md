# Building Aurora Visuals

Requirements: Java 21 and Gradle 8.14.3 or a compatible Gradle installation.

From the project root, run:

```bash
gradle --no-daemon clean build
```

The mod JAR will be created in `build/libs/`.

GitHub Actions is configured in `.github/workflows/build.yml`. After pushing this project to GitHub, open the **Actions** tab, select **Build Aurora Visuals**, and download the `aurora-visuals-jar` artifact from a successful run. The workflow must finish successfully before a JAR is available.
